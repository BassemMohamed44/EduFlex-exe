# Eduflex

برنامج Desktop احترافي (Offline) لإدارة المدرسين والطلاب والحضور والاختبارات والاشتراكات والتقارير.

## التقنيات
- Python 3.13+, PySide6, SQLAlchemy + SQLite, Argon2id, qrcode/OpenCV/pyzbar, ReportLab, openpyxl, pytest, PyInstaller

## حالة المشروع (قيد التنفيذ على مراحل)
- [x] Phase 1: هيكل المشروع + قاعدة البيانات + الموديلات
- [x] Phase 2: Authentication (Argon2id) + Teacher Profile
- [x] Phase 3: Student Management
- [x] Phase 4: Classes + Subscriptions
- [x] Phase 5: QR Generation + Scanner
- [x] Phase 6: Attendance System
- [x] Phase 7: Exams + Results
- [x] Phase 8: Reports + Export
- [x] Phase 9: Dashboard + Login Window + Main Window (أول واجهة قابلة للتشغيل فعليًا)
- [x] Phase 10: Backup / Restore
- [x] Phase 11: Testing (تغطية شاملة عبر كل المراحل)
- [x] Phase 12: Security Review + Bug Fixing
- [x] Phase 13: Packaging (PyInstaller spec جاهز - البناء الفعلي لملف .exe يتطلب تشغيله على جهاز Windows)

## التشغيل (بيئة تطوير)
```bash
pip install -r requirements.txt
pytest              # تشغيل الاختبارات
python -m app.main  # تشغيل التطبيق - سيظهر شاشة تسجيل الدخول
```

عند أول تشغيل، ستظهر شاشة "إنشاء حساب المدرس" (اسم، مادة، كلمة مرور).
بعد الإنشاء سيتم تسجيل الدخول تلقائيًا وستظهر النافذة الرئيسية بلوحة تحكم (Dashboard) تعرض بيانات حقيقية من قاعدة البيانات.

**حالة الشاشات: 9/9 مكتملة، بما فيها مسح QR بالكاميرا الحية في شاشة الحضور**

## بناء نسخة Windows (.exe)
```bat
build_windows.bat
```
يجب تشغيل هذا السكريبت **على جهاز Windows فعلي** (وليس بيئة التطوير الحالية) داخل virtualenv مثبّت عليه `requirements.txt`. يقوم بتشغيل الاختبارات أولًا، ثم يبني `dist\Eduflex\Eduflex.exe` عبر `eduflex.spec`.

## ملخص المراجعة الأمنية (Phase 12)
- ✅ لا يوجد أي استخدام لـ `print()` لمعالجة الأخطاء في الكود بالكامل (تحقق فعلي بالبحث)
- ✅ كلمات المرور وهاشاتها **لا تظهر إطلاقًا** في ملفات الـLogs (تحقق فعلي بقراءة محتوى ملف اللوج بعد Login/Change Password)
- ✅ توكن QR والـpayload الخاص به **لا يظهران** في الـLogs
- ✅ محاولات SQL Injection في مدخلات المستخدم (مثل اسم الطالب) تُخزَّن كنص عادي آمن بفضل SQLAlchemy ORM، ولا تُنفَّذ كأوامر SQL (تحقق فعلي)
- ✅ اختبار تدفق كامل (End-to-End) يغطي كل المراحل من تسجيل الدخول وحتى النسخ الاحتياطي والاستعادة
- 🐛 تم اكتشاف وإصلاح علة حرجة فعلية أثناء الاختبار: تصادم أسماء ملفات النسخ الاحتياطي بدقة الثانية كان يمكن أن يؤدي لفقد بيانات أثناء الاستعادة (انظر Phase 10)
- 🐛 تم اكتشاف وإصلاح علة في نظام الـLogging لا تتبع تغيير مسارات البيانات (مؤثرة فقط في بيئة الاختبار، غير مؤثرة في الإنتاج الفعلي)

## هيكل المشروع
```
Eduflex/
├── app/
│   ├── main.py
│   ├── config/        # مسارات البيانات والإعدادات
│   ├── database/      # اتصال SQLAlchemy + migrations
│   ├── models/        # جداول قاعدة البيانات (ORM)
│   ├── repositories/  # طبقة الوصول للبيانات
│   ├── services/       # منطق العمل (Business Logic)
│   ├── security/       # تشفير كلمات المرور
│   ├── qr/             # توليد وقراءة QR
│   ├── reports/        # توليد تقارير PDF/Excel
│   ├── ui/              # واجهات PySide6
│   └── utils/           # أدوات مساعدة (logging, exceptions)
├── tests/
├── assets/
├── requirements.txt
└── pyproject.toml
```

## ملاحظات أمنية
- كلمات المرور تُخزَّن كـ Argon2id hash فقط.
- QR codes تحتوي على token عشوائي فقط، وليس بيانات شخصية.
- قاعدة البيانات تُخزَّن في مجلد بيانات المستخدم (AppData) وليس داخل مجلد التثبيت.
