from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from app.database.init_db import init_database
from app.licensing import license_service
from app.ui.theme import app_stylesheet, force_light_palette
from app.ui.windows.license_window import LicenseWindow
from app.ui.windows.login_window import LoginWindow
from app.ui.windows.main_window import MainWindow
from app.utils.logger import get_logger

logger = get_logger(__name__)


class AppController:

    def __init__(self) -> None:
        self.license_window: LicenseWindow | None = None
        self.login_window: LoginWindow | None = None
        self.main_window: MainWindow | None = None

    def start(self) -> None:
        if license_service.is_valid():
            self._show_login()
        else:
            self._show_license()

    def _show_license(self) -> None:
        self.license_window = LicenseWindow()
        self.license_window.activated.connect(self._on_activated)
        self.license_window.show()

    def _on_activated(self) -> None:
        if self.license_window is not None:
            self.license_window.close()
            self.license_window = None
        self._show_login()

    def _show_login(self) -> None:
        self.main_window = None
        self.login_window = LoginWindow()
        self.login_window.login_succeeded.connect(self._show_main_window)
        self.login_window.show()

    def _show_main_window(self) -> None:
        if self.login_window is not None:
            self.login_window.close()
            self.login_window = None

        self.main_window = MainWindow()
        self.main_window.destroyed.connect(self._on_main_window_closed)
        self.main_window.show()
        self._maybe_show_expiry_reminder()

    def _maybe_show_expiry_reminder(self) -> None:
        status = license_service.get_status()
        remaining = status.get("remaining_days")
        if remaining is not None and remaining <= 7:
            from app.ui.helpers import show_info

            show_info(
                self.main_window,
                f"سينتهي ترخيص البرنامج خلال {remaining} يوم. برجاء تجديد الترخيص.",
                "تنبيه انتهاء الترخيص",
            )

    def _on_main_window_closed(self) -> None:
        from app.services.auth_service import current_session

        if not current_session.is_authenticated:
            self._show_login()


def main() -> int:
    logger.info("Eduflex starting up.")
    init_database()

    app = QApplication(sys.argv)
    app.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
    force_light_palette(app)
    app.setStyleSheet(app_stylesheet())

    controller = AppController()
    controller.start()

    exit_code = app.exec()
    logger.info("Eduflex shutting down (exit_code=%s).", exit_code)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
