from __future__ import annotations

import enum

from sqlalchemy import Enum, ForeignKey, Numeric, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin


class ClassStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class ClassSession(Base, TimestampMixin):
    __tablename__ = "classes"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    subject: Mapped[str] = mapped_column(String(100), nullable=False)

    days_of_week: Mapped[str] = mapped_column(String(100), nullable=False)
    time_slot: Mapped[str] = mapped_column(String(50), nullable=False)

    price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False, default=0)
    center_name: Mapped[str | None] = mapped_column(String(150), nullable=True)

    status: Mapped[ClassStatus] = mapped_column(
        Enum(ClassStatus), nullable=False, default=ClassStatus.ACTIVE
    )

    enrollments: Mapped[list["Enrollment"]] = relationship(
        back_populates="class_session", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<ClassSession id={self.id} subject={self.subject!r} time={self.time_slot!r}>"


class Enrollment(Base, TimestampMixin):

    __tablename__ = "enrollments"
    __table_args__ = (
        UniqueConstraint("student_id", "class_id", name="uq_enrollment_student_class"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    class_id: Mapped[int] = mapped_column(
        ForeignKey("classes.id", ondelete="CASCADE"), nullable=False, index=True
    )

    student: Mapped["Student"] = relationship(back_populates="enrollments")
    class_session: Mapped["ClassSession"] = relationship(back_populates="enrollments")
