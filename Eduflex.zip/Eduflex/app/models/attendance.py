from __future__ import annotations

import datetime as dt
import enum

from sqlalchemy import Date, DateTime, Enum, ForeignKey, Index, Integer, String, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin


class AttendanceStatus(str, enum.Enum):
    PRESENT = "present"
    LEFT = "left"
    ABSENT = "absent"


class AttendanceSource(str, enum.Enum):
    QR = "qr"
    MANUAL_ID = "manual_id"


class Attendance(Base, TimestampMixin):
    __tablename__ = "attendance"
    __table_args__ = (
        UniqueConstraint("student_id", "attendance_date", "class_id", name="uq_attendance_day_with_class"),
        Index(
            "uq_attendance_day_no_class",
            "student_id",
            "attendance_date",
            unique=True,
            sqlite_where=text("class_id IS NULL"),
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    class_id: Mapped[int | None] = mapped_column(
        ForeignKey("classes.id", ondelete="SET NULL"), nullable=True, index=True
    )

    attendance_date: Mapped[dt.date] = mapped_column(Date, nullable=False, index=True)
    check_in_time: Mapped[dt.datetime] = mapped_column(DateTime, nullable=False)
    check_out_time: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)

    status: Mapped[AttendanceStatus] = mapped_column(Enum(AttendanceStatus), nullable=False)
    source: Mapped[AttendanceSource] = mapped_column(Enum(AttendanceSource), nullable=False)

    student: Mapped["Student"] = relationship(back_populates="attendance_records")

    def __repr__(self) -> str:
        return (
            f"<Attendance id={self.id} student_id={self.student_id} "
            f"date={self.attendance_date} status={self.status}>"
        )
