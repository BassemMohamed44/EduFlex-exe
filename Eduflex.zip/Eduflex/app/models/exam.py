from __future__ import annotations

import datetime as dt

from sqlalchemy import CheckConstraint, Date, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin


class Exam(Base, TimestampMixin):
    __tablename__ = "exams"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    subject: Mapped[str] = mapped_column(String(100), nullable=False)
    exam_date: Mapped[dt.date] = mapped_column(Date, nullable=False)
    max_score: Mapped[float] = mapped_column(Numeric(6, 2), nullable=False)
    grade_level: Mapped[str] = mapped_column(String(50), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    results: Mapped[list["ExamResult"]] = relationship(
        back_populates="exam", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Exam id={self.id} name={self.name!r} max_score={self.max_score}>"


class ExamResult(Base, TimestampMixin):
    __tablename__ = "exam_results"
    __table_args__ = (
        UniqueConstraint("exam_id", "student_id", name="uq_exam_result_student"),
        CheckConstraint("score >= 0", name="ck_exam_result_score_nonneg"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    exam_id: Mapped[int] = mapped_column(
        ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True
    )
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    score: Mapped[float] = mapped_column(Numeric(6, 2), nullable=False)

    exam: Mapped["Exam"] = relationship(back_populates="results")
    student: Mapped["Student"] = relationship(back_populates="exam_results")

    def __repr__(self) -> str:
        return f"<ExamResult exam_id={self.exam_id} student_id={self.student_id} score={self.score}>"
