from __future__ import annotations

import datetime as dt
import enum

from sqlalchemy import Date, Enum, ForeignKey, Index, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin


class StudentStatus(str, enum.Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    ARCHIVED = "archived"


class Student(Base, TimestampMixin):

    __tablename__ = "students"
    __table_args__ = (
        Index("ix_students_full_name", "full_name"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    student_code: Mapped[str] = mapped_column(
        String(4), unique=True, nullable=False, index=True
    )

    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    grade_level: Mapped[str] = mapped_column(String(50), nullable=False)

    lesson_time: Mapped[str | None] = mapped_column(String(100), nullable=True)

    subscription_price: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False, default=0)
    center_name: Mapped[str | None] = mapped_column(String(150), nullable=True)

    student_phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    guardian_phone: Mapped[str | None] = mapped_column(String(30), nullable=True)

    subscription_start: Mapped[dt.date | None] = mapped_column(Date, nullable=True)
    subscription_end: Mapped[dt.date | None] = mapped_column(Date, nullable=True)

    status: Mapped[StudentStatus] = mapped_column(
        Enum(StudentStatus), nullable=False, default=StudentStatus.ACTIVE
    )

    qr_token: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)

    subscriptions: Mapped[list["Subscription"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )
    attendance_records: Mapped[list["Attendance"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )
    enrollments: Mapped[list["Enrollment"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )
    exam_results: Mapped[list["ExamResult"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Student id={self.id} code={self.student_code} name={self.full_name!r}>"
