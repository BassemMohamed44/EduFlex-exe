from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.teacher import Teacher


class TeacherRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_by_id(self, teacher_id: int) -> Teacher | None:
        return self.session.get(Teacher, teacher_id)

    def get_by_name(self, full_name: str) -> Teacher | None:
        return (
            self.session.query(Teacher)
            .filter(Teacher.full_name == full_name)
            .one_or_none()
        )

    def list_all(self) -> list[Teacher]:
        return self.session.query(Teacher).order_by(Teacher.full_name).all()

    def any_exists(self) -> bool:
        return self.session.query(Teacher.id).first() is not None

    def add(self, teacher: Teacher) -> Teacher:
        self.session.add(teacher)
        self.session.flush()
        return teacher

    def update(self, teacher: Teacher) -> Teacher:
        self.session.flush()
        return teacher
