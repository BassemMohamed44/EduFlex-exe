from __future__ import annotations

import datetime as dt

from sqlalchemy.orm import Session

from app.models.subscription import Subscription


class SubscriptionRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_by_id(self, subscription_id: int) -> Subscription | None:
        return self.session.get(Subscription, subscription_id)

    def add(self, subscription: Subscription) -> Subscription:
        self.session.add(subscription)
        self.session.flush()
        return subscription

    def update(self, subscription: Subscription) -> Subscription:
        self.session.flush()
        return subscription

    def delete(self, subscription: Subscription) -> None:
        self.session.delete(subscription)
        self.session.flush()

    def list_for_student(self, student_id: int) -> list[Subscription]:
        return (
            self.session.query(Subscription)
            .filter(Subscription.student_id == student_id)
            .order_by(Subscription.end_date.desc())
            .all()
        )

    def get_latest_for_student(self, student_id: int) -> Subscription | None:
        return (
            self.session.query(Subscription)
            .filter(Subscription.student_id == student_id)
            .order_by(Subscription.end_date.desc())
            .first()
        )

    def list_all_latest_per_student(self) -> list[Subscription]:
        all_subs = self.session.query(Subscription).order_by(Subscription.end_date.desc()).all()
        seen: set[int] = set()
        latest: list[Subscription] = []
        for sub in all_subs:
            if sub.student_id not in seen:
                seen.add(sub.student_id)
                latest.append(sub)
        return latest

    def list_expiring_between(self, start: dt.date, end: dt.date) -> list[Subscription]:
        return (
            self.session.query(Subscription)
            .filter(Subscription.end_date >= start, Subscription.end_date <= end)
            .order_by(Subscription.end_date.asc())
            .all()
        )
