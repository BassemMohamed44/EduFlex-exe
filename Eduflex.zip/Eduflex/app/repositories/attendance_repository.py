from __future__ import annotations

import datetime as dt

from sqlalchemy.orm import Session

from app.models.attendance import Attendance


class AttendanceRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_by_id(self, attendance_id: int) -> Attendance | None:
        return self.session.get(Attendance, attendance_id)

    def get_for_student_on_date(
        self, student_id: int, date: dt.date, class_id: int | None = None
    ) -> Attendance | None:
        return (
            self.session.query(Attendance)
            .filter(
                Attendance.student_id == student_id,
                Attendance.attendance_date == date,
                Attendance.class_id == class_id,
            )
            .one_or_none()
        )

    def add(self, attendance: Attendance) -> Attendance:
        self.session.add(attendance)
        self.session.flush()
        return attendance

    def update(self, attendance: Attendance) -> Attendance:
        self.session.flush()
        return attendance

    def list_for_student(self, student_id: int) -> list[Attendance]:
        return (
            self.session.query(Attendance)
            .filter(Attendance.student_id == student_id)
            .order_by(Attendance.attendance_date.desc())
            .all()
        )

    def list_for_date(self, date: dt.date) -> list[Attendance]:
        return (
            self.session.query(Attendance)
            .filter(Attendance.attendance_date == date)
            .order_by(Attendance.check_in_time.asc())
            .all()
        )

    def list_recent(self, limit: int = 10) -> list[Attendance]:
        return (
            self.session.query(Attendance)
            .order_by(Attendance.check_in_time.desc())
            .limit(limit)
            .all()
        )

    def count_present_on_date(self, date: dt.date) -> int:
        return self.session.query(Attendance).filter(Attendance.attendance_date == date).count()
