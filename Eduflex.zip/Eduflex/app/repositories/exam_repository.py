from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.exam import Exam, ExamResult


class ExamRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_by_id(self, exam_id: int) -> Exam | None:
        return self.session.get(Exam, exam_id)

    def add(self, exam: Exam) -> Exam:
        self.session.add(exam)
        self.session.flush()
        return exam

    def update(self, exam: Exam) -> Exam:
        self.session.flush()
        return exam

    def delete(self, exam: Exam) -> None:
        self.session.delete(exam)
        self.session.flush()

    def list_all(self, grade_level: str | None = None, subject: str | None = None) -> list[Exam]:
        query = self.session.query(Exam)
        if grade_level:
            query = query.filter(Exam.grade_level == grade_level)
        if subject:
            query = query.filter(Exam.subject == subject)
        return query.order_by(Exam.exam_date.desc()).all()

    def get_result(self, exam_id: int, student_id: int) -> ExamResult | None:
        return (
            self.session.query(ExamResult)
            .filter(ExamResult.exam_id == exam_id, ExamResult.student_id == student_id)
            .one_or_none()
        )

    def add_result(self, result: ExamResult) -> ExamResult:
        self.session.add(result)
        self.session.flush()
        return result

    def update_result(self, result: ExamResult) -> ExamResult:
        self.session.flush()
        return result

    def delete_result(self, result: ExamResult) -> None:
        self.session.delete(result)
        self.session.flush()

    def list_results_for_exam(self, exam_id: int) -> list[ExamResult]:
        return (
            self.session.query(ExamResult)
            .filter(ExamResult.exam_id == exam_id)
            .all()
        )

    def list_results_for_student(self, student_id: int) -> list[ExamResult]:
        return (
            self.session.query(ExamResult)
            .filter(ExamResult.student_id == student_id)
            .all()
        )
