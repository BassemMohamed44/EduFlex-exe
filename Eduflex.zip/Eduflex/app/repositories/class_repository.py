from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.class_session import ClassSession, ClassStatus, Enrollment
from app.models.student import Student


class ClassRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_by_id(self, class_id: int) -> ClassSession | None:
        return self.session.get(ClassSession, class_id)

    def list_all(self, status: ClassStatus | None = None) -> list[ClassSession]:
        query = self.session.query(ClassSession)
        if status:
            query = query.filter(ClassSession.status == status)
        return query.order_by(ClassSession.subject).all()

    def add(self, class_session: ClassSession) -> ClassSession:
        self.session.add(class_session)
        self.session.flush()
        return class_session

    def update(self, class_session: ClassSession) -> ClassSession:
        self.session.flush()
        return class_session

    def delete(self, class_session: ClassSession) -> None:
        self.session.delete(class_session)
        self.session.flush()

    def get_enrollment(self, student_id: int, class_id: int) -> Enrollment | None:
        return (
            self.session.query(Enrollment)
            .filter(Enrollment.student_id == student_id, Enrollment.class_id == class_id)
            .one_or_none()
        )

    def enroll(self, student_id: int, class_id: int) -> Enrollment:
        enrollment = Enrollment(student_id=student_id, class_id=class_id)
        self.session.add(enrollment)
        self.session.flush()
        return enrollment

    def unenroll(self, enrollment: Enrollment) -> None:
        self.session.delete(enrollment)
        self.session.flush()

    def list_students_for_class(self, class_id: int) -> list[Student]:
        return (
            self.session.query(Student)
            .join(Enrollment, Enrollment.student_id == Student.id)
            .filter(Enrollment.class_id == class_id)
            .order_by(Student.full_name)
            .all()
        )

    def list_classes_for_student(self, student_id: int) -> list[ClassSession]:
        return (
            self.session.query(ClassSession)
            .join(Enrollment, Enrollment.class_id == ClassSession.id)
            .filter(Enrollment.student_id == student_id)
            .order_by(ClassSession.subject)
            .all()
        )
