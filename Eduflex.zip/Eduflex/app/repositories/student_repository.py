from __future__ import annotations

from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.models.student import Student, StudentStatus


class StudentRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_by_id(self, student_id: int) -> Student | None:
        return self.session.get(Student, student_id)

    def get_by_code(self, student_code: str) -> Student | None:
        return (
            self.session.query(Student)
            .filter(Student.student_code == student_code)
            .one_or_none()
        )

    def get_by_qr_token(self, qr_token: str) -> Student | None:
        return (
            self.session.query(Student)
            .filter(Student.qr_token == qr_token)
            .one_or_none()
        )

    def code_exists(self, student_code: str) -> bool:
        return self.get_by_code(student_code) is not None

    def count(self) -> int:
        return self.session.query(Student).count()

    def add(self, student: Student) -> Student:
        self.session.add(student)
        self.session.flush()
        return student

    def update(self, student: Student) -> Student:
        self.session.flush()
        return student

    def delete(self, student: Student) -> None:
        self.session.delete(student)
        self.session.flush()

    def search(
        self,
        *,
        text: str | None = None,
        grade_level: str | None = None,
        center_name: str | None = None,
        status: StudentStatus | None = None,
        sort_by: str = "full_name",
        sort_desc: bool = False,
    ) -> list[Student]:
        query = self.session.query(Student)

        if text:
            like_pattern = f"%{text.strip()}%"
            query = query.filter(
                or_(
                    Student.full_name.like(like_pattern),
                    Student.student_code.like(like_pattern),
                )
            )
        if grade_level:
            query = query.filter(Student.grade_level == grade_level)
        if center_name:
            query = query.filter(Student.center_name == center_name)
        if status:
            query = query.filter(Student.status == status)

        sort_column = getattr(Student, sort_by, Student.full_name)
        query = query.order_by(sort_column.desc() if sort_desc else sort_column.asc())

        return query.all()

    def list_all(self) -> list[Student]:
        return self.session.query(Student).order_by(Student.full_name).all()
