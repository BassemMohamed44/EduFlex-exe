from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json
from pathlib import Path

from app.config.settings import get_paths
from app.licensing.codec import LicenseCodeError, decode_license_code
from app.licensing.keys import LOCAL_HMAC_SECRET
from app.licensing.machine_id import get_machine_id
from app.utils.exceptions import EduflexError
from app.utils.logger import get_logger

logger = get_logger(__name__)


class LicenseError(EduflexError):
    pass


def _license_file() -> Path:
    return get_paths().root / "license.dat"


def _compute_mac(record: dict) -> str:
    canonical = json.dumps(
        {k: v for k, v in record.items() if k != "mac"}, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hmac.new(LOCAL_HMAC_SECRET, canonical, hashlib.sha256).hexdigest()


def _load_record() -> dict | None:
    path = _license_file()
    if not path.exists():
        return None
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    expected_mac = _compute_mac(record)
    if not hmac.compare_digest(expected_mac, record.get("mac", "")):
        logger.warning("License file failed integrity check.")
        return None
    return record


def _save_record(record: dict) -> None:
    record = dict(record)
    record["mac"] = _compute_mac(record)
    _license_file().write_text(json.dumps(record), encoding="utf-8")


def activate(code: str) -> dict:
    payload = decode_license_code(code)
    machine_id = get_machine_id()
    record = {
        "code": code.strip().upper(),
        "plan": payload["plan"],
        "days": payload["days"],
        "license_id": payload["id"],
        "machine_id": machine_id,
        "activated_at": dt.datetime.now().isoformat(),
    }
    _save_record(record)
    logger.info("License activated (plan=%s).", payload["plan"])
    return get_status()


def get_status() -> dict:
    record = _load_record()
    if record is None:
        return {"activated": False, "valid": False, "reason": "not_activated"}

    if record.get("machine_id") != get_machine_id():
        return {"activated": True, "valid": False, "reason": "machine_mismatch"}

    try:
        activated_at = dt.datetime.fromisoformat(record["activated_at"])
    except (KeyError, ValueError):
        return {"activated": True, "valid": False, "reason": "corrupt"}

    expires_at = activated_at + dt.timedelta(days=record.get("days", 0))
    now = dt.datetime.now()
    remaining_days = (expires_at - now).days

    if now > expires_at:
        return {
            "activated": True,
            "valid": False,
            "reason": "expired",
            "plan": record.get("plan"),
            "expires_at": expires_at,
        }

    return {
        "activated": True,
        "valid": True,
        "reason": "ok",
        "plan": record.get("plan"),
        "expires_at": expires_at,
        "remaining_days": remaining_days,
    }


def is_valid() -> bool:
    return get_status().get("valid", False)


def deactivate_for_tests() -> None:
    path = _license_file()
    if path.exists():
        path.unlink()
