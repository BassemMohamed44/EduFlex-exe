PUBLIC_KEY_B64 = "2rX3mU39Ze5TM7Xv5QEa6aDnSLz0AaSvH1PgjZGqoQE="
LOCAL_HMAC_SECRET = b"eduflex-license-guard-8f2a41c6-do-not-share"
