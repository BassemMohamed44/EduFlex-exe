from __future__ import annotations

import base64
import json

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ed25519

from app.licensing.keys import PUBLIC_KEY_B64
from app.utils.exceptions import EduflexError

PLANS = {"monthly": 30, "yearly": 365}


class LicenseCodeError(EduflexError):
    pass


def encode_license_code(private_key_b64: str, plan: str, license_id: str) -> str:
    if plan not in PLANS:
        raise LicenseCodeError("نوع الباقة غير صالح.")
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(private_key_b64))
    payload = {"plan": plan, "days": PLANS[plan], "id": license_id}
    payload_bytes = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    signature = private_key.sign(payload_bytes)
    combined = payload_bytes + signature
    raw = base64.b32encode(combined).decode("ascii").rstrip("=")
    return "-".join(raw[i:i + 5] for i in range(0, len(raw), 5))


def decode_license_code(code: str) -> dict:
    cleaned = code.strip().upper().replace("-", "").replace(" ", "")
    if not cleaned:
        raise LicenseCodeError("كود التفعيل فارغ.")
    padding = "=" * ((8 - len(cleaned) % 8) % 8)
    try:
        combined = base64.b32decode(cleaned + padding)
        signature = combined[-64:]
        payload_bytes = combined[:-64]
        payload = json.loads(payload_bytes.decode("utf-8"))
    except Exception as exc:
        raise LicenseCodeError("كود التفعيل غير صالح.") from exc

    public_key = ed25519.Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))
    try:
        public_key.verify(signature, payload_bytes)
    except InvalidSignature as exc:
        raise LicenseCodeError("كود التفعيل غير صالح أو تم التلاعب به.") from exc

    if payload.get("plan") not in PLANS or not isinstance(payload.get("days"), int):
        raise LicenseCodeError("كود التفعيل غير صالح.")

    return payload
