from __future__ import annotations

import hashlib
import platform
import uuid


def get_machine_id() -> str:
    raw = f"{uuid.getnode()}-{platform.node()}-{platform.system()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]
