from __future__ import annotations

import datetime as dt
import re

from app.utils.exceptions import ValidationError

PHONE_PATTERN = re.compile(r"^[0-9+\-\s]{7,20}$")


def require_non_empty(value: str | None, field_label: str) -> str:
    value = (value or "").strip()
    if not value:
        raise ValidationError(f"{field_label} مطلوب.")
    return value


def validate_phone(value: str | None, field_label: str, required: bool = False) -> str | None:
    value = (value or "").strip() or None
    if value is None:
        if required:
            raise ValidationError(f"{field_label} مطلوب.")
        return None
    if not PHONE_PATTERN.match(value):
        raise ValidationError(f"{field_label} غير صالح.")
    return value


def validate_non_negative_number(value, field_label: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field_label} يجب أن يكون رقمًا.")
    if number < 0:
        raise ValidationError(f"{field_label} لا يمكن أن يكون سالبًا.")
    return number


def validate_date_range(start: dt.date | None, end: dt.date | None) -> None:
    if start and end and end < start:
        raise ValidationError("تاريخ النهاية يجب أن يكون بعد تاريخ البداية.")
