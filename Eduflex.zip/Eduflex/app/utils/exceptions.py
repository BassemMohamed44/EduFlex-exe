from __future__ import annotations


class EduflexError(Exception):
    pass


class AuthenticationError(EduflexError):
    pass


class NotAuthenticatedError(EduflexError):
    pass


class ValidationError(EduflexError):
    pass


class DuplicateError(EduflexError):
    pass


class NotFoundError(EduflexError):
    pass


class AttendanceError(EduflexError):
    pass


class SubscriptionError(EduflexError):
    pass


class QRError(EduflexError):
    pass


class BackupError(EduflexError):
    pass
