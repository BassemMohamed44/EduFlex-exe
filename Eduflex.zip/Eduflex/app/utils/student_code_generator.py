from __future__ import annotations

import random

from app.utils.exceptions import ValidationError

CODE_MIN = 1000
CODE_MAX = 9999
MAX_GENERATION_ATTEMPTS = 50


def generate_candidate_code() -> str:
    return str(random.randint(CODE_MIN, CODE_MAX))


def total_capacity() -> int:
    return CODE_MAX - CODE_MIN + 1


def ensure_capacity_available(current_count: int) -> None:
    if current_count >= total_capacity():
        raise ValidationError(
            "تم الوصول إلى الحد الأقصى لعدد معرفات الطلاب المتاحة (4 أرقام)."
        )
