from __future__ import annotations

import logging
import sys
from logging.handlers import TimedRotatingFileHandler

_configured = False


def _build_handlers() -> None:
    from app.config.settings import get_paths

    log_dir = get_paths().logs_dir
    log_file = log_dir / "eduflex.log"

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = TimedRotatingFileHandler(
        log_file, when="midnight", backupCount=14, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.WARNING)

    root = logging.getLogger("eduflex")
    root.setLevel(logging.INFO)
    root.addHandler(file_handler)
    root.addHandler(console_handler)
    root.propagate = False


def _configure_root_logger() -> None:
    global _configured
    if _configured:
        return
    _build_handlers()
    _configured = True


def reset_logging_for_tests() -> None:
    global _configured
    root = logging.getLogger("eduflex")
    for handler in list(root.handlers):
        handler.close()
        root.removeHandler(handler)
    _build_handlers()
    _configured = True


def get_logger(name: str) -> logging.Logger:
    _configure_root_logger()
    return logging.getLogger(f"eduflex.{name}")
