from __future__ import annotations

from app.database.session import session_scope
from app.models.class_session import ClassSession, ClassStatus
from app.repositories.class_repository import ClassRepository
from app.repositories.student_repository import StudentRepository
from app.utils.exceptions import DuplicateError, NotFoundError, ValidationError
from app.utils.logger import get_logger
from app.utils.validators import require_non_empty, validate_non_negative_number

logger = get_logger(__name__)


def create_class(
    *,
    subject: str,
    days_of_week: str,
    time_slot: str,
    price: float = 0,
    center_name: str | None = None,
) -> dict:
    subject = require_non_empty(subject, "المادة")
    days_of_week = require_non_empty(days_of_week, "أيام الدرس")
    time_slot = require_non_empty(time_slot, "موعد الدرس")
    price = validate_non_negative_number(price, "السعر")

    with session_scope() as session:
        repo = ClassRepository(session)
        class_session = ClassSession(
            subject=subject,
            days_of_week=days_of_week,
            time_slot=time_slot,
            price=price,
            center_name=(center_name or "").strip() or None,
            status=ClassStatus.ACTIVE,
        )
        repo.add(class_session)
        logger.info("Created class id=%s subject=%s", class_session.id, subject)
        return _class_to_dict(class_session)


def update_class(
    class_id: int,
    *,
    subject: str,
    days_of_week: str,
    time_slot: str,
    price: float = 0,
    center_name: str | None = None,
    status: ClassStatus | None = None,
) -> dict:
    subject = require_non_empty(subject, "المادة")
    days_of_week = require_non_empty(days_of_week, "أيام الدرس")
    time_slot = require_non_empty(time_slot, "موعد الدرس")
    price = validate_non_negative_number(price, "السعر")

    with session_scope() as session:
        repo = ClassRepository(session)
        class_session = repo.get_by_id(class_id)
        if class_session is None:
            raise NotFoundError("لم يتم العثور على الحصة.")

        class_session.subject = subject
        class_session.days_of_week = days_of_week
        class_session.time_slot = time_slot
        class_session.price = price
        class_session.center_name = (center_name or "").strip() or None
        if status is not None:
            class_session.status = status

        repo.update(class_session)
        logger.info("Updated class id=%s", class_id)
        return _class_to_dict(class_session)


def delete_class(class_id: int) -> None:
    with session_scope() as session:
        repo = ClassRepository(session)
        class_session = repo.get_by_id(class_id)
        if class_session is None:
            raise NotFoundError("لم يتم العثور على الحصة.")
        repo.delete(class_session)
        logger.info("Deleted class id=%s", class_id)


def get_class(class_id: int) -> dict:
    with session_scope() as session:
        repo = ClassRepository(session)
        class_session = repo.get_by_id(class_id)
        if class_session is None:
            raise NotFoundError("لم يتم العثور على الحصة.")
        return _class_to_dict(class_session)


def list_classes(status: ClassStatus | None = None) -> list[dict]:
    with session_scope() as session:
        repo = ClassRepository(session)
        return [_class_to_dict(c) for c in repo.list_all(status=status)]


def enroll_student(student_id: int, class_id: int) -> None:
    with session_scope() as session:
        class_repo = ClassRepository(session)
        student_repo = StudentRepository(session)

        if student_repo.get_by_id(student_id) is None:
            raise NotFoundError("لم يتم العثور على الطالب.")
        if class_repo.get_by_id(class_id) is None:
            raise NotFoundError("لم يتم العثور على الحصة.")
        if class_repo.get_enrollment(student_id, class_id) is not None:
            raise DuplicateError("الطالب مسجل بالفعل في هذه الحصة.")

        class_repo.enroll(student_id, class_id)
        logger.info("Enrolled student_id=%s in class_id=%s", student_id, class_id)


def unenroll_student(student_id: int, class_id: int) -> None:
    with session_scope() as session:
        class_repo = ClassRepository(session)
        enrollment = class_repo.get_enrollment(student_id, class_id)
        if enrollment is None:
            raise NotFoundError("الطالب غير مسجل في هذه الحصة.")
        class_repo.unenroll(enrollment)
        logger.info("Unenrolled student_id=%s from class_id=%s", student_id, class_id)


def list_students_for_class(class_id: int) -> list[dict]:
    with session_scope() as session:
        class_repo = ClassRepository(session)
        if class_repo.get_by_id(class_id) is None:
            raise NotFoundError("لم يتم العثور على الحصة.")
        students = class_repo.list_students_for_class(class_id)
        return [
            {"id": s.id, "student_code": s.student_code, "full_name": s.full_name}
            for s in students
        ]


def list_classes_for_student(student_id: int) -> list[dict]:
    with session_scope() as session:
        class_repo = ClassRepository(session)
        classes = class_repo.list_classes_for_student(student_id)
        return [_class_to_dict(c) for c in classes]


def _class_to_dict(class_session: ClassSession) -> dict:
    return {
        "id": class_session.id,
        "subject": class_session.subject,
        "days_of_week": class_session.days_of_week,
        "time_slot": class_session.time_slot,
        "price": float(class_session.price),
        "center_name": class_session.center_name,
        "status": class_session.status,
    }
