from __future__ import annotations

import re

from app.database.session import session_scope
from app.models.teacher import Teacher
from app.repositories.teacher_repository import TeacherRepository
from app.security.password_hasher import hash_password, needs_rehash, verify_password
from app.utils.exceptions import AuthenticationError, NotAuthenticatedError, ValidationError
from app.utils.logger import get_logger

logger = get_logger(__name__)

_MIN_PASSWORD_LENGTH = 8


class SessionState:

    def __init__(self) -> None:
        self._teacher_id: int | None = None
        self._teacher_name: str | None = None

    @property
    def is_authenticated(self) -> bool:
        return self._teacher_id is not None

    @property
    def teacher_id(self) -> int:
        if self._teacher_id is None:
            raise NotAuthenticatedError("No teacher is currently logged in.")
        return self._teacher_id

    @property
    def teacher_name(self) -> str | None:
        return self._teacher_name

    def _set(self, teacher: Teacher) -> None:
        self._teacher_id = teacher.id
        self._teacher_name = teacher.full_name

    def clear(self) -> None:
        self._teacher_id = None
        self._teacher_name = None


current_session = SessionState()


def _validate_password_strength(password: str) -> None:
    if len(password) < _MIN_PASSWORD_LENGTH:
        raise ValidationError(f"كلمة المرور يجب ألا تقل عن {_MIN_PASSWORD_LENGTH} أحرف.")
    if not re.search(r"[A-Za-z\u0600-\u06FF]", password) or not re.search(r"\d", password):
        raise ValidationError("كلمة المرور يجب أن تحتوي على أحرف وأرقام معًا.")


def has_any_account() -> bool:
    with session_scope() as session:
        return TeacherRepository(session).any_exists()


def register_teacher(full_name: str, subject: str, password: str) -> int:
    full_name = (full_name or "").strip()
    subject = (subject or "").strip()

    if not full_name:
        raise ValidationError("اسم المدرس مطلوب.")
    if not subject:
        raise ValidationError("المادة العلمية مطلوبة.")
    _validate_password_strength(password)

    with session_scope() as session:
        repo = TeacherRepository(session)
        if repo.get_by_name(full_name) is not None:
            raise ValidationError("يوجد حساب بهذا الاسم بالفعل.")

        teacher = Teacher(
            full_name=full_name,
            subject=subject,
            password_hash=hash_password(password),
        )
        repo.add(teacher)
        logger.info("Registered new teacher account (id=%s).", teacher.id)
        return teacher.id


def login(full_name: str, password: str) -> None:
    generic_error = AuthenticationError("اسم المدرس أو كلمة المرور غير صحيحة.")

    if not full_name or not password:
        logger.warning("Login attempt with empty name or password.")
        raise generic_error

    with session_scope() as session:
        repo = TeacherRepository(session)
        teacher = repo.get_by_name(full_name.strip())

        if teacher is None or not teacher.is_active:
            logger.warning("Login failed: account not found or inactive.")
            raise generic_error

        if not verify_password(password, teacher.password_hash):
            logger.warning("Login failed: incorrect password for teacher_id=%s.", teacher.id)
            raise generic_error

        if needs_rehash(teacher.password_hash):
            teacher.password_hash = hash_password(password)
            repo.update(teacher)
            logger.info("Upgraded password hash for teacher_id=%s.", teacher.id)

        current_session._set(teacher)
        logger.info("Teacher logged in (id=%s).", teacher.id)


def logout() -> None:
    if current_session.is_authenticated:
        logger.info("Teacher logged out (id=%s).", current_session.teacher_id)
    current_session.clear()


def change_password(old_password: str, new_password: str) -> None:
    teacher_id = current_session.teacher_id

    with session_scope() as session:
        repo = TeacherRepository(session)
        teacher = repo.get_by_id(teacher_id)
        if teacher is None:
            raise NotAuthenticatedError("جلسة غير صالحة.")

        if not verify_password(old_password, teacher.password_hash):
            raise AuthenticationError("كلمة المرور الحالية غير صحيحة.")

        _validate_password_strength(new_password)
        if verify_password(new_password, teacher.password_hash):
            raise ValidationError("كلمة المرور الجديدة يجب أن تختلف عن الحالية.")

        teacher.password_hash = hash_password(new_password)
        repo.update(teacher)
        logger.info("Password changed for teacher_id=%s.", teacher.id)
