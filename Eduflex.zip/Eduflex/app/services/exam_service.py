from __future__ import annotations

import datetime as dt

from app.database.session import session_scope
from app.models.exam import Exam, ExamResult
from app.repositories.exam_repository import ExamRepository
from app.repositories.student_repository import StudentRepository
from app.utils.exceptions import DuplicateError, NotFoundError, ValidationError
from app.utils.logger import get_logger
from app.utils.validators import require_non_empty, validate_non_negative_number

logger = get_logger(__name__)


def create_exam(
    *,
    name: str,
    subject: str,
    exam_date: dt.date,
    max_score: float,
    grade_level: str,
    notes: str | None = None,
) -> dict:
    name = require_non_empty(name, "اسم الاختبار")
    subject = require_non_empty(subject, "المادة")
    grade_level = require_non_empty(grade_level, "الصف الدراسي")
    max_score = validate_non_negative_number(max_score, "الدرجة النهائية")
    if max_score <= 0:
        raise ValidationError("الدرجة النهائية يجب أن تكون أكبر من صفر.")
    if exam_date is None:
        raise ValidationError("تاريخ الاختبار مطلوب.")

    with session_scope() as session:
        repo = ExamRepository(session)
        exam = Exam(
            name=name,
            subject=subject,
            exam_date=exam_date,
            max_score=max_score,
            grade_level=grade_level,
            notes=(notes or "").strip() or None,
        )
        repo.add(exam)
        logger.info("Created exam id=%s name=%s", exam.id, name)
        return _exam_to_dict(exam)


def update_exam(
    exam_id: int,
    *,
    name: str,
    subject: str,
    exam_date: dt.date,
    max_score: float,
    grade_level: str,
    notes: str | None = None,
) -> dict:
    name = require_non_empty(name, "اسم الاختبار")
    subject = require_non_empty(subject, "المادة")
    grade_level = require_non_empty(grade_level, "الصف الدراسي")
    max_score = validate_non_negative_number(max_score, "الدرجة النهائية")
    if max_score <= 0:
        raise ValidationError("الدرجة النهائية يجب أن تكون أكبر من صفر.")

    with session_scope() as session:
        repo = ExamRepository(session)
        exam = repo.get_by_id(exam_id)
        if exam is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")

        existing_results = repo.list_results_for_exam(exam_id)
        if existing_results and any(float(r.score) > max_score for r in existing_results):
            raise ValidationError(
                "لا يمكن تقليل الدرجة النهائية لأقل من درجة مسجلة بالفعل لأحد الطلاب."
            )

        exam.name = name
        exam.subject = subject
        exam.exam_date = exam_date
        exam.max_score = max_score
        exam.grade_level = grade_level
        exam.notes = (notes or "").strip() or None
        repo.update(exam)
        logger.info("Updated exam id=%s", exam_id)
        return _exam_to_dict(exam)


def delete_exam(exam_id: int) -> None:
    with session_scope() as session:
        repo = ExamRepository(session)
        exam = repo.get_by_id(exam_id)
        if exam is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")
        repo.delete(exam)
        logger.info("Deleted exam id=%s", exam_id)


def get_exam(exam_id: int) -> dict:
    with session_scope() as session:
        repo = ExamRepository(session)
        exam = repo.get_by_id(exam_id)
        if exam is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")
        return _exam_to_dict(exam)


def list_exams(grade_level: str | None = None, subject: str | None = None) -> list[dict]:
    with session_scope() as session:
        repo = ExamRepository(session)
        return [_exam_to_dict(e) for e in repo.list_all(grade_level=grade_level, subject=subject)]


def record_result(exam_id: int, student_id: int, score: float) -> dict:
    with session_scope() as session:
        exam_repo = ExamRepository(session)
        student_repo = StudentRepository(session)

        exam = exam_repo.get_by_id(exam_id)
        if exam is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")
        if student_repo.get_by_id(student_id) is None:
            raise NotFoundError("لم يتم العثور على الطالب.")

        score = validate_non_negative_number(score, "الدرجة")
        if score > float(exam.max_score):
            raise ValidationError(
                f"الدرجة لا يمكن أن تتجاوز الدرجة النهائية ({exam.max_score})."
            )

        if exam_repo.get_result(exam_id, student_id) is not None:
            raise DuplicateError("تم تسجيل نتيجة هذا الطالب لهذا الاختبار بالفعل.")

        result = ExamResult(exam_id=exam_id, student_id=student_id, score=score)
        exam_repo.add_result(result)
        logger.info("Recorded exam result exam_id=%s student_id=%s", exam_id, student_id)
        return _result_to_dict(result)


def update_result(exam_id: int, student_id: int, score: float) -> dict:
    with session_scope() as session:
        exam_repo = ExamRepository(session)
        exam = exam_repo.get_by_id(exam_id)
        if exam is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")

        score = validate_non_negative_number(score, "الدرجة")
        if score > float(exam.max_score):
            raise ValidationError(
                f"الدرجة لا يمكن أن تتجاوز الدرجة النهائية ({exam.max_score})."
            )

        result = exam_repo.get_result(exam_id, student_id)
        if result is None:
            raise NotFoundError("لا توجد نتيجة مسجلة لهذا الطالب في هذا الاختبار.")

        result.score = score
        exam_repo.update_result(result)
        logger.info("Updated exam result exam_id=%s student_id=%s", exam_id, student_id)
        return _result_to_dict(result)


def delete_result(exam_id: int, student_id: int) -> None:
    with session_scope() as session:
        exam_repo = ExamRepository(session)
        result = exam_repo.get_result(exam_id, student_id)
        if result is None:
            raise NotFoundError("لا توجد نتيجة مسجلة لهذا الطالب في هذا الاختبار.")
        exam_repo.delete_result(result)
        logger.info("Deleted exam result exam_id=%s student_id=%s", exam_id, student_id)


def list_results_for_exam(exam_id: int) -> list[dict]:
    with session_scope() as session:
        exam_repo = ExamRepository(session)
        if exam_repo.get_by_id(exam_id) is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")
        return [_result_to_dict(r) for r in exam_repo.list_results_for_exam(exam_id)]


def list_results_for_student(student_id: int) -> list[dict]:
    with session_scope() as session:
        exam_repo = ExamRepository(session)
        return [_result_to_dict(r) for r in exam_repo.list_results_for_student(student_id)]


def get_exam_statistics(exam_id: int) -> dict:
    with session_scope() as session:
        exam_repo = ExamRepository(session)
        exam = exam_repo.get_by_id(exam_id)
        if exam is None:
            raise NotFoundError("لم يتم العثور على الاختبار.")

        results = exam_repo.list_results_for_exam(exam_id)
        if not results:
            return {
                "exam_id": exam_id,
                "count": 0,
                "average": None,
                "highest": None,
                "lowest": None,
                "pass_rate": None,
            }

        scores = [float(r.score) for r in results]
        max_score = float(exam.max_score)
        passing = sum(1 for s in scores if s >= max_score * 0.5)

        return {
            "exam_id": exam_id,
            "count": len(scores),
            "average": round(sum(scores) / len(scores), 2),
            "highest": max(scores),
            "lowest": min(scores),
            "pass_rate": round(passing / len(scores) * 100, 1),
        }


def _exam_to_dict(exam: Exam) -> dict:
    return {
        "id": exam.id,
        "name": exam.name,
        "subject": exam.subject,
        "exam_date": exam.exam_date,
        "max_score": float(exam.max_score),
        "grade_level": exam.grade_level,
        "notes": exam.notes,
    }


def _result_to_dict(result: ExamResult) -> dict:
    return {
        "id": result.id,
        "exam_id": result.exam_id,
        "student_id": result.student_id,
        "score": float(result.score),
    }
