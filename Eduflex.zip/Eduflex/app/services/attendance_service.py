from __future__ import annotations

import datetime as dt

from app.database.session import session_scope
from app.models.attendance import Attendance, AttendanceSource, AttendanceStatus
from app.models.student import Student, StudentStatus
from app.repositories.attendance_repository import AttendanceRepository
from app.repositories.student_repository import StudentRepository
from app.services.subscription_service import (
    SubscriptionStatus,
    compute_status,
)
from app.repositories.subscription_repository import SubscriptionRepository
from app.utils.exceptions import AttendanceError, NotFoundError, ValidationError
from app.utils.logger import get_logger

logger = get_logger(__name__)


def _subscription_status_for(session, student_id: int) -> SubscriptionStatus | None:
    sub_repo = SubscriptionRepository(session)
    latest = sub_repo.get_latest_for_student(student_id)
    if latest is None:
        return None
    return compute_status(latest.end_date)


def _toggle_attendance(
    session,
    student: Student,
    *,
    source: AttendanceSource,
    class_id: int | None,
) -> dict:
    if student.status != StudentStatus.ACTIVE:
        raise AttendanceError("حالة الطالب غير نشطة، لا يمكن تسجيل الحضور.")

    attendance_repo = AttendanceRepository(session)
    today = dt.date.today()
    now = dt.datetime.now()

    existing = attendance_repo.get_for_student_on_date(student.id, today, class_id)

    if existing is None:
        record = Attendance(
            student_id=student.id,
            class_id=class_id,
            attendance_date=today,
            check_in_time=now,
            status=AttendanceStatus.PRESENT,
            source=source,
        )
        attendance_repo.add(record)
        action = "check_in"
        logger.info("Check-in recorded for student_id=%s via %s", student.id, source.value)
    elif existing.check_out_time is None:
        existing.check_out_time = now
        existing.status = AttendanceStatus.LEFT
        attendance_repo.update(existing)
        record = existing
        action = "check_out"
        logger.info("Check-out recorded for student_id=%s via %s", student.id, source.value)
    else:
        raise AttendanceError("تم تسجيل حضور وانصراف هذا الطالب بالفعل اليوم.")

    subscription_status = _subscription_status_for(session, student.id)

    return {
        "action": action,
        "attendance_id": record.id,
        "student_id": student.id,
        "student_code": student.student_code,
        "full_name": student.full_name,
        "check_in_time": record.check_in_time,
        "check_out_time": record.check_out_time,
        "status": record.status,
        "source": record.source,
        "subscription_status": subscription_status,
    }


def record_attendance_by_token(qr_token: str, class_id: int | None = None) -> dict:
    if not qr_token:
        raise ValidationError("رمز QR غير صالح.")

    with session_scope() as session:
        student_repo = StudentRepository(session)
        student = student_repo.get_by_qr_token(qr_token)
        if student is None:
            raise NotFoundError("رمز QR غير مرتبط بأي طالب.")

        return _toggle_attendance(session, student, source=AttendanceSource.QR, class_id=class_id)


def record_attendance_by_code(student_code: str, class_id: int | None = None) -> dict:
    if not student_code or not student_code.strip():
        raise ValidationError("معرف الطالب مطلوب.")

    with session_scope() as session:
        student_repo = StudentRepository(session)
        student = student_repo.get_by_code(student_code.strip())
        if student is None:
            raise NotFoundError("لا يوجد طالب بهذا المعرف.")

        return _toggle_attendance(session, student, source=AttendanceSource.MANUAL_ID, class_id=class_id)


def list_attendance_for_student(student_id: int) -> list[dict]:
    with session_scope() as session:
        repo = AttendanceRepository(session)
        return [_to_dict(a) for a in repo.list_for_student(student_id)]


def list_attendance_for_date(date: dt.date) -> list[dict]:
    with session_scope() as session:
        repo = AttendanceRepository(session)
        return [_to_dict(a) for a in repo.list_for_date(date)]


def list_recent_attendance(limit: int = 10) -> list[dict]:
    with session_scope() as session:
        repo = AttendanceRepository(session)
        return [_to_dict(a) for a in repo.list_recent(limit=limit)]


def get_today_summary() -> dict:
    with session_scope() as session:
        student_repo = StudentRepository(session)
        attendance_repo = AttendanceRepository(session)

        total_students = student_repo.count()
        present_today = attendance_repo.count_present_on_date(dt.date.today())
        absent_today = max(total_students - present_today, 0)
        rate = (present_today / total_students * 100) if total_students else 0.0

        return {
            "total_students": total_students,
            "present_today": present_today,
            "absent_today": absent_today,
            "attendance_rate": round(rate, 1),
        }


def _to_dict(attendance: Attendance) -> dict:
    return {
        "id": attendance.id,
        "student_id": attendance.student_id,
        "class_id": attendance.class_id,
        "attendance_date": attendance.attendance_date,
        "check_in_time": attendance.check_in_time,
        "check_out_time": attendance.check_out_time,
        "status": attendance.status,
        "source": attendance.source,
    }
