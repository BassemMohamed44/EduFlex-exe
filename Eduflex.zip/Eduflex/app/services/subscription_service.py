from __future__ import annotations

import datetime as dt
import enum

from app.config.settings import get_settings
from app.database.session import session_scope
from app.models.subscription import Subscription
from app.repositories.student_repository import StudentRepository
from app.repositories.subscription_repository import SubscriptionRepository
from app.utils.exceptions import NotFoundError, ValidationError
from app.utils.logger import get_logger
from app.utils.validators import validate_date_range, validate_non_negative_number

logger = get_logger(__name__)


class SubscriptionStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRING_SOON = "expiring_soon"
    EXPIRED = "expired"


def compute_status(end_date: dt.date, today: dt.date | None = None, warning_days: int | None = None) -> SubscriptionStatus:
    today = today or dt.date.today()
    warning_days = warning_days if warning_days is not None else get_settings().get(
        "subscription_warning_days", 7
    )

    if end_date < today:
        return SubscriptionStatus.EXPIRED
    if end_date <= today + dt.timedelta(days=warning_days):
        return SubscriptionStatus.EXPIRING_SOON
    return SubscriptionStatus.ACTIVE


def create_subscription(
    *, student_id: int, start_date: dt.date, end_date: dt.date, price: float = 0
) -> dict:
    validate_date_range(start_date, end_date)
    if start_date is None or end_date is None:
        raise ValidationError("تاريخ بداية ونهاية الاشتراك مطلوبان.")
    price = validate_non_negative_number(price, "سعر الاشتراك")

    with session_scope() as session:
        student_repo = StudentRepository(session)
        if student_repo.get_by_id(student_id) is None:
            raise NotFoundError("لم يتم العثور على الطالب.")

        sub_repo = SubscriptionRepository(session)
        subscription = Subscription(
            student_id=student_id, start_date=start_date, end_date=end_date, price=price
        )
        sub_repo.add(subscription)
        logger.info("Created subscription id=%s for student_id=%s", subscription.id, student_id)
        return _to_dict(subscription)


def update_subscription(
    subscription_id: int, *, start_date: dt.date, end_date: dt.date, price: float = 0
) -> dict:
    validate_date_range(start_date, end_date)
    price = validate_non_negative_number(price, "سعر الاشتراك")

    with session_scope() as session:
        sub_repo = SubscriptionRepository(session)
        subscription = sub_repo.get_by_id(subscription_id)
        if subscription is None:
            raise NotFoundError("لم يتم العثور على الاشتراك.")

        subscription.start_date = start_date
        subscription.end_date = end_date
        subscription.price = price
        sub_repo.update(subscription)
        logger.info("Updated subscription id=%s", subscription_id)
        return _to_dict(subscription)


def delete_subscription(subscription_id: int) -> None:
    with session_scope() as session:
        sub_repo = SubscriptionRepository(session)
        subscription = sub_repo.get_by_id(subscription_id)
        if subscription is None:
            raise NotFoundError("لم يتم العثور على الاشتراك.")
        sub_repo.delete(subscription)
        logger.info("Deleted subscription id=%s", subscription_id)


def list_subscriptions_for_student(student_id: int) -> list[dict]:
    with session_scope() as session:
        sub_repo = SubscriptionRepository(session)
        return [_to_dict(s) for s in sub_repo.list_for_student(student_id)]


def get_current_status_for_student(student_id: int) -> SubscriptionStatus | None:
    with session_scope() as session:
        sub_repo = SubscriptionRepository(session)
        latest = sub_repo.get_latest_for_student(student_id)
        if latest is None:
            return None
        return compute_status(latest.end_date)


def list_expired_subscriptions() -> list[dict]:
    with session_scope() as session:
        sub_repo = SubscriptionRepository(session)
        today = dt.date.today()
        result = []
        for sub in sub_repo.list_all_latest_per_student():
            if compute_status(sub.end_date, today) == SubscriptionStatus.EXPIRED:
                result.append(_to_dict(sub))
        return result


def list_expiring_soon_subscriptions() -> list[dict]:
    with session_scope() as session:
        sub_repo = SubscriptionRepository(session)
        today = dt.date.today()
        result = []
        for sub in sub_repo.list_all_latest_per_student():
            if compute_status(sub.end_date, today) == SubscriptionStatus.EXPIRING_SOON:
                result.append(_to_dict(sub))
        return result


def _to_dict(subscription: Subscription) -> dict:
    return {
        "id": subscription.id,
        "student_id": subscription.student_id,
        "start_date": subscription.start_date,
        "end_date": subscription.end_date,
        "price": float(subscription.price),
        "status": compute_status(subscription.end_date),
    }
