from __future__ import annotations

import datetime as dt
import shutil
import sqlite3
from pathlib import Path

from app.config.settings import get_paths, get_settings
from app.database.session import get_engine, rebind_engine
from app.utils.exceptions import BackupError
from app.utils.logger import get_logger

logger = get_logger(__name__)

BACKUP_FILENAME_FORMAT = "eduflex_backup_%Y%m%d_%H%M%S_%f.db"
PRE_RESTORE_PREFIX = "pre_restore_auto_"


def _checkpoint_wal() -> None:
    engine = get_engine()
    with engine.connect() as conn:
        conn.exec_driver_sql("PRAGMA wal_checkpoint(FULL)")


def create_backup(destination_dir: str | None = None) -> dict:
    try:
        _checkpoint_wal()

        source = get_paths().database_file
        if not source.exists():
            raise BackupError("لم يتم العثور على قاعدة البيانات لعمل نسخة احتياطية منها.")

        target_dir = Path(destination_dir) if destination_dir else get_paths().backups_dir
        target_dir.mkdir(parents=True, exist_ok=True)

        timestamp = dt.datetime.now()
        filename = timestamp.strftime(BACKUP_FILENAME_FORMAT)
        target_path = target_dir / filename

        counter = 1
        while target_path.exists():
            target_path = target_dir / f"{target_path.stem}_{counter}{target_path.suffix}"
            counter += 1

        shutil.copy2(source, target_path)

        settings = get_settings()
        settings.set("last_backup_path", str(target_path))
        settings.set("last_backup_at", timestamp.isoformat())

        logger.info("Backup created at %s", target_path)
        return {"path": str(target_path), "created_at": timestamp}
    except BackupError:
        raise
    except Exception as exc:
        logger.error("Backup creation failed: %s", exc)
        raise BackupError("تعذر إنشاء نسخة احتياطية.") from exc


def get_last_backup_info() -> dict | None:
    settings = get_settings()
    path = settings.get("last_backup_path")
    created_at = settings.get("last_backup_at")
    if not path:
        return None
    return {
        "path": path,
        "created_at": dt.datetime.fromisoformat(created_at) if created_at else None,
        "exists": Path(path).exists(),
    }


def list_available_backups() -> list[dict]:
    backups_dir = get_paths().backups_dir
    entries = []
    for file in backups_dir.glob("*.db"):
        entries.append(
            {
                "path": str(file),
                "filename": file.name,
                "modified_at": dt.datetime.fromtimestamp(file.stat().st_mtime),
                "size_bytes": file.stat().st_size,
            }
        )
    return sorted(entries, key=lambda e: e["modified_at"], reverse=True)


def _validate_backup_file(backup_path: Path) -> None:
    if not backup_path.exists():
        raise BackupError("ملف النسخة الاحتياطية غير موجود.")
    try:
        conn = sqlite3.connect(str(backup_path))
        try:
            conn.execute("PRAGMA integrity_check").fetchone()
            tables = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='students'"
            ).fetchall()
            if not tables:
                raise BackupError("الملف المحدد ليس نسخة احتياطية صالحة لبرنامج Eduflex.")
        finally:
            conn.close()
    except sqlite3.DatabaseError as exc:
        raise BackupError("الملف المحدد تالف أو ليس قاعدة بيانات صالحة.") from exc


def restore_backup(backup_path: str) -> dict:
    source = Path(backup_path)
    _validate_backup_file(source)

    try:
        pre_restore = create_backup()
        logger.info("Pre-restore safety backup created at %s", pre_restore["path"])

        live_db_path = get_paths().database_file

        engine = get_engine()
        engine.dispose()

        shutil.copy2(source, live_db_path)
        for suffix in ("-wal", "-shm"):
            stale = Path(str(live_db_path) + suffix)
            if stale.exists():
                stale.unlink()

        rebind_engine(live_db_path)

        logger.info("Database restored from %s", source)
        return {"restored_from": str(source), "pre_restore_backup": pre_restore["path"]}
    except BackupError:
        raise
    except Exception as exc:
        logger.error("Restore failed: %s", exc)
        raise BackupError("تعذرت استعادة النسخة الاحتياطية.") from exc
