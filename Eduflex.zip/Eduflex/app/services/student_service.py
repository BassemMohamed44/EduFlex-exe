from __future__ import annotations

import datetime as dt

from app.database.session import session_scope
from app.models.student import Student, StudentStatus
from app.repositories.student_repository import StudentRepository
from app.utils.exceptions import DuplicateError, NotFoundError, ValidationError
from app.utils.logger import get_logger
from app.utils.student_code_generator import (
    MAX_GENERATION_ATTEMPTS,
    ensure_capacity_available,
    generate_candidate_code,
)
from app.utils.validators import (
    require_non_empty,
    validate_date_range,
    validate_non_negative_number,
    validate_phone,
)

logger = get_logger(__name__)


def _generate_unique_student_code(repo: StudentRepository) -> str:
    ensure_capacity_available(repo.count())

    for _ in range(MAX_GENERATION_ATTEMPTS):
        candidate = generate_candidate_code()
        if not repo.code_exists(candidate):
            return candidate

    raise ValidationError(
        "تعذر إنشاء معرف طالب فريد بعد عدة محاولات، برجاء المحاولة مرة أخرى."
    )


def _validate_student_fields(
    full_name: str,
    grade_level: str,
    subscription_price,
    student_phone: str | None,
    guardian_phone: str | None,
    subscription_start: dt.date | None,
    subscription_end: dt.date | None,
) -> tuple[str, str, float, str | None, str | None]:
    full_name = require_non_empty(full_name, "اسم الطالب")
    grade_level = require_non_empty(grade_level, "الصف الدراسي")
    price = validate_non_negative_number(subscription_price, "سعر الاشتراك")
    student_phone = validate_phone(student_phone, "رقم الطالب")
    guardian_phone = validate_phone(guardian_phone, "رقم ولي الأمر")
    validate_date_range(subscription_start, subscription_end)
    return full_name, grade_level, price, student_phone, guardian_phone


def create_student(
    *,
    full_name: str,
    grade_level: str,
    lesson_time: str | None = None,
    subscription_price: float = 0,
    center_name: str | None = None,
    student_phone: str | None = None,
    guardian_phone: str | None = None,
    subscription_start: dt.date | None = None,
    subscription_end: dt.date | None = None,
) -> dict:
    full_name, grade_level, price, student_phone, guardian_phone = _validate_student_fields(
        full_name,
        grade_level,
        subscription_price,
        student_phone,
        guardian_phone,
        subscription_start,
        subscription_end,
    )

    with session_scope() as session:
        repo = StudentRepository(session)
        code = _generate_unique_student_code(repo)

        student = Student(
            student_code=code,
            full_name=full_name,
            grade_level=grade_level,
            lesson_time=(lesson_time or "").strip() or None,
            subscription_price=price,
            center_name=(center_name or "").strip() or None,
            student_phone=student_phone,
            guardian_phone=guardian_phone,
            subscription_start=subscription_start,
            subscription_end=subscription_end,
            status=StudentStatus.ACTIVE,
        )
        repo.add(student)
        logger.info("Created student id=%s code=%s", student.id, student.student_code)
        return _to_dict(student)


def update_student(
    student_id: int,
    *,
    full_name: str,
    grade_level: str,
    lesson_time: str | None = None,
    subscription_price: float = 0,
    center_name: str | None = None,
    student_phone: str | None = None,
    guardian_phone: str | None = None,
    subscription_start: dt.date | None = None,
    subscription_end: dt.date | None = None,
    status: StudentStatus | None = None,
) -> dict:
    full_name, grade_level, price, student_phone, guardian_phone = _validate_student_fields(
        full_name,
        grade_level,
        subscription_price,
        student_phone,
        guardian_phone,
        subscription_start,
        subscription_end,
    )

    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError("لم يتم العثور على الطالب.")

        student.full_name = full_name
        student.grade_level = grade_level
        student.lesson_time = (lesson_time or "").strip() or None
        student.subscription_price = price
        student.center_name = (center_name or "").strip() or None
        student.student_phone = student_phone
        student.guardian_phone = guardian_phone
        student.subscription_start = subscription_start
        student.subscription_end = subscription_end
        if status is not None:
            student.status = status

        repo.update(student)
        logger.info("Updated student id=%s", student.id)
        return _to_dict(student)


def delete_student(student_id: int) -> None:
    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError("لم يتم العثور على الطالب.")
        code = student.student_code
        repo.delete(student)
        logger.info("Deleted student id=%s code=%s", student_id, code)


def get_student(student_id: int) -> dict:
    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError("لم يتم العثور على الطالب.")
        return _to_dict(student)


def get_student_by_code(student_code: str) -> dict:
    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_code(student_code)
        if student is None:
            raise NotFoundError("لا يوجد طالب بهذا المعرف.")
        return _to_dict(student)


def search_students(
    *,
    text: str | None = None,
    grade_level: str | None = None,
    center_name: str | None = None,
    status: StudentStatus | None = None,
    sort_by: str = "full_name",
    sort_desc: bool = False,
) -> list[dict]:
    with session_scope() as session:
        repo = StudentRepository(session)
        students = repo.search(
            text=text,
            grade_level=grade_level,
            center_name=center_name,
            status=status,
            sort_by=sort_by,
            sort_desc=sort_desc,
        )
        return [_to_dict(s) for s in students]


def list_students() -> list[dict]:
    with session_scope() as session:
        repo = StudentRepository(session)
        return [_to_dict(s) for s in repo.list_all()]


def _to_dict(student: Student) -> dict:
    return {
        "id": student.id,
        "student_code": student.student_code,
        "full_name": student.full_name,
        "grade_level": student.grade_level,
        "lesson_time": student.lesson_time,
        "subscription_price": float(student.subscription_price),
        "center_name": student.center_name,
        "student_phone": student.student_phone,
        "guardian_phone": student.guardian_phone,
        "subscription_start": student.subscription_start,
        "subscription_end": student.subscription_end,
        "status": student.status,
        "qr_token": student.qr_token,
    }
