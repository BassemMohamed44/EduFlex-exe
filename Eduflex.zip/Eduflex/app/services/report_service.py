from __future__ import annotations

import datetime as dt

from app.database.session import session_scope
from app.models.attendance import Attendance, AttendanceStatus
from app.models.student import Student
from app.repositories.attendance_repository import AttendanceRepository
from app.repositories.student_repository import StudentRepository
from app.services import exam_service, subscription_service
from app.services.subscription_service import SubscriptionStatus
from app.utils.logger import get_logger

logger = get_logger(__name__)


def attendance_totals_report() -> list[dict]:
    with session_scope() as session:
        student_repo = StudentRepository(session)
        attendance_repo = AttendanceRepository(session)

        students = student_repo.list_all()

        all_dates = {
            row.attendance_date
            for row in session.query(Attendance.attendance_date).distinct().all()
        }
        total_operating_days = len(all_dates)

        result = []
        for student in students:
            records = attendance_repo.list_for_student(student.id)
            present_days = {r.attendance_date for r in records}
            present_count = len(present_days)
            absent_count = max(total_operating_days - present_count, 0)
            result.append(
                {
                    "student_id": student.id,
                    "student_code": student.student_code,
                    "full_name": student.full_name,
                    "present_count": present_count,
                    "absent_count": absent_count,
                    "total_operating_days": total_operating_days,
                }
            )
        return result


def daily_attendance_report(date: dt.date) -> list[dict]:
    with session_scope() as session:
        attendance_repo = AttendanceRepository(session)
        records = attendance_repo.list_for_date(date)
        result = []
        for r in records:
            result.append(
                {
                    "student_id": r.student_id,
                    "full_name": r.student.full_name,
                    "student_code": r.student.student_code,
                    "date": r.attendance_date,
                    "status": r.status,
                    "check_in_time": r.check_in_time,
                    "check_out_time": r.check_out_time,
                }
            )
        return result


def exam_results_report(exam_id: int) -> dict:
    results = exam_service.list_results_for_exam(exam_id)
    exam = exam_service.get_exam(exam_id)
    stats = exam_service.get_exam_statistics(exam_id)

    with session_scope() as session:
        student_repo = StudentRepository(session)
        detailed = []
        for r in results:
            student = student_repo.get_by_id(r["student_id"])
            detailed.append(
                {
                    "student_id": r["student_id"],
                    "full_name": student.full_name if student else "-",
                    "student_code": student.student_code if student else "-",
                    "score": r["score"],
                    "max_score": exam["max_score"],
                }
            )

    return {"exam": exam, "results": detailed, "statistics": stats}


def expired_subscriptions_report() -> list[dict]:
    expired = subscription_service.list_expired_subscriptions()
    with session_scope() as session:
        student_repo = StudentRepository(session)
        result = []
        for sub in expired:
            student = student_repo.get_by_id(sub["student_id"])
            result.append(
                {
                    "student_id": sub["student_id"],
                    "full_name": student.full_name if student else "-",
                    "student_code": student.student_code if student else "-",
                    "end_date": sub["end_date"],
                    "price": sub["price"],
                }
            )
        return result


def comprehensive_statistics_report() -> dict:
    with session_scope() as session:
        student_repo = StudentRepository(session)
        total_students = student_repo.count()

    from app.services.attendance_service import get_today_summary

    today_summary = get_today_summary()

    with session_scope() as session:
        from app.repositories.subscription_repository import SubscriptionRepository
        from app.models.exam import ExamResult

        sub_repo = SubscriptionRepository(session)
        latest_subs = sub_repo.list_all_latest_per_student()
        active_count = sum(
            1
            for s in latest_subs
            if subscription_service.compute_status(s.end_date) == SubscriptionStatus.ACTIVE
        )
        expired_count = sum(
            1
            for s in latest_subs
            if subscription_service.compute_status(s.end_date) == SubscriptionStatus.EXPIRED
        )

        all_scores = [float(r.score) for r in session.query(ExamResult).all()]
        all_max_scores = []
        from app.models.exam import Exam

        exam_max_by_id = {e.id: float(e.max_score) for e in session.query(Exam).all()}
        exam_results = session.query(ExamResult).all()
        percentage_scores = [
            (float(r.score) / exam_max_by_id[r.exam_id] * 100)
            for r in exam_results
            if r.exam_id in exam_max_by_id and exam_max_by_id[r.exam_id] > 0
        ]
        avg_exam_score_pct = (
            round(sum(percentage_scores) / len(percentage_scores), 1) if percentage_scores else None
        )

    return {
        "number_of_students": total_students,
        "attendance_rate": today_summary["attendance_rate"],
        "absence_rate": round(100 - today_summary["attendance_rate"], 1) if total_students else 0.0,
        "average_exam_score_percent": avg_exam_score_pct,
        "active_subscriptions": active_count,
        "expired_subscriptions": expired_count,
    }
