from __future__ import annotations

from app.database.session import session_scope
from app.repositories.teacher_repository import TeacherRepository
from app.utils.exceptions import NotFoundError, ValidationError
from app.utils.logger import get_logger

logger = get_logger(__name__)


def update_profile(teacher_id: int, full_name: str, subject: str) -> None:
    full_name = (full_name or "").strip()
    subject = (subject or "").strip()
    if not full_name:
        raise ValidationError("اسم المدرس مطلوب.")
    if not subject:
        raise ValidationError("المادة العلمية مطلوبة.")

    with session_scope() as session:
        repo = TeacherRepository(session)
        teacher = repo.get_by_id(teacher_id)
        if teacher is None:
            raise NotFoundError("لم يتم العثور على حساب المدرس.")

        existing = repo.get_by_name(full_name)
        if existing is not None and existing.id != teacher_id:
            raise ValidationError("يوجد حساب آخر بنفس الاسم.")

        teacher.full_name = full_name
        teacher.subject = subject
        repo.update(teacher)
        logger.info("Updated profile for teacher_id=%s.", teacher_id)


def get_profile(teacher_id: int):
    with session_scope() as session:
        repo = TeacherRepository(session)
        teacher = repo.get_by_id(teacher_id)
        if teacher is None:
            raise NotFoundError("لم يتم العثور على حساب المدرس.")
        return {
            "id": teacher.id,
            "full_name": teacher.full_name,
            "subject": teacher.subject,
            "is_active": teacher.is_active,
        }
