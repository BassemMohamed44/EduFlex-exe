from __future__ import annotations

import datetime as dt

from app.reports.excel_report import export_table_to_excel
from app.reports.pdf_report import export_table_to_pdf
from app.services import report_service
from app.utils.exceptions import ValidationError

_STATUS_LABELS_AR = {"present": "حاضر", "left": "انصرف", "absent": "غائب"}


def _export(fmt: str, *, title: str, headers, rows, destination: str) -> str:
    fmt = (fmt or "").lower()
    if fmt == "pdf":
        return export_table_to_pdf(title=title, headers=headers, rows=rows, destination=destination)
    if fmt == "excel":
        return export_table_to_excel(title=title, headers=headers, rows=rows, destination=destination)
    raise ValidationError("صيغة التصدير غير مدعومة (pdf أو excel فقط).")


def export_attendance_totals(fmt: str, destination: str) -> str:
    data = report_service.attendance_totals_report()
    headers = ["معرف الطالب", "الاسم", "أيام الحضور", "أيام الغياب"]
    rows = [(d["student_code"], d["full_name"], d["present_count"], d["absent_count"]) for d in data]
    return _export(fmt, title="إجمالي الحضور والغياب", headers=headers, rows=rows, destination=destination)


def export_daily_attendance(date: dt.date, fmt: str, destination: str) -> str:
    data = report_service.daily_attendance_report(date)
    headers = ["معرف الطالب", "الاسم", "الحالة", "وقت الحضور", "وقت الخروج"]
    rows = [
        (
            d["student_code"],
            d["full_name"],
            _STATUS_LABELS_AR.get(d["status"].value, d["status"].value),
            d["check_in_time"].strftime("%H:%M") if d["check_in_time"] else "-",
            d["check_out_time"].strftime("%H:%M") if d["check_out_time"] else "-",
        )
        for d in data
    ]
    title = f"الحضور اليومي - {date.isoformat()}"
    return _export(fmt, title=title, headers=headers, rows=rows, destination=destination)


def export_exam_results(exam_id: int, fmt: str, destination: str) -> str:
    data = report_service.exam_results_report(exam_id)
    headers = ["معرف الطالب", "الاسم", "الدرجة", "الدرجة النهائية"]
    rows = [(r["student_code"], r["full_name"], r["score"], r["max_score"]) for r in data["results"]]
    title = f"نتائج اختبار - {data['exam']['name']}"
    return _export(fmt, title=title, headers=headers, rows=rows, destination=destination)


def export_expired_subscriptions(fmt: str, destination: str) -> str:
    data = report_service.expired_subscriptions_report()
    headers = ["معرف الطالب", "الاسم", "تاريخ الانتهاء", "السعر"]
    rows = [(d["student_code"], d["full_name"], d["end_date"].isoformat(), d["price"]) for d in data]
    return _export(fmt, title="الاشتراكات المنتهية", headers=headers, rows=rows, destination=destination)


def export_comprehensive_statistics(fmt: str, destination: str) -> str:
    data = report_service.comprehensive_statistics_report()
    headers = ["المؤشر", "القيمة"]
    rows = [
        ("عدد الطلاب", data["number_of_students"]),
        ("نسبة الحضور اليوم (%)", data["attendance_rate"]),
        ("نسبة الغياب اليوم (%)", data["absence_rate"]),
        ("متوسط درجات الاختبارات (%)", data["average_exam_score_percent"] or "-"),
        ("الاشتراكات النشطة", data["active_subscriptions"]),
        ("الاشتراكات المنتهية", data["expired_subscriptions"]),
    ]
    return _export(fmt, title="الإحصائيات الشاملة", headers=headers, rows=rows, destination=destination)
