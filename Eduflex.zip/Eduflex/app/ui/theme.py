from __future__ import annotations

COLOR_PRIMARY = "#2C3E50"
COLOR_PRIMARY_LIGHT = "#34495E"
COLOR_ACCENT = "#2E86DE"
COLOR_ACCENT_HOVER = "#256FB8"
COLOR_SUCCESS = "#27AE60"
COLOR_WARNING = "#F39C12"
COLOR_DANGER = "#E74C3C"

COLOR_BG = "#F5F6FA"
COLOR_SURFACE = "#FFFFFF"
COLOR_BORDER = "#E1E4E8"

COLOR_TEXT_PRIMARY = "#1B2531"
COLOR_TEXT_SECONDARY = "#6B7280"
COLOR_TEXT_ON_DARK = "#FFFFFF"
COLOR_TEXT_MUTED_ON_DARK = "#AEB6C2"

FONT_FAMILY = "Cairo, Tahoma, Arial"
FONT_SIZE_BASE = 14
FONT_SIZE_SMALL = 12
FONT_SIZE_LARGE = 18
FONT_SIZE_TITLE = 24

SPACING_XS = 4
SPACING_SM = 8
SPACING_MD = 16
SPACING_LG = 24
SPACING_XL = 32

RADIUS = 10
SIDEBAR_WIDTH = 220


def force_light_palette(app) -> None:
    from PySide6.QtGui import QColor, QPalette

    app.setStyle("Fusion")
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(COLOR_BG))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(COLOR_TEXT_PRIMARY))
    palette.setColor(QPalette.ColorRole.Base, QColor(COLOR_SURFACE))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor(COLOR_BG))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(COLOR_SURFACE))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor(COLOR_TEXT_PRIMARY))
    palette.setColor(QPalette.ColorRole.Text, QColor(COLOR_TEXT_PRIMARY))
    palette.setColor(QPalette.ColorRole.Button, QColor(COLOR_SURFACE))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(COLOR_TEXT_PRIMARY))
    palette.setColor(QPalette.ColorRole.BrightText, QColor(COLOR_DANGER))
    palette.setColor(QPalette.ColorRole.Link, QColor(COLOR_ACCENT))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(COLOR_ACCENT))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor(COLOR_TEXT_ON_DARK))
    palette.setColor(QPalette.ColorRole.PlaceholderText, QColor(COLOR_TEXT_SECONDARY))

    disabled_text = QColor(COLOR_TEXT_SECONDARY)
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, disabled_text)
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, disabled_text)
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, disabled_text)

    app.setPalette(palette)


def app_stylesheet() -> str:
    return f"""
    * {{
        font-family: {FONT_FAMILY};
        font-size: {FONT_SIZE_BASE}px;
        color: {COLOR_TEXT_PRIMARY};
    }}

    QMainWindow, QWidget#centralWidget {{
        background-color: {COLOR_BG};
    }}

    QPushButton {{
        background-color: {COLOR_ACCENT};
        color: {COLOR_TEXT_ON_DARK};
        border: none;
        border-radius: {RADIUS}px;
        padding: 10px 18px;
        font-weight: 600;
    }}
    QPushButton:hover {{
        background-color: {COLOR_ACCENT_HOVER};
    }}
    QPushButton:disabled {{
        background-color: #B0BEC5;
    }}
    QPushButton#secondaryButton {{
        background-color: {COLOR_SURFACE};
        color: {COLOR_ACCENT};
        border: 1px solid {COLOR_ACCENT};
    }}
    QPushButton#dangerButton {{
        background-color: {COLOR_DANGER};
    }}

    QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QTextEdit {{
        background-color: {COLOR_SURFACE};
        border: 1px solid {COLOR_BORDER};
        border-radius: 8px;
        padding: 8px 10px;
        selection-background-color: {COLOR_ACCENT};
    }}
    QLineEdit:focus, QComboBox:focus {{
        border: 1px solid {COLOR_ACCENT};
    }}

    QLabel#pageTitle {{
        font-size: {FONT_SIZE_TITLE}px;
        font-weight: 700;
    }}
    QLabel#cardValue {{
        font-size: 28px;
        font-weight: 700;
        color: {COLOR_ACCENT};
    }}
    QLabel#cardLabel {{
        color: {COLOR_TEXT_SECONDARY};
        font-size: {FONT_SIZE_SMALL}px;
    }}
    QLabel#errorLabel {{
        color: {COLOR_DANGER};
        font-size: {FONT_SIZE_SMALL}px;
    }}

    QFrame#card {{
        background-color: {COLOR_SURFACE};
        border-radius: {RADIUS}px;
        border: 1px solid {COLOR_BORDER};
    }}

    QFrame#sidebar {{
        background-color: {COLOR_PRIMARY};
    }}
    QPushButton#sidebarButton {{
        background-color: transparent;
        color: {COLOR_TEXT_MUTED_ON_DARK};
        text-align: left;
        border-radius: 8px;
        padding: 12px 16px;
        font-weight: 500;
    }}
    QPushButton#sidebarButton:hover {{
        background-color: {COLOR_PRIMARY_LIGHT};
        color: {COLOR_TEXT_ON_DARK};
    }}
    QPushButton#sidebarButtonActive {{
        background-color: {COLOR_ACCENT};
        color: {COLOR_TEXT_ON_DARK};
        text-align: left;
        border-radius: 8px;
        padding: 12px 16px;
        font-weight: 700;
    }}

    QLabel#formLabel {{
        background-color: #02C4EF;
        color: {COLOR_TEXT_ON_DARK};
        padding: 10px 16px;
        border-radius: 8px;
        font-weight: 700;
    }}

    QTableWidget {{
        background-color: {COLOR_SURFACE};
        border: 1px solid {COLOR_BORDER};
        border-radius: {RADIUS}px;
        gridline-color: {COLOR_BORDER};
    }}
    QHeaderView::section {{
        background-color: #02C4EF;
        color: {COLOR_TEXT_ON_DARK};
        padding: 10px;
        border: none;
        border-radius: 8px;
        margin: 2px;
        font-weight: 700;
        text-align: center;
    }}
    """
