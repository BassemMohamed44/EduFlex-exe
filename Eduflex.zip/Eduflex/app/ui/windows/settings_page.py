from __future__ import annotations

from PySide6.QtWidgets import (
    QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QVBoxLayout, QWidget,
)

from app.services import auth_service, teacher_service
from app.licensing import license_service
from app.ui.dialogs.renew_license_dialog import RenewLicenseDialog
from app.ui.helpers import show_error, show_info
from app.utils.exceptions import EduflexError

_PLAN_LABELS = {"monthly": "شهري", "yearly": "سنوي"}


class SettingsPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(24)

        title = QLabel("الإعدادات")
        title.setObjectName("pageTitle")
        layout.addWidget(title)

        profile_label = QLabel("بيانات المدرس")
        profile_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        layout.addWidget(profile_label)

        profile_form = QFormLayout()
        self.name_input = QLineEdit()
        profile_form.addRow("اسم المدرس", self.name_input)
        self.subject_input = QLineEdit()
        profile_form.addRow("المادة العلمية", self.subject_input)
        layout.addLayout(profile_form)

        self.profile_error = QLabel("")
        self.profile_error.setObjectName("errorLabel")
        layout.addWidget(self.profile_error)

        save_profile_btn = QPushButton("حفظ البيانات")
        save_profile_btn.clicked.connect(self._on_save_profile)
        layout.addWidget(save_profile_btn)

        password_label = QLabel("تغيير كلمة المرور")
        password_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        layout.addWidget(password_label)

        password_form = QFormLayout()
        self.old_password_input = QLineEdit()
        self.old_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        password_form.addRow("كلمة المرور الحالية", self.old_password_input)
        self.new_password_input = QLineEdit()
        self.new_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        password_form.addRow("كلمة المرور الجديدة", self.new_password_input)
        layout.addLayout(password_form)

        self.password_error = QLabel("")
        self.password_error.setObjectName("errorLabel")
        layout.addWidget(self.password_error)

        change_password_btn = QPushButton("تغيير كلمة المرور")
        change_password_btn.clicked.connect(self._on_change_password)
        layout.addWidget(change_password_btn)

        license_label = QLabel("الترخيص")
        license_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        layout.addWidget(license_label)

        self.license_status_label = QLabel("")
        layout.addWidget(self.license_status_label)

        renew_btn = QPushButton("تجديد / تفعيل الترخيص")
        renew_btn.setObjectName("secondaryButton")
        renew_btn.clicked.connect(self._on_renew_license)
        layout.addWidget(renew_btn)

        layout.addStretch()

    def refresh(self) -> None:
        try:
            profile = teacher_service.get_profile(auth_service.current_session.teacher_id)
        except EduflexError as exc:
            show_error(self, exc)
            return
        self.name_input.setText(profile["full_name"])
        self.subject_input.setText(profile["subject"])
        self._refresh_license_status()

    def _refresh_license_status(self) -> None:
        status = license_service.get_status()
        if not status.get("valid"):
            self.license_status_label.setText("الترخيص غير مفعّل أو منتهي.")
            return
        plan = _PLAN_LABELS.get(status.get("plan"), status.get("plan"))
        remaining = status.get("remaining_days", 0)
        self.license_status_label.setText(f"الباقة: {plan} - الأيام المتبقية: {remaining}")

    def _on_renew_license(self) -> None:
        dialog = RenewLicenseDialog(self)
        if dialog.exec():
            self._refresh_license_status()
            show_info(self, "تم تفعيل الترخيص بنجاح.")

    def _on_save_profile(self) -> None:
        self.profile_error.setText("")
        try:
            teacher_service.update_profile(
                auth_service.current_session.teacher_id,
                self.name_input.text(),
                self.subject_input.text(),
            )
            show_info(self, "تم حفظ البيانات بنجاح.")
        except EduflexError as exc:
            self.profile_error.setText(str(exc))

    def _on_change_password(self) -> None:
        self.password_error.setText("")
        try:
            auth_service.change_password(
                self.old_password_input.text(), self.new_password_input.text()
            )
            self.old_password_input.clear()
            self.new_password_input.clear()
            show_info(self, "تم تغيير كلمة المرور بنجاح.")
        except EduflexError as exc:
            self.password_error.setText(str(exc))
