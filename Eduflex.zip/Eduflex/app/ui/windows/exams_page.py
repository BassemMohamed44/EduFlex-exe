from __future__ import annotations

from PySide6.QtCore import Qt

from PySide6.QtWidgets import (
    QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.services import exam_service
from app.ui.dialogs.exam_dialog import ExamDialog
from app.ui.dialogs.exam_results_dialog import ExamResultsDialog
from app.ui.helpers import confirm, show_error, show_info
from app.utils.exceptions import EduflexError

_COLUMNS = ["الاسم", "المادة", "الصف", "التاريخ", "الدرجة النهائية"]


class ExamsPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._rows: list[dict] = []
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        header = QHBoxLayout()
        title = QLabel("إدارة الاختبارات")
        title.setObjectName("pageTitle")
        header.addWidget(title)
        header.addStretch()
        self.add_button = QPushButton("+ إضافة اختبار")
        self.add_button.clicked.connect(self._on_add)
        header.addWidget(self.add_button)
        layout.addLayout(header)

        self.table = QTableWidget(0, len(_COLUMNS))
        self.table.setHorizontalHeaderLabels(_COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.table)

        actions = QHBoxLayout()
        self.edit_button = QPushButton("تعديل")
        self.edit_button.clicked.connect(self._on_edit_selected)
        self.results_button = QPushButton("تسجيل الدرجات")
        self.results_button.setObjectName("secondaryButton")
        self.results_button.clicked.connect(self._on_manage_results)
        self.delete_button = QPushButton("حذف")
        self.delete_button.setObjectName("dangerButton")
        self.delete_button.clicked.connect(self._on_delete_selected)
        actions.addWidget(self.edit_button)
        actions.addWidget(self.results_button)
        actions.addWidget(self.delete_button)
        actions.addStretch()
        layout.addLayout(actions)

    def refresh(self) -> None:
        try:
            exams = exam_service.list_exams()
        except EduflexError as exc:
            show_error(self, exc)
            return
        self._rows = exams
        self.table.setRowCount(len(exams))
        for row, e in enumerate(exams):
            self.table.setItem(row, 0, QTableWidgetItem(e["name"]))
            self.table.setItem(row, 1, QTableWidgetItem(e["subject"]))
            self.table.setItem(row, 2, QTableWidgetItem(e["grade_level"]))
            self.table.setItem(row, 3, QTableWidgetItem(e["exam_date"].isoformat()))
            self.table.setItem(row, 4, QTableWidgetItem(str(e["max_score"])))

    def _selected(self) -> dict | None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        return self._rows[rows[0].row()]

    def _on_add(self) -> None:
        if ExamDialog(self).exec():
            self.refresh()

    def _on_edit_selected(self) -> None:
        e = self._selected()
        if e is None:
            show_info(self, "الرجاء اختيار اختبار من الجدول أولًا.", "لم يتم الاختيار")
            return
        if ExamDialog(self, exam=e).exec():
            self.refresh()

    def _on_manage_results(self) -> None:
        e = self._selected()
        if e is None:
            show_info(self, "الرجاء اختيار اختبار من الجدول أولًا.", "لم يتم الاختيار")
            return
        ExamResultsDialog(self, e).exec()

    def _on_delete_selected(self) -> None:
        e = self._selected()
        if e is None:
            show_info(self, "الرجاء اختيار اختبار من الجدول أولًا.", "لم يتم الاختيار")
            return
        if not confirm(self, f"سيتم حذف اختبار '{e['name']}' وكل نتائجه. متابعة؟", "تأكيد الحذف"):
            return
        try:
            exam_service.delete_exam(e["id"])
            self.refresh()
        except EduflexError as exc:
            show_error(self, exc)
