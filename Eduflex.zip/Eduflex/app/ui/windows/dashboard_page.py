from __future__ import annotations

import datetime as dt

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.services import attendance_service, class_service, exam_service, subscription_service
from app.ui.widgets.stat_card import StatCard

_WEEKDAY_AR = {
    0: "الاثنين", 1: "الثلاثاء", 2: "الأربعاء", 3: "الخميس",
    4: "الجمعة", 5: "السبت", 6: "الأحد",
}


class DashboardPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(20)

        title = QLabel("لوحة التحكم")
        title.setObjectName("pageTitle")
        layout.addWidget(title)

        grid = QGridLayout()
        grid.setSpacing(16)

        self.card_total_students = StatCard("-", "إجمالي عدد الطلاب")
        self.card_present_today = StatCard("-", "الحاضرون اليوم")
        self.card_absent_today = StatCard("-", "الغائبون اليوم")
        self.card_attendance_rate = StatCard("-", "نسبة الحضور")
        self.card_expired_subs = StatCard("-", "اشتراكات منتهية")
        self.card_exam_count = StatCard("-", "عدد الاختبارات")

        cards = [
            self.card_total_students,
            self.card_present_today,
            self.card_absent_today,
            self.card_attendance_rate,
            self.card_expired_subs,
            self.card_exam_count,
        ]
        for i, card in enumerate(cards):
            grid.addWidget(card, i // 3, i % 3)

        layout.addLayout(grid)

        columns = QHBoxLayout()
        columns.setSpacing(20)

        recent_col = QVBoxLayout()
        recent_label = QLabel("أحدث عمليات الحضور")
        recent_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        recent_col.addWidget(recent_label)

        self.recent_table = QTableWidget(0, 3)
        self.recent_table.setHorizontalHeaderLabels(["الطالب", "الحالة", "الوقت"])
        self.recent_table.horizontalHeader().setStretchLastSection(True)
        self.recent_table.verticalHeader().setVisible(False)
        self.recent_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        recent_col.addWidget(self.recent_table)
        columns.addLayout(recent_col, 3)

        classes_col = QVBoxLayout()
        classes_label = QLabel("الدروس المجدولة اليوم")
        classes_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        classes_col.addWidget(classes_label)

        self.classes_table = QTableWidget(0, 3)
        self.classes_table.setHorizontalHeaderLabels(["اليوم", "المادة", "الموعد"])
        self.classes_table.horizontalHeader().setStretchLastSection(True)
        self.classes_table.verticalHeader().setVisible(False)
        self.classes_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        classes_col.addWidget(self.classes_table)
        columns.addLayout(classes_col, 2)

        layout.addLayout(columns)

    def refresh(self) -> None:
        summary = attendance_service.get_today_summary()
        self.card_total_students.set_value(str(summary["total_students"]))
        self.card_present_today.set_value(str(summary["present_today"]))
        self.card_absent_today.set_value(str(summary["absent_today"]))
        self.card_attendance_rate.set_value(f"{summary['attendance_rate']}%")

        expired = subscription_service.list_expired_subscriptions()
        self.card_expired_subs.set_value(str(len(expired)))

        exams = exam_service.list_exams()
        self.card_exam_count.set_value(str(len(exams)))

        self._load_recent_attendance()
        self._load_today_classes()

    def _load_recent_attendance(self) -> None:
        from app.repositories.student_repository import StudentRepository
        from app.database.session import session_scope

        recent = attendance_service.list_recent_attendance(limit=8)
        self.recent_table.setRowCount(len(recent))

        with session_scope() as session:
            repo = StudentRepository(session)
            for row, record in enumerate(recent):
                student = repo.get_by_id(record["student_id"])
                name = student.full_name if student else "-"
                status_text = "حاضر" if record["status"].value == "present" else "انصرف"
                time_value = record["check_out_time"] or record["check_in_time"]
                time_text = time_value.strftime("%H:%M") if time_value else "-"

                self.recent_table.setItem(row, 0, QTableWidgetItem(name))
                self.recent_table.setItem(row, 1, QTableWidgetItem(status_text))
                self.recent_table.setItem(row, 2, QTableWidgetItem(time_text))

    def _load_today_classes(self) -> None:
        today_name = _WEEKDAY_AR.get(dt.date.today().weekday(), "")
        classes = class_service.list_classes()
        matched = [c for c in classes if today_name in c["days_of_week"]] or classes

        self.classes_table.setRowCount(len(matched))
        for row, c in enumerate(matched):
            self.classes_table.setItem(row, 0, QTableWidgetItem(today_name))
            self.classes_table.setItem(row, 1, QTableWidgetItem(c["subject"]))
            self.classes_table.setItem(row, 2, QTableWidgetItem(c["time_slot"]))
