from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget

_SERVICES = [
    ("إدارة الطلاب", "إضافة وتعديل وحذف بيانات الطلاب، مع بحث وفلترة سريعة."),
    ("رمز QR لكل طالب", "توليد رمز QR فريد وآمن لكل طالب لتسهيل تسجيل الحضور."),
    ("الحضور والانصراف", "تسجيل الحضور عبر مسح QR بالكاميرا أو إدخال المعرف يدويًا."),
    ("إدارة الحصص والاشتراكات", "متابعة جداول الحصص وتسجيل الطلاب وتتبع حالة الاشتراكات."),
    ("الاختبارات والدرجات", "إنشاء الاختبارات وتسجيل النتائج وتحليل الأداء."),
    ("التقارير", "تقارير شاملة قابلة للتصدير بصيغة PDF أو Excel."),
    ("النسخ الاحتياطي", "حماية بيانات المركز عبر نسخ احتياطي واستعادة آمنة."),
]


class ServicesPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        title = QLabel("خدماتنا")
        title.setObjectName("pageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(title)

        for name, description in _SERVICES:
            card = QFrame()
            card.setObjectName("card")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(18, 14, 18, 14)
            card_layout.setSpacing(4)

            name_label = QLabel(name)
            name_label.setAlignment(Qt.AlignmentFlag.AlignRight)
            name_label.setStyleSheet("font-size: 16px; font-weight: 700;")
            card_layout.addWidget(name_label)

            desc_label = QLabel(description)
            desc_label.setAlignment(Qt.AlignmentFlag.AlignRight)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #6B7280; font-size: 13px;")
            card_layout.addWidget(desc_label)

            layout.addWidget(card)
