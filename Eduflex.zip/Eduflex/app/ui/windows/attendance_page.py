from __future__ import annotations

import datetime as dt

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.services import attendance_service
from app.ui.helpers import show_error
from app.ui.widgets.qr_scan_widget import QRScanWidget
from app.utils.exceptions import EduflexError

_STATUS_LABELS = {"present": "حاضر", "left": "انصرف"}


class _ResultBanner(QFrame):
    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("card")
        self.setMinimumHeight(70)
        layout = QVBoxLayout(self)
        self.label = QLabel("جاهز لتسجيل الحضور")
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("font-size: 16px; font-weight: 600;")
        self.label.setWordWrap(True)
        layout.addWidget(self.label)

    def show_success(self, text: str) -> None:
        self.label.setText(text)
        self.label.setStyleSheet("font-size: 16px; font-weight: 600; color: #27AE60;")

    def show_warning(self, text: str) -> None:
        self.label.setText(text)
        self.label.setStyleSheet("font-size: 16px; font-weight: 600; color: #F39C12;")

    def show_error(self, text: str) -> None:
        self.label.setText(text)
        self.label.setStyleSheet("font-size: 16px; font-weight: 600; color: #E74C3C;")


class AttendancePage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        title = QLabel("الحضور والانصراف")
        title.setObjectName("pageTitle")
        layout.addWidget(title)

        self.banner = _ResultBanner()
        layout.addWidget(self.banner)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_manual_tab(), "إدخال يدوي")
        self.tabs.addTab(self._build_camera_tab(), "مسح QR بالكاميرا")
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.tabs.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        layout.addWidget(self.tabs)

        table_label = QLabel("سجل حضور اليوم")
        table_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        layout.addWidget(table_label)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["الطالب", "الحالة", "وقت الحضور", "وقت الخروج"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.table, 1)

    def _build_manual_tab(self) -> QWidget:
        tab = QWidget()
        outer = QVBoxLayout(tab)
        outer.setAlignment(Qt.AlignmentFlag.AlignTop)

        row = QHBoxLayout()
        self.code_input = QLineEdit()
        self.code_input.setPlaceholderText("أدخل معرف الطالب (4 أرقام) واضغط Enter")
        self.code_input.setMaxLength(4)
        self.code_input.setFixedHeight(38)
        self.code_input.returnPressed.connect(self._on_submit_code)
        row.addWidget(self.code_input, 3)

        self.submit_button = QPushButton("تسجيل")
        self.submit_button.setFixedHeight(38)
        self.submit_button.clicked.connect(self._on_submit_code)
        row.addWidget(self.submit_button, 1)

        outer.addLayout(row)
        return tab

    def _build_camera_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        self.scan_widget = QRScanWidget()
        self.scan_widget.qr_detected.connect(self._on_qr_detected)
        self.scan_widget.camera_error.connect(self._on_camera_error)
        layout.addWidget(self.scan_widget)

        controls = QHBoxLayout()
        self.start_scan_button = QPushButton("بدء المسح")
        self.start_scan_button.clicked.connect(self._on_start_scan)
        self.stop_scan_button = QPushButton("إيقاف المسح")
        self.stop_scan_button.setObjectName("secondaryButton")
        self.stop_scan_button.clicked.connect(self._on_stop_scan)
        controls.addWidget(self.start_scan_button)
        controls.addWidget(self.stop_scan_button)
        layout.addLayout(controls)
        return tab

    def refresh(self) -> None:
        self._load_today_table()

    def _on_tab_changed(self, index: int) -> None:
        if index != 1 and self.scan_widget.is_running:
            self.scan_widget.stop()

    def _on_start_scan(self) -> None:
        self.scan_widget.start()

    def _on_stop_scan(self) -> None:
        self.scan_widget.stop()

    def _on_camera_error(self, message: str) -> None:
        self.banner.show_error(message)

    def _on_qr_detected(self, token: str) -> None:
        try:
            result = attendance_service.record_attendance_by_token(token)
        except EduflexError as exc:
            self.banner.show_error(str(exc))
            return
        self._show_result(result)
        self._load_today_table()

    def _on_submit_code(self) -> None:
        code = self.code_input.text().strip()
        self.code_input.clear()
        if not code:
            return

        try:
            result = attendance_service.record_attendance_by_code(code)
        except EduflexError as exc:
            self.banner.show_error(str(exc))
            return

        self._show_result(result)
        self._load_today_table()
        self.code_input.setFocus()

    def _show_result(self, result: dict) -> None:
        action_text = "تسجيل حضور" if result["action"] == "check_in" else "تسجيل انصراف"
        message = f"{action_text}: {result['full_name']} ({result['student_code']})"

        sub_status = result.get("subscription_status")
        if sub_status is not None and sub_status.value == "expired":
            message += " - تنبيه: اشتراك الطالب منتهٍ"
            self.banner.show_warning(message)
        elif sub_status is not None and sub_status.value == "expiring_soon":
            message += " - اشتراك الطالب قريب الانتهاء"
            self.banner.show_warning(message)
        else:
            self.banner.show_success(message)

    def _load_today_table(self) -> None:
        from app.database.session import session_scope
        from app.repositories.student_repository import StudentRepository

        records = attendance_service.list_attendance_for_date(dt.date.today())
        self.table.setRowCount(len(records))

        with session_scope() as session:
            repo = StudentRepository(session)
            for row, record in enumerate(records):
                student = repo.get_by_id(record["student_id"])
                name = student.full_name if student else "-"
                status_text = _STATUS_LABELS.get(record["status"].value, record["status"].value)
                check_in = record["check_in_time"].strftime("%H:%M") if record["check_in_time"] else "-"
                check_out = record["check_out_time"].strftime("%H:%M") if record["check_out_time"] else "-"

                self.table.setItem(row, 0, QTableWidgetItem(name))
                self.table.setItem(row, 1, QTableWidgetItem(status_text))
                self.table.setItem(row, 2, QTableWidgetItem(check_in))
                self.table.setItem(row, 3, QTableWidgetItem(check_out))
