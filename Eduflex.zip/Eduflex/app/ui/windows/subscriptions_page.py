from __future__ import annotations

from PySide6.QtCore import Qt

import datetime as dt

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.services import student_service, subscription_service
from app.services.subscription_service import SubscriptionStatus
from app.ui.helpers import no_spin_arrows, show_error, styled_form_label, show_info
from app.utils.exceptions import EduflexError

_STATUS_LABELS = {
    SubscriptionStatus.ACTIVE: "نشط",
    SubscriptionStatus.EXPIRING_SOON: "قريب الانتهاء",
    SubscriptionStatus.EXPIRED: "منتهي",
}
_STATUS_COLORS = {
    SubscriptionStatus.ACTIVE: "#27AE60",
    SubscriptionStatus.EXPIRING_SOON: "#F39C12",
    SubscriptionStatus.EXPIRED: "#E74C3C",
}
_FILTER_ITEMS = [("الكل", None)] + [(label, status) for status, label in _STATUS_LABELS.items()]


class RenewSubscriptionDialog(QDialog):
    def __init__(self, parent, student: dict) -> None:
        super().__init__(parent)
        self.student = student
        self.setWindowTitle(f"تجديد اشتراك: {student['full_name']}")
        self.setMinimumWidth(360)

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.start_input = QDateEdit()
        self.start_input.setCalendarPopup(True)
        self.start_input.setDate(dt.date.today())
        form.addRow(styled_form_label("بداية الاشتراك"), self.start_input)

        self.end_input = QDateEdit()
        self.end_input.setCalendarPopup(True)
        self.end_input.setDate(dt.date.today() + dt.timedelta(days=30))
        form.addRow(styled_form_label("نهاية الاشتراك"), self.end_input)

        self.price_input = QDoubleSpinBox()
        self.price_input.setRange(0, 1_000_000)
        self.price_input.setSuffix(" جنيه")
        self.price_input.setValue(float(student.get("subscription_price") or 0))
        no_spin_arrows(self.price_input)
        form.addRow(styled_form_label("السعر"), self.price_input)

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QHBoxLayout()
        save_button = QPushButton("تجديد")
        save_button.clicked.connect(self._on_save)
        cancel_button = QPushButton("إلغاء")
        cancel_button.setObjectName("secondaryButton")
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(save_button)
        buttons.addWidget(cancel_button)
        layout.addLayout(buttons)

    def _on_save(self) -> None:
        try:
            subscription_service.create_subscription(
                student_id=self.student["id"],
                start_date=self.start_input.date().toPython(),
                end_date=self.end_input.date().toPython(),
                price=self.price_input.value(),
            )
            self.accept()
        except EduflexError as exc:
            self.error_label.setText(str(exc))
        except Exception as exc:
            show_error(self, exc)


class SubscriptionsPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._rows: list[dict] = []
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        header = QHBoxLayout()
        title = QLabel("إدارة الاشتراكات")
        title.setObjectName("pageTitle")
        header.addWidget(title)
        header.addStretch()
        layout.addLayout(header)

        filters = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("بحث بالاسم أو معرف الطالب...")
        self.search_input.textChanged.connect(self.refresh)
        filters.addWidget(self.search_input, 2)

        self.status_filter = QComboBox()
        for label, _s in _FILTER_ITEMS:
            self.status_filter.addItem(label)
        self.status_filter.currentIndexChanged.connect(self.refresh)
        filters.addWidget(self.status_filter, 1)
        layout.addLayout(filters)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["الطالب", "المعرف", "تاريخ الانتهاء", "السعر", "الحالة"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.table)

        actions = QHBoxLayout()
        self.renew_button = QPushButton("تجديد اشتراك المحدد")
        self.renew_button.clicked.connect(self._on_renew_selected)
        actions.addWidget(self.renew_button)
        actions.addStretch()
        layout.addLayout(actions)

    def refresh(self) -> None:
        try:
            students = student_service.list_students()
        except EduflexError as exc:
            show_error(self, exc)
            return

        text = self.search_input.text().strip().lower()
        status_filter = _FILTER_ITEMS[self.status_filter.currentIndex()][1]

        rows = []
        for s in students:
            if text and text not in s["full_name"].lower() and text not in s["student_code"]:
                continue
            status = subscription_service.get_current_status_for_student(s["id"])
            if status_filter is not None and status != status_filter:
                continue
            subs = subscription_service.list_subscriptions_for_student(s["id"])
            latest = subs[0] if subs else None
            rows.append({"student": s, "status": status, "latest": latest})

        self._rows = rows
        self.table.setRowCount(len(rows))
        for row, r in enumerate(rows):
            s = r["student"]
            self.table.setItem(row, 0, QTableWidgetItem(s["full_name"]))
            self.table.setItem(row, 1, QTableWidgetItem(s["student_code"]))
            end_date = r["latest"]["end_date"].isoformat() if r["latest"] else "-"
            self.table.setItem(row, 2, QTableWidgetItem(end_date))
            price = r["latest"]["price"] if r["latest"] else 0
            self.table.setItem(row, 3, QTableWidgetItem(f"{price:.0f}"))

            status_item = QTableWidgetItem(
                _STATUS_LABELS.get(r["status"], "لا يوجد اشتراك") if r["status"] else "لا يوجد اشتراك"
            )
            if r["status"] is not None:
                from PySide6.QtGui import QColor

                status_item.setForeground(QColor(_STATUS_COLORS[r["status"]]))
            self.table.setItem(row, 4, status_item)

    def _selected(self) -> dict | None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        return self._rows[rows[0].row()]

    def _on_renew_selected(self) -> None:
        selection = self._selected()
        if selection is None:
            show_info(self, "الرجاء اختيار طالب من الجدول أولًا.", "لم يتم الاختيار")
            return
        if RenewSubscriptionDialog(self, selection["student"]).exec():
            self.refresh()
