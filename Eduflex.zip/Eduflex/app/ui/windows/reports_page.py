from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QGridLayout, QLabel, QScrollArea, QVBoxLayout, QWidget

from app.ui.dialogs.report_detail_dialog import ReportDetailDialog
from app.ui.icons import (
    ICON_CALENDAR,
    ICON_DOLLAR,
    ICON_EDIT,
    ICON_EXIT,
    ICON_GRADUATION,
    make_icon,
)
from app.ui.widgets.report_card import ReportCard

_CARDS = [
    ("إجمالي الغياب", ICON_EXIT, "attendance_totals"),
    ("إجمالي الحضور", ICON_CALENDAR, "attendance_totals"),
    ("الحضور والغياب اليومي", ICON_CALENDAR, "daily_attendance"),
    ("درجات الطلاب في الاختبارات", ICON_GRADUATION, "exam_results"),
    ("تسجيل درجات الاختبارات", ICON_EDIT, "goto_exams"),
    ("الاشتراكات المنتهية", ICON_DOLLAR, "expired_subscriptions"),
    ("الإحصائيات الشاملة", ICON_GRADUATION, "comprehensive_statistics"),
]


class ReportsPage(QWidget):
    navigate_requested = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._build_ui()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 24, 28, 24)
        outer.setSpacing(16)

        title = QLabel("التقارير")
        title.setObjectName("pageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignRight)
        outer.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        outer.addWidget(scroll)

        container = QWidget()
        grid = QGridLayout(container)
        grid.setSpacing(16)

        for index, (label, icon_svg, kind) in enumerate(_CARDS):
            card = ReportCard(label, make_icon(icon_svg))
            card.clicked.connect(lambda _checked=False, k=kind, t=label: self._on_card_clicked(k, t))
            row, col = divmod(index, 2)
            grid.addWidget(card, row, col)

        scroll.setWidget(container)

    def refresh(self) -> None:
        pass

    def _on_card_clicked(self, kind: str, title: str) -> None:
        if kind == "goto_exams":
            self.navigate_requested.emit("exams")
            return
        ReportDetailDialog(self, kind, title).exec()
