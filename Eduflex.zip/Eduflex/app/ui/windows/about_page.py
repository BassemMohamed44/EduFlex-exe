from __future__ import annotations

import html
import re

from PySide6.QtCore import QSize, QUrl, Qt
from PySide6.QtGui import QColor, QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

_ARABIC_PATTERN = re.compile(r"[\u0600-\u06FF]")

SOCIAL_LINKS1 = [
    ("FaceBook", "https://facebook.com/eduflex"),
    ("Instagram", "https://instagram.com/eduflex"),
    ("Youtube", "https://youtube.com/@eduflex"),
    ("WhatsApp", "https://wa.me/201000000000"),
]
SOCIAL_LINKS2 = [
    ("Bassem Social", "https://bassem-social-hub.pages.dev/"),
    ("Portfolio", "https://bassemmohamed.pages.dev/"),
    ("GitHub", "https://github.com/BassemMohamed44"),
    ("Instagram", "https://www.instagram.com/bassemmohamed_0?igsh=NWZoMHVzNnpxdG9t"),
]
SOCIAL_LINKS3 = [
    ("FaceBook", "https://facebook.com/eduflex"),
    ("Instagram", "https://instagram.com/eduflex"),
    ("Youtube", "https://youtube.com/@eduflex"),
    ("WhatsApp", "https://wa.me/201000000000"),
]

_ICON_FACEBOOK = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.99 3.66 9.13 8.44 9.88v-6.99H7.9v-2.89h2.54V9.79c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.23.2 2.23.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56v1.88h2.78l-.44 2.89h-2.34v6.99C18.34 21.13 22 16.99 22 12z"/></svg>"""
_ICON_INSTAGRAM = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M12 2c2.72 0 3.06.01 4.12.06 1.06.05 1.79.22 2.43.47.66.26 1.22.6 1.77 1.15.55.55.89 1.11 1.15 1.77.25.64.42 1.37.47 2.43C21.99 8.94 22 9.28 22 12s-.01 3.06-.06 4.12c-.05 1.06-.22 1.79-.47 2.43a4.9 4.9 0 0 1-1.15 1.77 4.9 4.9 0 0 1-1.77 1.15c-.64.25-1.37.42-2.43.47-1.06.05-1.4.06-4.12.06s-3.06-.01-4.12-.06c-1.06-.05-1.79-.22-2.43-.47a4.9 4.9 0 0 1-1.77-1.15 4.9 4.9 0 0 1-1.15-1.77c-.25-.64-.42-1.37-.47-2.43C2.01 15.06 2 14.72 2 12s.01-3.06.06-4.12c.05-1.06.22-1.79.47-2.43.26-.66.6-1.22 1.15-1.77A4.9 4.9 0 0 1 5.45.53c.64-.25 1.37-.42 2.43-.47C8.94.01 9.28 0 12 0zm0 5.84A6.16 6.16 0 1 0 12 18.16 6.16 6.16 0 0 0 12 5.84zm0 10.16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.4-10.4a1.44 1.44 0 1 1-2.88 0 1.44 1.44 0 0 1 2.88 0z"/></svg>"""
_ICON_YOUTUBE = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M23.5 6.2s-.23-1.64-.94-2.36c-.9-.94-1.9-.95-2.36-1C17 2.5 12 2.5 12 2.5h-.01s-5 0-8.19.34c-.46.05-1.46.06-2.36 1C.73 4.56.5 6.2.5 6.2S.25 8.13.25 10.05v1.78c0 1.92.25 3.85.25 3.85s.23 1.64.94 2.36c.9.95 2.08.92 2.6 1.02 1.9.18 8.02.34 8.02.34s5.01-.01 8.19-.35c.46-.05 1.46-.06 2.36-1 .71-.72.94-2.36.94-2.36s.25-1.92.25-3.85v-1.78c0-1.92-.25-3.85-.25-3.85zM9.6 14.6V7.4l6.4 3.6-6.4 3.6z"/></svg>"""
_ICON_WHATSAPP = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M17.47 14.38c-.29-.15-1.7-.84-1.97-.94-.26-.1-.46-.15-.65.15-.19.29-.75.94-.92 1.13-.17.19-.34.22-.63.07-.29-.15-1.22-.45-2.33-1.44-.86-.77-1.44-1.71-1.61-2-.17-.29-.02-.45.13-.6.13-.13.29-.34.44-.51.15-.17.19-.29.29-.48.1-.19.05-.36-.02-.51-.07-.15-.65-1.58-.9-2.16-.24-.58-.48-.5-.65-.5-.17 0-.36-.02-.55-.02-.19 0-.51.07-.77.36-.26.29-1.01.99-1.01 2.41s1.04 2.8 1.18 3c.15.19 2.04 3.13 4.96 4.39.69.3 1.23.48 1.65.61.69.22 1.32.19 1.81.11.55-.08 1.7-.7 1.94-1.37.24-.68.24-1.26.17-1.37-.07-.12-.26-.19-.55-.34zM12.02 2C6.5 2 2 6.48 2 12c0 1.85.5 3.58 1.36 5.07L2 22l5.09-1.33A9.94 9.94 0 0 0 12.02 22C17.5 22 22 17.52 22 12S17.5 2 12.02 2z"/></svg>"""
_ICON_GITHUB = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="white"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>"""
_ICON_GLOBE = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm6.93 8h-3.05a15.6 15.6 0 0 0-1.27-5.09A8.03 8.03 0 0 1 18.93 10zM12 4.05c.9 1.3 1.6 3.05 1.93 5.95H10.07c.33-2.9 1.03-4.65 1.93-5.95zM4.26 12h3.66c.08 1.4.32 2.76.7 4H4.98a7.94 7.94 0 0 1-.72-4zm.72-2a7.94 7.94 0 0 1 .72-2h3.7c-.08.63-.13 1.3-.15 2H4.98zm3.8 8.09A15.6 15.6 0 0 1 7.92 14h3.15c.15 1.5.45 2.9.93 4.09a7.96 7.96 0 0 1-2.99-.0zM10.07 14h3.86c-.33 2.9-1.03 4.65-1.93 5.95-.9-1.3-1.6-3.05-1.93-5.95zm5.02 4.09c.48-1.19.78-2.59.93-4.09h3.15a15.6 15.6 0 0 1-1.19 2.09 8 8 0 0 1-2.89 2zm1.09-6.09c-.02-.7-.07-1.37-.15-2h3.7c.34.62.6 1.3.72 2h-4.27zm.15-4a15.6 15.6 0 0 0-1.27-5.09A8 8 0 0 1 18.7 8h-2.37zM7.39 4.91A15.6 15.6 0 0 0 6.12 10H3.07a8.03 8.03 0 0 1 4.32-5.09z"/></svg>"""

_PLATFORM_STYLES = {
    "facebook": (_ICON_FACEBOOK, "#1877F2"),
    "instagram": (_ICON_INSTAGRAM, "#E1306C"),
    "youtube": (_ICON_YOUTUBE, "#FF0000"),
    "whatsapp": (_ICON_WHATSAPP, "#25D366"),
    "github": (_ICON_GITHUB, "#181717"),
}

_ABOUT_TEXT = """هو أنا فاشل؟ ولا في حاجة ناقصة؟

قصتنا بدأت من يوم الأحد 26 فبراير 2023… يوم عادي جدًا بالنسبة لمعظم الناس.
لكن بالنسبة ليا؟
كان يوم غيّر حياتي كلها 180 درجة.

اليوم ده حسيت إن عندي شغف مختلف… حسيت إن في حاجة جوايا بتقولي:
ابدأ. متستناش.

وبعدها بكام يوم، الجمعة 3 مارس 2023، قررت أخد أول خطوة فعلية:
أنزل فيديو على اليوتيوب.

ونزلت بعدها حوالي خمس فيديوهات.

بس الصدمة؟ مفيش مشاهدات.

سألت نفسي: هو أنا فاشل؟ ولا في حاجة ناقصة؟

المهم سألت كذا صديق، وبعد تفكير طويل اكتشفت إن السر كله في التفاصيل الصغيرة… الصور المصغرة.

ومن هنا بدأت رحلتي في مجال الـ Graphic Design.

اتعلمت من التليفون ساعتها من برنامج بيكس آرت وبيكسل لاب.
دي كانت البداية، واللي ساعدني صديقي مالك عثمان، اللي عمره ما بخل عليا بمعلومة، واللي ليه فضل كبير عليا بعد ربنا.

لأن لولاه كان المشوار هيكون صعب شوية، لاني الواحد مكنش عنده ثقافة البحث على اليوتيوب والتعلم الذاتي والحاجات دي.

وبعد فترة جبت PC، وجه محمد وليد وفتحلي باب أكبر إني أطور من نفسي على أدوبي فوتوشوب.

واحدة واحدة، بدأت أفهم إن الموضوع مش مجرد فيديوهات…
ده عالم كامل اسمه Content Creation.

وبعدين لقيت نفسي بدخل أعمق في مجال الجرافيك ديزاين.

وبين التعب والمحاولات الكتير… بدأت تيجي فرص شغل.

كل شغلانة صغيرة كانت بتأكدلي إن حلمي مش بعيد.

ولما كبرت خطوة بخطوة، سألت نفسي:

ليه أكون لوحدي؟

ليه منعملش تيم كامل، ونبني شركة أونلاين…
ومع الوقت تبقى على أرض الواقع؟

والحمدلله… حالياً الحلم بقى حقيقة.

أسسنا شركة Flex Design ✨

بقينا بنقدم كل حاجة في عالم الدعاية والإعلان:

🎨 جرافيك ديزاين
🎬 فيديو إيديتنج
🎤 تعليق صوتي
📝 كتابة محتوى
📱 إدارة صفحات
✏️ وايت بورد أنيميشن
🤖 AI Video Generation

والأجمل إننا مشينا سوا وبدأنا نكبر أكتر…

فريقنا النهارده بقى فيه مبرمج أسطورة وهو باسم محمد، صديق الطفولة،
و UI/UX مبدع وهو أخويا محمد عبدالله، اللي بيجادل دايماً معايا وبينكشني في أي حاجة 😅❤

والخطوة الجاية؟

شغالين دلوقتي على تطبيق هيغير شكل التعليم للمدرسين، سميناه EDUFLEX.

وعندنا كمان فكرة لتطبيق جديد… بس المفاجأة لسه جاية 😉

أنا شاركت القصة دي مش بس عشان أحكيلكم بداية مشواري…
لكن كمان عشان أقول لكل حد عنده حلم:

ابدأ… حتى لو من ولا حاجة.

لأن كل نجاح كبير بدأ بخطوة صغيرة جدًا.

ادعولنا إننا نكمل ونوصل بحلمنا لأبعد مكان 🙏🔥"""


def _to_bidi_html(text: str) -> str:
    paragraphs = text.split("\n\n")
    parts = []
    for paragraph in paragraphs:
        if not paragraph.strip():
            continue
        is_arabic = bool(_ARABIC_PATTERN.search(paragraph))
        direction = "rtl" if is_arabic else "ltr"
        escaped = html.escape(paragraph).replace("\n", "<br>")
        parts.append(f'<p dir="{direction}">{escaped}</p>')
    return f'<div dir="rtl">{"".join(parts)}</div>'


def _style_for(label: str) -> tuple[str, str]:
    key = label.strip().lower().replace(" ", "")
    for platform, style in _PLATFORM_STYLES.items():
        if platform in key:
            return style
    return _ICON_GLOBE, "#2E86DE"


def _make_social_button(label: str, url: str) -> QPushButton:
    icon_svg, color = _style_for(label)
    pixmap = QPixmap()
    pixmap.loadFromData(icon_svg.encode("utf-8"), "SVG")
    hover_color = QColor(color).darker(115).name()

    button = QPushButton(label)
    button.setIcon(QIcon(pixmap))
    button.setIconSize(QSize(18, 18))
    button.setCursor(Qt.CursorShape.PointingHandCursor)
    button.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
    button.setMinimumHeight(40)
    button.setStyleSheet(
        f"QPushButton {{"
        f"background-color: {color};"
        f"color: white;"
        f"border: none;"
        f"border-radius: 10px;"
        f"padding: 8px 18px;"
        f"font-weight: 600;"
        f"font-size: 13px;"
        f"}}"
        f"QPushButton:hover {{"
        f"background-color: {hover_color};"
        f"}}"
    )
    button.clicked.connect(lambda _checked=False, u=url: QDesktopServices.openUrl(QUrl(u)))
    return button


def _add_social_row(layout: QVBoxLayout, title: str, links: list[tuple[str, str]]) -> None:
    title_label = QLabel(title)
    title_label.setAlignment(Qt.AlignmentFlag.AlignRight)
    title_label.setStyleSheet("font-weight: 700; font-size: 15px; margin-top: 20px;")
    layout.addWidget(title_label)

    row = QHBoxLayout()
    row.setSpacing(10)
    for label, url in links:
        row.addWidget(_make_social_button(label, url))
    row.addStretch()
    layout.addLayout(row)


class AboutPage(QWidget):
    def __init__(self) -> None:
        super().__init__()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        title = QLabel("من نحن")
        title.setObjectName("pageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(title)

        text = QLabel()
        text.setTextFormat(Qt.TextFormat.RichText)
        text.setText(_to_bidi_html(_ABOUT_TEXT))
        text.setWordWrap(True)
        text.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        text.setStyleSheet("QLabel { font-size: 15px; line-height: 1.8; }")

        scroll = QScrollArea()
        scroll.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(text)
        layout.addWidget(scroll)

        _add_social_row(layout, "تابعنا على", SOCIAL_LINKS1)
        _add_social_row(layout, "Follow Bassem Mohamed", SOCIAL_LINKS2)
        _add_social_row(layout, "Follow Mohamed", SOCIAL_LINKS3)
