from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout, QMainWindow, QStackedWidget, QWidget

from app.services import auth_service
from app.ui.widgets.sidebar import NAV_ITEMS, Sidebar
from app.ui.windows.attendance_page import AttendancePage
from app.ui.windows.about_page import AboutPage
from app.ui.windows.backup_page import BackupPage
from app.ui.windows.classes_page import ClassesPage
from app.ui.windows.dashboard_page import DashboardPage
from app.ui.windows.exams_page import ExamsPage
from app.ui.windows.placeholder_page import PlaceholderPage
from app.ui.windows.reports_page import ReportsPage
from app.ui.windows.services_page import ServicesPage
from app.ui.windows.settings_page import SettingsPage
from app.ui.windows.students_page import StudentsPage
from app.ui.windows.subscriptions_page import SubscriptionsPage


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Eduflex")
        self.resize(1100, 720)

        central = QWidget()
        central.setObjectName("centralWidget")
        self.setCentralWidget(central)

        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        teacher_name = auth_service.current_session.teacher_name or ""
        self.sidebar = Sidebar(teacher_name)
        self.sidebar.navigate.connect(self._on_navigate)
        self.sidebar.logout_requested.connect(self._on_logout)
        layout.addWidget(self.sidebar)

        self.stack = QStackedWidget()
        layout.addWidget(self.stack, 1)

        self._pages: dict[str, QWidget] = {}
        self._build_pages()
        self._on_navigate("dashboard")

    def _build_pages(self) -> None:
        label_by_key = dict(NAV_ITEMS)

        self.dashboard_page = DashboardPage()
        self._pages["dashboard"] = self.dashboard_page
        self.stack.addWidget(self.dashboard_page)

        self.students_page = StudentsPage()
        self._pages["students"] = self.students_page
        self.stack.addWidget(self.students_page)

        self.attendance_page = AttendancePage()
        self._pages["attendance"] = self.attendance_page
        self.stack.addWidget(self.attendance_page)

        self.classes_page = ClassesPage()
        self._pages["classes"] = self.classes_page
        self.stack.addWidget(self.classes_page)

        self.subscriptions_page = SubscriptionsPage()
        self._pages["subscriptions"] = self.subscriptions_page
        self.stack.addWidget(self.subscriptions_page)

        self.backup_page = BackupPage()
        self._pages["backup"] = self.backup_page
        self.stack.addWidget(self.backup_page)

        self.exams_page = ExamsPage()
        self._pages["exams"] = self.exams_page
        self.stack.addWidget(self.exams_page)

        self.reports_page = ReportsPage()
        self.reports_page.navigate_requested.connect(self._on_navigate)
        self._pages["reports"] = self.reports_page
        self.stack.addWidget(self.reports_page)

        self.settings_page = SettingsPage()
        self._pages["settings"] = self.settings_page
        self.stack.addWidget(self.settings_page)

        self.about_page = AboutPage()
        self._pages["about"] = self.about_page
        self.stack.addWidget(self.about_page)

        self.services_page = ServicesPage()
        self._pages["services"] = self.services_page
        self.stack.addWidget(self.services_page)

        for key, label in NAV_ITEMS:
            if key in self._pages:
                continue
            page = PlaceholderPage(label)
            self._pages[key] = page
            self.stack.addWidget(page)

    def _on_navigate(self, key: str) -> None:
        page = self._pages.get(key)
        if page is None:
            return
        if key == "dashboard":
            self.dashboard_page.refresh()
        elif key == "students":
            self.students_page.refresh()
        elif key == "attendance":
            self.attendance_page.refresh()
        elif key == "classes":
            self.classes_page.refresh()
        elif key == "subscriptions":
            self.subscriptions_page.refresh()
        elif key == "backup":
            self.backup_page.refresh()
        elif key == "exams":
            self.exams_page.refresh()
        elif key == "reports":
            self.reports_page.refresh()
        elif key == "settings":
            self.settings_page.refresh()
        self.stack.setCurrentWidget(page)
        self.sidebar.set_active(key)

    def _on_logout(self) -> None:
        auth_service.logout()
        self.close()
