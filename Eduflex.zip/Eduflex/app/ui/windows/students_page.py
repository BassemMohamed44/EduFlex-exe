from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.models.student import StudentStatus
from app.services import student_service
from app.ui.dialogs.qr_code_dialog import QRCodeDialog
from app.ui.dialogs.student_dialog import StudentDialog
from app.ui.helpers import confirm, show_error, show_info
from app.utils.exceptions import EduflexError

_STATUS_LABELS = {
    StudentStatus.ACTIVE: "نشط",
    StudentStatus.SUSPENDED: "موقوف",
    StudentStatus.ARCHIVED: "مؤرشف",
}
_STATUS_FILTER_ITEMS = [("الكل", None)] + [(label, status) for status, label in _STATUS_LABELS.items()]

_COLUMNS = ["المعرف", "الاسم", "الصف", "السنتر", "الاشتراك", "الحالة"]


class StudentsPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._rows: list[dict] = []
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        header = QHBoxLayout()
        title = QLabel("إدارة الطلاب")
        title.setObjectName("pageTitle")
        header.addWidget(title)
        header.addStretch()

        self.add_button = QPushButton("+ إضافة طالب")
        self.add_button.clicked.connect(self._on_add)
        header.addWidget(self.add_button)
        layout.addLayout(header)

        filters = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("بحث بالاسم أو معرف الطالب...")
        self.search_input.textChanged.connect(self._on_filters_changed)
        filters.addWidget(self.search_input, 2)

        self.status_filter = QComboBox()
        for label, _status in _STATUS_FILTER_ITEMS:
            self.status_filter.addItem(label)
        self.status_filter.currentIndexChanged.connect(self._on_filters_changed)
        filters.addWidget(self.status_filter, 1)

        layout.addLayout(filters)

        self.table = QTableWidget(0, len(_COLUMNS))
        self.table.setHorizontalHeaderLabels(_COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.table)

        actions = QHBoxLayout()
        self.view_button = QPushButton("عرض / تعديل")
        self.view_button.clicked.connect(self._on_edit_selected)
        self.qr_button = QPushButton("رمز QR")
        self.qr_button.setObjectName("secondaryButton")
        self.qr_button.clicked.connect(self._on_show_qr_selected)
        self.delete_button = QPushButton("حذف")
        self.delete_button.setObjectName("dangerButton")
        self.delete_button.clicked.connect(self._on_delete_selected)

        actions.addWidget(self.view_button)
        actions.addWidget(self.qr_button)
        actions.addWidget(self.delete_button)
        actions.addStretch()
        layout.addLayout(actions)

    def refresh(self) -> None:
        self._on_filters_changed()

    def _on_filters_changed(self) -> None:
        text = self.search_input.text().strip() or None
        status = _STATUS_FILTER_ITEMS[self.status_filter.currentIndex()][1]
        try:
            students = student_service.search_students(text=text, status=status)
        except EduflexError as exc:
            show_error(self, exc)
            return
        self._populate_table(students)

    def _populate_table(self, students: list[dict]) -> None:
        self._rows = students
        self.table.setRowCount(len(students))
        for row, s in enumerate(students):
            self.table.setItem(row, 0, QTableWidgetItem(s["student_code"]))
            self.table.setItem(row, 1, QTableWidgetItem(s["full_name"]))
            self.table.setItem(row, 2, QTableWidgetItem(s["grade_level"]))
            self.table.setItem(row, 3, QTableWidgetItem(s.get("center_name") or "-"))
            price = s.get("subscription_price") or 0
            self.table.setItem(row, 4, QTableWidgetItem(f"{price:.0f}"))
            self.table.setItem(row, 5, QTableWidgetItem(_STATUS_LABELS.get(s["status"], "-")))

    def _selected_student(self) -> dict | None:
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return None
        return self._rows[selected_rows[0].row()]

    def _on_add(self) -> None:
        dialog = StudentDialog(self)
        if dialog.exec():
            self.refresh()

    def _on_edit_selected(self) -> None:
        student = self._selected_student()
        if student is None:
            show_info(self, "الرجاء اختيار طالب من الجدول أولًا.", "لم يتم الاختيار")
            return
        try:
            full = student_service.get_student(student["id"])
        except EduflexError as exc:
            show_error(self, exc)
            return
        dialog = StudentDialog(self, student=full)
        if dialog.exec():
            self.refresh()

    def _on_show_qr_selected(self) -> None:
        student = self._selected_student()
        if student is None:
            show_info(self, "الرجاء اختيار طالب من الجدول أولًا.", "لم يتم الاختيار")
            return
        dialog = QRCodeDialog(self, student)
        dialog.exec()

    def _on_delete_selected(self) -> None:
        student = self._selected_student()
        if student is None:
            show_info(self, "الرجاء اختيار طالب من الجدول أولًا.", "لم يتم الاختيار")
            return
        if not confirm(
            self,
            f"سيتم حذف الطالب '{student['full_name']}' وكل سجلاته (الحضور، الاشتراكات، النتائج) نهائيًا. هل أنت متأكد؟",
            "تأكيد الحذف",
        ):
            return
        try:
            student_service.delete_student(student["id"])
            self.refresh()
        except EduflexError as exc:
            show_error(self, exc)
