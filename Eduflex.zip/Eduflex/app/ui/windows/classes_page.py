from __future__ import annotations

from PySide6.QtCore import Qt

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.models.class_session import ClassStatus
from app.services import class_service
from app.ui.dialogs.class_dialog import ClassDialog
from app.ui.dialogs.enrollment_dialog import EnrollmentDialog
from app.ui.helpers import confirm, show_error, show_info
from app.utils.exceptions import EduflexError

_STATUS_LABELS = {ClassStatus.ACTIVE: "نشطة", ClassStatus.INACTIVE: "غير نشطة"}
_COLUMNS = ["المادة", "الأيام", "الموعد", "السنتر", "السعر", "الحالة"]


class ClassesPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._rows: list[dict] = []
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        header = QHBoxLayout()
        title = QLabel("إدارة الحصص")
        title.setObjectName("pageTitle")
        header.addWidget(title)
        header.addStretch()
        self.add_button = QPushButton("+ إضافة حصة")
        self.add_button.clicked.connect(self._on_add)
        header.addWidget(self.add_button)
        layout.addLayout(header)

        self.table = QTableWidget(0, len(_COLUMNS))
        self.table.setHorizontalHeaderLabels(_COLUMNS)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.table)

        actions = QHBoxLayout()
        self.edit_button = QPushButton("تعديل")
        self.edit_button.clicked.connect(self._on_edit_selected)
        self.students_button = QPushButton("طلاب الحصة")
        self.students_button.setObjectName("secondaryButton")
        self.students_button.clicked.connect(self._on_manage_students)
        self.delete_button = QPushButton("حذف")
        self.delete_button.setObjectName("dangerButton")
        self.delete_button.clicked.connect(self._on_delete_selected)

        actions.addWidget(self.edit_button)
        actions.addWidget(self.students_button)
        actions.addWidget(self.delete_button)
        actions.addStretch()
        layout.addLayout(actions)

    def refresh(self) -> None:
        try:
            classes = class_service.list_classes()
        except EduflexError as exc:
            show_error(self, exc)
            return
        self._rows = classes
        self.table.setRowCount(len(classes))
        for row, c in enumerate(classes):
            self.table.setItem(row, 0, QTableWidgetItem(c["subject"]))
            self.table.setItem(row, 1, QTableWidgetItem(c["days_of_week"]))
            self.table.setItem(row, 2, QTableWidgetItem(c["time_slot"]))
            self.table.setItem(row, 3, QTableWidgetItem(c.get("center_name") or "-"))
            self.table.setItem(row, 4, QTableWidgetItem(f"{c['price']:.0f}"))
            self.table.setItem(row, 5, QTableWidgetItem(_STATUS_LABELS.get(c["status"], "-")))

    def _selected(self) -> dict | None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        return self._rows[rows[0].row()]

    def _on_add(self) -> None:
        if ClassDialog(self).exec():
            self.refresh()

    def _on_edit_selected(self) -> None:
        c = self._selected()
        if c is None:
            show_info(self, "الرجاء اختيار حصة من الجدول أولًا.", "لم يتم الاختيار")
            return
        if ClassDialog(self, class_session=c).exec():
            self.refresh()

    def _on_manage_students(self) -> None:
        c = self._selected()
        if c is None:
            show_info(self, "الرجاء اختيار حصة من الجدول أولًا.", "لم يتم الاختيار")
            return
        EnrollmentDialog(self, c).exec()

    def _on_delete_selected(self) -> None:
        c = self._selected()
        if c is None:
            show_info(self, "الرجاء اختيار حصة من الجدول أولًا.", "لم يتم الاختيار")
            return
        if not confirm(self, f"سيتم حذف حصة '{c['subject']}' وإلغاء تسجيل كل طلابها. متابعة؟", "تأكيد الحذف"):
            return
        try:
            class_service.delete_class(c["id"])
            self.refresh()
        except EduflexError as exc:
            show_error(self, exc)
