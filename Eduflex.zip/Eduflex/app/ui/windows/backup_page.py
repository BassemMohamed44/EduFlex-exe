from __future__ import annotations

from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.services import backup_service
from app.ui.helpers import confirm, show_error, show_info
from app.utils.exceptions import EduflexError


class BackupPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._rows: list[dict] = []
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)

        title = QLabel("النسخ الاحتياطي")
        title.setObjectName("pageTitle")
        layout.addWidget(title)

        self.last_backup_label = QLabel("")
        self.last_backup_label.setStyleSheet("color: #6B7280;")
        layout.addWidget(self.last_backup_label)

        actions = QHBoxLayout()
        self.backup_now_button = QPushButton("إنشاء نسخة احتياطية الآن")
        self.backup_now_button.clicked.connect(self._on_backup_now)
        actions.addWidget(self.backup_now_button)

        self.backup_to_button = QPushButton("نسخ احتياطي إلى مكان مخصص...")
        self.backup_to_button.setObjectName("secondaryButton")
        self.backup_to_button.clicked.connect(self._on_backup_to_custom)
        actions.addWidget(self.backup_to_button)

        self.restore_from_button = QPushButton("استعادة من ملف...")
        self.restore_from_button.setObjectName("dangerButton")
        self.restore_from_button.clicked.connect(self._on_restore_from_file)
        actions.addWidget(self.restore_from_button)
        actions.addStretch()
        layout.addLayout(actions)

        table_label = QLabel("النسخ الاحتياطية المتاحة")
        table_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        layout.addWidget(table_label)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["اسم الملف", "التاريخ", "الحجم"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)

        restore_selected_button = QPushButton("استعادة النسخة المحددة")
        restore_selected_button.setObjectName("dangerButton")
        restore_selected_button.clicked.connect(self._on_restore_selected)
        layout.addWidget(restore_selected_button)

    def refresh(self) -> None:
        info = backup_service.get_last_backup_info()
        if info is None:
            self.last_backup_label.setText("لم يتم إنشاء أي نسخة احتياطية بعد.")
        else:
            created = info["created_at"].strftime("%Y-%m-%d %H:%M") if info["created_at"] else "-"
            self.last_backup_label.setText(f"آخر نسخة احتياطية: {created}")

        backups = backup_service.list_available_backups()
        self._rows = backups
        self.table.setRowCount(len(backups))
        for row, b in enumerate(backups):
            self.table.setItem(row, 0, QTableWidgetItem(b["filename"]))
            self.table.setItem(row, 1, QTableWidgetItem(b["modified_at"].strftime("%Y-%m-%d %H:%M")))
            size_kb = b["size_bytes"] / 1024
            self.table.setItem(row, 2, QTableWidgetItem(f"{size_kb:.1f} KB"))

    def _on_backup_now(self) -> None:
        try:
            backup_service.create_backup()
            self.refresh()
            show_info(self, "تم إنشاء نسخة احتياطية بنجاح.")
        except EduflexError as exc:
            show_error(self, exc)

    def _on_backup_to_custom(self) -> None:
        directory = QFileDialog.getExistingDirectory(self, "اختر مكان حفظ النسخة الاحتياطية")
        if not directory:
            return
        try:
            backup_service.create_backup(destination_dir=directory)
            self.refresh()
            show_info(self, "تم إنشاء نسخة احتياطية بنجاح.")
        except EduflexError as exc:
            show_error(self, exc)

    def _on_restore_from_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "اختر ملف النسخة الاحتياطية", "", "Database Files (*.db)")
        if not path:
            return
        self._restore(path)

    def _on_restore_selected(self) -> None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return
        backup = self._rows[rows[0].row()]
        self._restore(backup["path"])

    def _restore(self, path: str) -> None:
        if not confirm(
            self,
            "سيتم استبدال البيانات الحالية بالكامل ببيانات هذه النسخة الاحتياطية. "
            "سيتم أخذ نسخة أمان تلقائية من الوضع الحالي أولًا. هل تريد المتابعة؟",
            "تأكيد الاستعادة",
        ):
            return
        try:
            backup_service.restore_backup(path)
            self.refresh()
            show_info(self, "تمت استعادة النسخة الاحتياطية بنجاح.")
        except EduflexError as exc:
            show_error(self, exc)
