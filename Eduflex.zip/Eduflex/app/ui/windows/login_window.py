from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.services import auth_service
from app.ui.helpers import show_error
from app.utils.exceptions import EduflexError


class LoginWindow(QWidget):
    login_succeeded = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Eduflex - تسجيل الدخول")
        self.resize(420, 480)

        self._is_first_run = not auth_service.has_any_account()
        self._build_ui()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.setContentsMargins(40, 40, 40, 40)

        card = QFrame()
        card.setObjectName("card")
        card.setMaximumWidth(360)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(32, 32, 32, 32)
        card_layout.setSpacing(14)

        title = QLabel("Eduflex")
        title.setObjectName("pageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(title)

        subtitle_text = "إنشاء حساب المدرس" if self._is_first_run else "تسجيل الدخول"
        subtitle = QLabel(subtitle_text)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(subtitle)
        card_layout.addSpacing(10)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("اسم المدرس")
        card_layout.addWidget(self.name_input)

        if self._is_first_run:
            self.subject_input = QLineEdit()
            self.subject_input.setPlaceholderText("المادة العلمية")
            card_layout.addWidget(self.subject_input)
        else:
            self.subject_input = None

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("كلمة المرور")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        card_layout.addWidget(self.password_input)

        if self._is_first_run:
            self.confirm_password_input = QLineEdit()
            self.confirm_password_input.setPlaceholderText("تأكيد كلمة المرور")
            self.confirm_password_input.setEchoMode(QLineEdit.EchoMode.Password)
            card_layout.addWidget(self.confirm_password_input)
        else:
            self.confirm_password_input = None

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        self.error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(self.error_label)

        submit_text = "إنشاء الحساب" if self._is_first_run else "دخول"
        self.submit_button = QPushButton(submit_text)
        self.submit_button.clicked.connect(self._on_submit)
        card_layout.addWidget(self.submit_button)

        self.password_input.returnPressed.connect(self._on_submit)

        outer.addWidget(card, alignment=Qt.AlignmentFlag.AlignCenter)

    def _on_submit(self) -> None:
        self.error_label.setText("")
        name = self.name_input.text().strip()
        password = self.password_input.text()

        try:
            if self._is_first_run:
                subject = self.subject_input.text().strip()
                confirm_password = self.confirm_password_input.text()
                if password != confirm_password:
                    raise EduflexError("كلمتا المرور غير متطابقتين.")
                auth_service.register_teacher(name, subject, password)
                auth_service.login(name, password)
            else:
                auth_service.login(name, password)

            self.login_succeeded.emit()
        except EduflexError as exc:
            self.error_label.setText(str(exc))
        except Exception as exc:
            show_error(self, exc)
