from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.licensing import license_service
from app.licensing.codec import LicenseCodeError
from app.utils.exceptions import EduflexError

_PLAN_LABELS = {"monthly": "شهري", "yearly": "سنوي"}
_REASON_MESSAGES = {
    "not_activated": "هذا الجهاز غير مفعّل. برجاء إدخال كود التفعيل.",
    "expired": "انتهت صلاحية الترخيص. برجاء إدخال كود تفعيل جديد.",
    "machine_mismatch": "كود التفعيل هذا مرتبط بجهاز آخر.",
    "corrupt": "تعذر التحقق من بيانات الترخيص. برجاء إدخال كود التفعيل مرة أخرى.",
}


class LicenseWindow(QWidget):
    activated = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Eduflex - تفعيل البرنامج")
        self.resize(460, 420)
        self._build_ui()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.setContentsMargins(40, 40, 40, 40)

        card = QFrame()
        card.setObjectName("card")
        card.setMaximumWidth(420)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(12)

        title = QLabel("تفعيل البرنامج")
        title.setObjectName("pageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        status = license_service.get_status()
        reason = status.get("reason", "not_activated")
        message = QLabel(_REASON_MESSAGES.get(reason, _REASON_MESSAGES["not_activated"]))
        message.setWordWrap(True)
        message.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(message)

        self.code_input = QPlainTextEdit()
        self.code_input.setPlaceholderText("الصق كود التفعيل هنا")
        self.code_input.setFixedHeight(120)
        layout.addWidget(self.code_input)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        self.error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.error_label)

        activate_button = QPushButton("تفعيل")
        activate_button.clicked.connect(self._on_activate)
        layout.addWidget(activate_button)

        outer.addWidget(card, alignment=Qt.AlignmentFlag.AlignCenter)

    def _on_activate(self) -> None:
        self.error_label.setText("")
        code = self.code_input.toPlainText().strip()
        if not code:
            self.error_label.setText("برجاء إدخال كود التفعيل.")
            return
        try:
            license_service.activate(code)
            self.activated.emit()
        except (LicenseCodeError, EduflexError) as exc:
            self.error_label.setText(str(exc))
