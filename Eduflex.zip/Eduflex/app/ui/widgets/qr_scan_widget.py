from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from app.qr.scanner import QRCameraScanner
from app.utils.exceptions import QRError
from app.utils.logger import get_logger

logger = get_logger(__name__)

_POLL_INTERVAL_MS = 200


def frame_to_pixmap(frame: "np.ndarray") -> QPixmap:
    rgb = np.ascontiguousarray(frame[:, :, ::-1])
    height, width, channels = rgb.shape
    bytes_per_line = channels * width
    image = QImage(rgb.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)
    return QPixmap.fromImage(image.copy())


class QRScanWidget(QWidget):
    qr_detected = Signal(str)
    camera_error = Signal(str)

    def __init__(self, scanner: QRCameraScanner | None = None) -> None:
        super().__init__()
        self._scanner = scanner or QRCameraScanner()
        self._timer = QTimer(self)
        self._timer.setInterval(_POLL_INTERVAL_MS)
        self._timer.timeout.connect(self._poll_frame)
        self._running = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.video_label = QLabel("الكاميرا متوقفة")
        self.video_label.setMinimumSize(320, 240)
        self.video_label.setStyleSheet("background-color: #1B2531; color: white; border-radius: 8px;")
        self.video_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.video_label)

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self) -> None:
        if self._running:
            return
        try:
            self._scanner.start()
        except QRError as exc:
            self.camera_error.emit(str(exc))
            return
        self._running = True
        self.video_label.setText("")
        self._timer.start()
        logger.info("QR scan widget started.")

    def stop(self) -> None:
        if not self._running:
            return
        self._timer.stop()
        self._scanner.stop()
        self._running = False
        self.video_label.setText("الكاميرا متوقفة")
        logger.info("QR scan widget stopped.")

    def _poll_frame(self) -> None:
        try:
            result = self._scanner.read_and_decode()
        except QRError as exc:
            self.stop()
            self.camera_error.emit(str(exc))
            return

        frame = getattr(self._scanner, "_last_frame", None)
        if frame is not None:
            self.video_label.setPixmap(
                frame_to_pixmap(frame).scaled(self.video_label.width(), self.video_label.height())
            )

        if result is not None:
            self.stop()
            self.qr_detected.emit(result.token)

    def closeEvent(self, event) -> None:
        self.stop()
        super().closeEvent(event)
