from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout

_BASE_COLOR = "#02C4EF"
_HOVER_COLOR = "#00AEDB"


class ReportCard(QFrame):
    clicked = Signal()

    def __init__(self, title: str, icon, parent=None) -> None:
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(110)
        self._apply_background(_BASE_COLOR)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 14)
        layout.setSpacing(6)

        top_row = QHBoxLayout()
        title_label = QLabel(title)
        title_label.setStyleSheet("color: white; font-size: 16px; font-weight: 700;")
        title_label.setWordWrap(True)
        top_row.addWidget(title_label, 1)

        icon_label = QLabel()
        icon_label.setPixmap(icon.pixmap(30, 30))
        top_row.addWidget(icon_label, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(top_row)

        layout.addStretch()

        details_label = QLabel("تفاصيل")
        details_label.setStyleSheet("color: white; font-size: 12px; text-decoration: underline;")
        details_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(details_label)

    def _apply_background(self, color: str) -> None:
        self.setStyleSheet(
            f"QFrame {{ background-color: {color}; border-radius: 12px; border: none; }}"
        )

    def enterEvent(self, event) -> None:
        self._apply_background(_HOVER_COLOR)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        self._apply_background(_BASE_COLOR)
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)
