from __future__ import annotations

from PySide6.QtCore import QUrl, Signal, Qt
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from app.ui.theme import SIDEBAR_WIDTH

APP_VERSION = "1.0.0"
GITHUB_URL = "https://github.com/BassemMohamed44"

NAV_ITEMS = [
    ("dashboard", "لوحة التحكم"),
    ("students", "الطلاب"),
    ("classes", "الحصص"),
    ("attendance", "الحضور والانصراف"),
    ("subscriptions", "الاشتراكات"),
    ("exams", "الاختبارات"),
    ("reports", "التقارير"),
    ("backup", "النسخ الاحتياطي"),
    ("settings", "الإعدادات"),
    ("about", "من نحن"),
    ("services", "خدماتنا"),
]

_GITHUB_ICON_SVG = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16" fill="#AEB6C2">
<path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38
0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01
1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95
0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68
0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82
2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01
8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>
</svg>
"""


class Sidebar(QFrame):
    navigate = Signal(str)
    logout_requested = Signal()

    def __init__(self, teacher_name: str, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(SIDEBAR_WIDTH)

        self._buttons: dict[str, QPushButton] = {}
        self._active_key: str | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 24, 12, 16)
        layout.setSpacing(6)

        brand = QLabel("Eduflex")
        brand.setStyleSheet("color: white; font-size: 20px; font-weight: 800; padding: 0 8px 16px 8px;")
        brand.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(brand)

        greeting = QLabel(teacher_name)
        greeting.setStyleSheet("color: #AEB6C2; font-size: 12px; padding: 0 8px 16px 8px;")
        greeting.setWordWrap(True)
        greeting.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(greeting)

        for key, label in NAV_ITEMS:
            button = QPushButton(label)
            button.setObjectName("sidebarButton")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
            button.clicked.connect(lambda _checked=False, k=key: self.navigate.emit(k))
            layout.addWidget(button)
            self._buttons[key] = button

        layout.addStretch()

        logout_button = QPushButton("تسجيل الخروج")
        logout_button.setObjectName("sidebarButton")
        logout_button.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        logout_button.clicked.connect(self.logout_requested.emit)
        layout.addWidget(logout_button)

        footer = QHBoxLayout()
        footer.setContentsMargins(8, 12, 8, 0)

        version_label = QLabel(f"الإصدار {APP_VERSION}")
        version_label.setStyleSheet("color: #6B7280; font-size: 11px;")
        footer.addWidget(version_label)
        footer.addStretch()

        github_button = QPushButton()
        github_button.setObjectName("sidebarButton")
        github_button.setFixedSize(28, 28)
        github_button.setCursor(Qt.CursorShape.PointingHandCursor)
        github_button.setToolTip(GITHUB_URL)
        github_button.setStyleSheet("padding: 4px;")
        from PySide6.QtGui import QIcon, QPixmap
        pixmap = QPixmap()
        pixmap.loadFromData(_GITHUB_ICON_SVG.encode("utf-8"), "SVG")
        github_button.setIcon(QIcon(pixmap))
        github_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(GITHUB_URL)))
        footer.addWidget(github_button)

        layout.addLayout(footer)

        self.set_active("dashboard")

    def set_active(self, key: str) -> None:
        if self._active_key and self._active_key in self._buttons:
            self._buttons[self._active_key].setObjectName("sidebarButton")
            self._buttons[self._active_key].setStyle(self._buttons[self._active_key].style())

        if key in self._buttons:
            self._buttons[key].setObjectName("sidebarButtonActive")
            self._buttons[key].setStyle(self._buttons[key].style())
            self._active_key = key
