from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QAbstractSpinBox, QLabel, QMessageBox, QWidget

from app.utils.exceptions import EduflexError


def styled_form_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("formLabel")
    label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    return label


def no_spin_arrows(spinbox) -> None:
    spinbox.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)


def show_error(parent: QWidget | None, error: Exception, title: str = "خطأ") -> None:
    if isinstance(error, EduflexError):
        message = str(error)
    else:
        message = "حدث خطأ غير متوقع. برجاء المحاولة مرة أخرى."
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Critical)
    box.setWindowTitle(title)
    box.setText(message)
    box.setLayoutDirection_ = None
    box.exec()


def show_info(parent: QWidget | None, message: str, title: str = "تم") -> None:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Information)
    box.setWindowTitle(title)
    box.setText(message)
    box.exec()


def confirm(parent: QWidget | None, message: str, title: str = "تأكيد") -> bool:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Question)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    box.setDefaultButton(QMessageBox.StandardButton.No)
    return box.exec() == QMessageBox.StandardButton.Yes
