from __future__ import annotations

import datetime as dt

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from app.models.student import StudentStatus
from app.services import student_service, subscription_service
from app.ui.helpers import no_spin_arrows, show_error, styled_form_label
from app.utils.exceptions import EduflexError

_STATUS_LABELS = {
    StudentStatus.ACTIVE: "نشط",
    StudentStatus.SUSPENDED: "موقوف",
    StudentStatus.ARCHIVED: "مؤرشف",
}


class StudentDialog(QDialog):

    def __init__(self, parent=None, student: dict | None = None) -> None:
        super().__init__(parent)
        self._existing = student
        self.setWindowTitle("تعديل بيانات طالب" if student else "إضافة طالب جديد")
        self.setMinimumWidth(420)
        self._build_ui()
        if student:
            self._populate(student)

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.full_name_input = QLineEdit()
        form.addRow(styled_form_label("اسم الطالب *"), self.full_name_input)

        self.grade_level_input = QLineEdit()
        form.addRow(styled_form_label("الصف الدراسي *"), self.grade_level_input)

        self.lesson_time_input = QLineEdit()
        form.addRow(styled_form_label("موعد الدرس"), self.lesson_time_input)

        self.price_input = QDoubleSpinBox()
        self.price_input.setRange(0, 1_000_000)
        self.price_input.setDecimals(2)
        self.price_input.setSuffix(" جنيه")
        no_spin_arrows(self.price_input)
        form.addRow(styled_form_label("سعر الاشتراك"), self.price_input)

        self.center_name_input = QLineEdit()
        form.addRow(styled_form_label("اسم السنتر"), self.center_name_input)

        self.student_phone_input = QLineEdit()
        form.addRow(styled_form_label("رقم الطالب"), self.student_phone_input)

        self.guardian_phone_input = QLineEdit()
        form.addRow(styled_form_label("رقم ولي الأمر"), self.guardian_phone_input)

        self.sub_start_input = QDateEdit()
        self.sub_start_input.setCalendarPopup(True)
        self.sub_start_input.setDate(dt.date.today())
        form.addRow(styled_form_label("بداية الاشتراك"), self.sub_start_input)

        self.sub_end_input = QDateEdit()
        self.sub_end_input.setCalendarPopup(True)
        self.sub_end_input.setDate(dt.date.today() + dt.timedelta(days=30))
        form.addRow(styled_form_label("نهاية الاشتراك"), self.sub_end_input)

        if self._existing:
            self.status_input = QComboBox()
            for status, label in _STATUS_LABELS.items():
                self.status_input.addItem(label, status)
            form.addRow(styled_form_label("حالة الطالب"), self.status_input)
        else:
            self.status_input = None

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QHBoxLayout()
        self.save_button = QPushButton("حفظ")
        self.save_button.clicked.connect(self._on_save)
        self.cancel_button = QPushButton("إلغاء")
        self.cancel_button.setObjectName("secondaryButton")
        self.cancel_button.clicked.connect(self.reject)
        buttons.addWidget(self.save_button)
        buttons.addWidget(self.cancel_button)
        layout.addLayout(buttons)

    def _populate(self, student: dict) -> None:
        self.full_name_input.setText(student["full_name"])
        self.grade_level_input.setText(student["grade_level"])
        self.lesson_time_input.setText(student.get("lesson_time") or "")
        self.price_input.setValue(float(student.get("subscription_price") or 0))
        self.center_name_input.setText(student.get("center_name") or "")
        self.student_phone_input.setText(student.get("student_phone") or "")
        self.guardian_phone_input.setText(student.get("guardian_phone") or "")
        if student.get("subscription_start"):
            self.sub_start_input.setDate(student["subscription_start"])
        if student.get("subscription_end"):
            self.sub_end_input.setDate(student["subscription_end"])
        if self.status_input is not None:
            idx = self.status_input.findData(student["status"])
            if idx >= 0:
                self.status_input.setCurrentIndex(idx)

    def _on_save(self) -> None:
        self.error_label.setText("")
        try:
            kwargs = dict(
                full_name=self.full_name_input.text(),
                grade_level=self.grade_level_input.text(),
                lesson_time=self.lesson_time_input.text(),
                subscription_price=self.price_input.value(),
                center_name=self.center_name_input.text(),
                student_phone=self.student_phone_input.text(),
                guardian_phone=self.guardian_phone_input.text(),
                subscription_start=self.sub_start_input.date().toPython(),
                subscription_end=self.sub_end_input.date().toPython(),
            )
            if self._existing:
                if self.status_input is not None:
                    kwargs["status"] = self.status_input.currentData()
                student_service.update_student(self._existing["id"], **kwargs)
            else:
                created = student_service.create_student(**kwargs)
                if kwargs["subscription_price"] > 0:
                    subscription_service.create_subscription(
                        student_id=created["id"],
                        start_date=kwargs["subscription_start"],
                        end_date=kwargs["subscription_end"],
                        price=kwargs["subscription_price"],
                    )
            self.accept()
        except EduflexError as exc:
            self.error_label.setText(str(exc))
        except Exception as exc:
            show_error(self, exc)
