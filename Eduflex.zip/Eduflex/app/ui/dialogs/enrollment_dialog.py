from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
)

from app.services import class_service, student_service
from app.ui.helpers import show_error
from app.utils.exceptions import EduflexError


class EnrollmentDialog(QDialog):
    def __init__(self, parent, class_session: dict) -> None:
        super().__init__(parent)
        self.class_session = class_session
        self.setWindowTitle(f"طلاب حصة: {class_session['subject']}")
        self.setMinimumSize(400, 420)
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        add_row = QHBoxLayout()
        self.student_picker = QComboBox()
        add_row.addWidget(self.student_picker, 3)
        add_button = QPushButton("تسجيل")
        add_button.clicked.connect(self._on_enroll)
        add_row.addWidget(add_button, 1)
        layout.addLayout(add_row)

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        remove_button = QPushButton("إلغاء تسجيل المحدد")
        remove_button.setObjectName("dangerButton")
        remove_button.clicked.connect(self._on_unenroll)
        layout.addWidget(remove_button)

        close_button = QPushButton("إغلاق")
        close_button.setObjectName("secondaryButton")
        close_button.clicked.connect(self.accept)
        layout.addWidget(close_button)

    def refresh(self) -> None:
        try:
            enrolled = class_service.list_students_for_class(self.class_session["id"])
            all_students = student_service.list_students()
        except EduflexError as exc:
            show_error(self, exc)
            return

        enrolled_ids = {s["id"] for s in enrolled}

        self.list_widget.clear()
        for s in enrolled:
            item = QListWidgetItem(f"{s['full_name']} ({s['student_code']})")
            item.setData(1, s["id"])
            self.list_widget.addItem(item)

        self.student_picker.clear()
        for s in all_students:
            if s["id"] not in enrolled_ids:
                self.student_picker.addItem(f"{s['full_name']} ({s['student_code']})", s["id"])

    def _on_enroll(self) -> None:
        student_id = self.student_picker.currentData()
        if student_id is None:
            return
        try:
            class_service.enroll_student(student_id, self.class_session["id"])
            self.refresh()
        except EduflexError as exc:
            show_error(self, exc)

    def _on_unenroll(self) -> None:
        item = self.list_widget.currentItem()
        if item is None:
            return
        student_id = item.data(1)
        try:
            class_service.unenroll_student(student_id, self.class_session["id"])
            self.refresh()
        except EduflexError as exc:
            show_error(self, exc)
