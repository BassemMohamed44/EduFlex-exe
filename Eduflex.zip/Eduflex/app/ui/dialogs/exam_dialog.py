from __future__ import annotations

import datetime as dt

from PySide6.QtWidgets import (
    QDateEdit, QDialog, QDoubleSpinBox, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QVBoxLayout,
)

from app.services import exam_service
from app.ui.helpers import no_spin_arrows, show_error, styled_form_label
from app.utils.exceptions import EduflexError


class ExamDialog(QDialog):
    def __init__(self, parent=None, exam: dict | None = None) -> None:
        super().__init__(parent)
        self._existing = exam
        self.setWindowTitle("تعديل اختبار" if exam else "إضافة اختبار جديد")
        self.setMinimumWidth(380)
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.name_input = QLineEdit()
        form.addRow(styled_form_label("اسم الاختبار *"), self.name_input)
        self.subject_input = QLineEdit()
        form.addRow(styled_form_label("المادة *"), self.subject_input)
        self.grade_input = QLineEdit()
        form.addRow(styled_form_label("الصف الدراسي *"), self.grade_input)
        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)
        self.date_input.setDate(dt.date.today())
        form.addRow(styled_form_label("التاريخ"), self.date_input)
        self.max_score_input = QDoubleSpinBox()
        self.max_score_input.setRange(1, 1000)
        self.max_score_input.setValue(100)
        no_spin_arrows(self.max_score_input)
        form.addRow(styled_form_label("الدرجة النهائية *"), self.max_score_input)
        self.notes_input = QTextEdit()
        self.notes_input.setMaximumHeight(70)
        form.addRow(styled_form_label("ملاحظات"), self.notes_input)
        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QHBoxLayout()
        save_btn = QPushButton("حفظ")
        save_btn.clicked.connect(self._on_save)
        cancel_btn = QPushButton("إلغاء")
        cancel_btn.setObjectName("secondaryButton")
        cancel_btn.clicked.connect(self.reject)
        buttons.addWidget(save_btn)
        buttons.addWidget(cancel_btn)
        layout.addLayout(buttons)

        if exam:
            self.name_input.setText(exam["name"])
            self.subject_input.setText(exam["subject"])
            self.grade_input.setText(exam["grade_level"])
            self.date_input.setDate(exam["exam_date"])
            self.max_score_input.setValue(float(exam["max_score"]))
            self.notes_input.setPlainText(exam.get("notes") or "")

    def _on_save(self) -> None:
        self.error_label.setText("")
        try:
            kwargs = dict(
                name=self.name_input.text(),
                subject=self.subject_input.text(),
                exam_date=self.date_input.date().toPython(),
                max_score=self.max_score_input.value(),
                grade_level=self.grade_input.text(),
                notes=self.notes_input.toPlainText(),
            )
            if self._existing:
                exam_service.update_exam(self._existing["id"], **kwargs)
            else:
                exam_service.create_exam(**kwargs)
            self.accept()
        except EduflexError as exc:
            self.error_label.setText(str(exc))
        except Exception as exc:
            show_error(self, exc)
