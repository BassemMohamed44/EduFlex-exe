from __future__ import annotations

import datetime as dt

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from app.services import exam_service, export_service, report_service
from app.ui.helpers import show_error, show_info
from app.utils.exceptions import EduflexError


class ReportDetailDialog(QDialog):
    def __init__(self, parent, kind: str, title: str) -> None:
        super().__init__(parent)
        self.kind = kind
        self.setWindowTitle(title)
        self.setMinimumSize(560, 480)
        self._current_extra = None
        self._build_ui(title)
        self._load_data()

    def _build_ui(self, title: str) -> None:
        layout = QVBoxLayout(self)

        title_label = QLabel(title)
        title_label.setObjectName("pageTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(title_label)

        controls = QHBoxLayout()
        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)
        self.date_input.setDate(dt.date.today())
        self.date_input.setVisible(self.kind == "daily_attendance")
        controls.addWidget(self.date_input)

        self.exam_picker = QComboBox()
        self.exam_picker.setVisible(self.kind == "exam_results")
        controls.addWidget(self.exam_picker)
        controls.addStretch()
        layout.addLayout(controls)

        self.table = QTableWidget(0, 0)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.table)

        export_row = QHBoxLayout()
        pdf_btn = QPushButton("تصدير PDF")
        pdf_btn.clicked.connect(lambda: self._on_export("pdf"))
        excel_btn = QPushButton("تصدير Excel")
        excel_btn.setObjectName("secondaryButton")
        excel_btn.clicked.connect(lambda: self._on_export("excel"))
        export_row.addWidget(pdf_btn)
        export_row.addWidget(excel_btn)
        export_row.addStretch()
        layout.addLayout(export_row)

        if self.kind == "exam_results":
            try:
                for e in exam_service.list_exams():
                    self.exam_picker.addItem(e["name"], e["id"])
            except EduflexError:
                pass

        self.date_input.dateChanged.connect(self._load_data)
        self.exam_picker.currentIndexChanged.connect(self._load_data)

    def _set_table(self, headers: list[str], rows: list[list]) -> None:
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))

    def _load_data(self) -> None:
        try:
            if self.kind == "attendance_totals":
                data = report_service.attendance_totals_report()
                self._set_table(
                    ["المعرف", "الاسم", "أيام الحضور", "أيام الغياب"],
                    [[d["student_code"], d["full_name"], d["present_count"], d["absent_count"]] for d in data],
                )
            elif self.kind == "daily_attendance":
                date = self.date_input.date().toPython()
                self._current_extra = date
                data = report_service.daily_attendance_report(date)
                rows = []
                for d in data:
                    check_in = d["check_in_time"].strftime("%H:%M") if d["check_in_time"] else "-"
                    check_out = d["check_out_time"].strftime("%H:%M") if d["check_out_time"] else "-"
                    rows.append([d["student_code"], d["full_name"], d["status"].value, check_in, check_out])
                self._set_table(["المعرف", "الاسم", "الحالة", "حضور", "خروج"], rows)
            elif self.kind == "exam_results":
                exam_id = self.exam_picker.currentData()
                self._current_extra = exam_id
                if exam_id is None:
                    self._set_table(["لا توجد اختبارات"], [])
                    return
                data = report_service.exam_results_report(exam_id)
                self._set_table(
                    ["المعرف", "الاسم", "الدرجة", "من"],
                    [[r["student_code"], r["full_name"], r["score"], r["max_score"]] for r in data["results"]],
                )
            elif self.kind == "expired_subscriptions":
                data = report_service.expired_subscriptions_report()
                self._set_table(
                    ["المعرف", "الاسم", "تاريخ الانتهاء", "السعر"],
                    [[d["student_code"], d["full_name"], d["end_date"].isoformat(), d["price"]] for d in data],
                )
            elif self.kind == "comprehensive_statistics":
                data = report_service.comprehensive_statistics_report()
                self._set_table(
                    ["المؤشر", "القيمة"],
                    [
                        ["عدد الطلاب", data["number_of_students"]],
                        ["نسبة الحضور اليوم (%)", data["attendance_rate"]],
                        ["نسبة الغياب اليوم (%)", data["absence_rate"]],
                        ["متوسط درجات الاختبارات (%)", data["average_exam_score_percent"] or "-"],
                        ["الاشتراكات النشطة", data["active_subscriptions"]],
                        ["الاشتراكات المنتهية", data["expired_subscriptions"]],
                    ],
                )
        except EduflexError as exc:
            show_error(self, exc)

    def _on_export(self, fmt: str) -> None:
        ext = "pdf" if fmt == "pdf" else "xlsx"
        destination, _ = QFileDialog.getSaveFileName(self, "حفظ التقرير", f"report.{ext}", f"*.{ext}")
        if not destination:
            return
        try:
            if self.kind == "attendance_totals":
                export_service.export_attendance_totals(fmt, destination)
            elif self.kind == "daily_attendance":
                export_service.export_daily_attendance(self._current_extra, fmt, destination)
            elif self.kind == "exam_results":
                if self._current_extra is None:
                    show_error(self, EduflexError("لا يوجد اختبار محدد للتصدير."))
                    return
                export_service.export_exam_results(self._current_extra, fmt, destination)
            elif self.kind == "expired_subscriptions":
                export_service.export_expired_subscriptions(fmt, destination)
            elif self.kind == "comprehensive_statistics":
                export_service.export_comprehensive_statistics(fmt, destination)
            show_info(self, "تم تصدير التقرير بنجاح.")
        except EduflexError as exc:
            show_error(self, exc)
