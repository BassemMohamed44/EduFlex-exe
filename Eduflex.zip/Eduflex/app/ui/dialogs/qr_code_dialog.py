from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtPrintSupport import QPrintDialog, QPrinter
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from app.qr import qr_service
from app.ui.helpers import confirm, show_error, show_info
from app.utils.exceptions import EduflexError


class QRCodeDialog(QDialog):
    def __init__(self, parent, student: dict) -> None:
        super().__init__(parent)
        self.student = student
        self.setWindowTitle(f"رمز QR - {student['full_name']}")
        self.setMinimumWidth(360)
        self._build_ui()
        self._load_qr()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        name_label = QLabel(f"{self.student['full_name']} ({self.student['student_code']})")
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name_label.setStyleSheet("font-weight: 700; font-size: 15px;")
        layout.addWidget(name_label)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setMinimumSize(280, 280)
        layout.addWidget(self.image_label)

        buttons = QHBoxLayout()
        self.regenerate_button = QPushButton("إعادة إنشاء")
        self.regenerate_button.setObjectName("secondaryButton")
        self.regenerate_button.clicked.connect(self._on_regenerate)

        self.save_button = QPushButton("حفظ كـ PNG")
        self.save_button.setObjectName("secondaryButton")
        self.save_button.clicked.connect(self._on_save)

        self.print_button = QPushButton("طباعة")
        self.print_button.clicked.connect(self._on_print)

        buttons.addWidget(self.regenerate_button)
        buttons.addWidget(self.save_button)
        buttons.addWidget(self.print_button)
        layout.addLayout(buttons)

    def _load_qr(self) -> None:
        try:
            self._current_path = qr_service.get_qr_file_path(self.student["id"])
            self.image_label.setPixmap(
                QPixmap(self._current_path).scaled(
                    280, 280, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation
                )
            )
        except EduflexError as exc:
            show_error(self, exc)

    def _on_regenerate(self) -> None:
        if not confirm(
            self,
            "سيتم إلغاء رمز QR القديم نهائيًا ولن يعمل بعد الآن. هل تريد المتابعة؟",
            "تأكيد إعادة الإنشاء",
        ):
            return
        try:
            qr_service.regenerate_qr_for_student(self.student["id"])
            self._load_qr()
            show_info(self, "تم إنشاء رمز QR جديد بنجاح.")
        except EduflexError as exc:
            show_error(self, exc)

    def _on_save(self) -> None:
        destination, _ = QFileDialog.getSaveFileName(
            self, "حفظ رمز QR", f"student_{self.student['student_code']}.png", "PNG Files (*.png)"
        )
        if not destination:
            return
        try:
            qr_service.export_qr_as_png(self.student["id"], destination)
            show_info(self, "تم حفظ الملف بنجاح.")
        except EduflexError as exc:
            show_error(self, exc)

    def _on_print(self) -> None:
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            from PySide6.QtGui import QPainter

            pixmap = QPixmap(self._current_path)
            painter = QPainter(printer)
            rect = painter.viewport()
            scaled = pixmap.scaled(rect.size(), Qt.AspectRatioMode.KeepAspectRatio)
            painter.drawPixmap(0, 0, scaled)
            painter.end()
        except Exception as exc:
            show_error(self, exc)
