from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from app.models.class_session import ClassStatus
from app.services import class_service
from app.ui.helpers import no_spin_arrows, show_error, styled_form_label
from app.utils.exceptions import EduflexError

_STATUS_LABELS = {ClassStatus.ACTIVE: "نشطة", ClassStatus.INACTIVE: "غير نشطة"}


class ClassDialog(QDialog):
    def __init__(self, parent=None, class_session: dict | None = None) -> None:
        super().__init__(parent)
        self._existing = class_session
        self.setWindowTitle("تعديل حصة" if class_session else "إضافة حصة جديدة")
        self.setMinimumWidth(380)
        self._build_ui()
        if class_session:
            self._populate(class_session)

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.subject_input = QLineEdit()
        form.addRow(styled_form_label("المادة *"), self.subject_input)

        self.days_input = QLineEdit()
        self.days_input.setPlaceholderText("مثال: Sat,Mon,Wed")
        form.addRow(styled_form_label("أيام الدرس *"), self.days_input)

        self.time_input = QLineEdit()
        self.time_input.setPlaceholderText("مثال: 4-6 PM")
        form.addRow(styled_form_label("موعد الدرس *"), self.time_input)

        self.price_input = QDoubleSpinBox()
        self.price_input.setRange(0, 1_000_000)
        self.price_input.setSuffix(" جنيه")
        no_spin_arrows(self.price_input)
        form.addRow(styled_form_label("السعر"), self.price_input)

        self.center_input = QLineEdit()
        form.addRow(styled_form_label("اسم السنتر"), self.center_input)

        if self._existing:
            self.status_input = QComboBox()
            for status, label in _STATUS_LABELS.items():
                self.status_input.addItem(label, status)
            form.addRow(styled_form_label("الحالة"), self.status_input)
        else:
            self.status_input = None

        layout.addLayout(form)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        buttons = QHBoxLayout()
        self.save_button = QPushButton("حفظ")
        self.save_button.clicked.connect(self._on_save)
        self.cancel_button = QPushButton("إلغاء")
        self.cancel_button.setObjectName("secondaryButton")
        self.cancel_button.clicked.connect(self.reject)
        buttons.addWidget(self.save_button)
        buttons.addWidget(self.cancel_button)
        layout.addLayout(buttons)

    def _populate(self, c: dict) -> None:
        self.subject_input.setText(c["subject"])
        self.days_input.setText(c["days_of_week"])
        self.time_input.setText(c["time_slot"])
        self.price_input.setValue(float(c["price"]))
        self.center_input.setText(c.get("center_name") or "")
        if self.status_input is not None:
            idx = self.status_input.findData(c["status"])
            if idx >= 0:
                self.status_input.setCurrentIndex(idx)

    def _on_save(self) -> None:
        self.error_label.setText("")
        try:
            kwargs = dict(
                subject=self.subject_input.text(),
                days_of_week=self.days_input.text(),
                time_slot=self.time_input.text(),
                price=self.price_input.value(),
                center_name=self.center_input.text(),
            )
            if self._existing:
                if self.status_input is not None:
                    kwargs["status"] = self.status_input.currentData()
                class_service.update_class(self._existing["id"], **kwargs)
            else:
                class_service.create_class(**kwargs)
            self.accept()
        except EduflexError as exc:
            self.error_label.setText(str(exc))
        except Exception as exc:
            show_error(self, exc)
