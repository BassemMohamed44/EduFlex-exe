from __future__ import annotations

from PySide6.QtWidgets import QDialog, QLabel, QPlainTextEdit, QPushButton, QVBoxLayout

from app.licensing import license_service
from app.licensing.codec import LicenseCodeError
from app.utils.exceptions import EduflexError


class RenewLicenseDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("تجديد الترخيص")
        self.setMinimumWidth(420)

        layout = QVBoxLayout(self)
        label = QLabel("الصق كود التفعيل الجديد:")
        layout.addWidget(label)

        self.code_input = QPlainTextEdit()
        self.code_input.setFixedHeight(120)
        layout.addWidget(self.code_input)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        layout.addWidget(self.error_label)

        activate_btn = QPushButton("تفعيل")
        activate_btn.clicked.connect(self._on_activate)
        layout.addWidget(activate_btn)

    def _on_activate(self) -> None:
        self.error_label.setText("")
        code = self.code_input.toPlainText().strip()
        if not code:
            self.error_label.setText("برجاء إدخال كود التفعيل.")
            return
        try:
            license_service.activate(code)
            self.accept()
        except (LicenseCodeError, EduflexError) as exc:
            self.error_label.setText(str(exc))
