from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox, QDialog, QDoubleSpinBox, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from app.services import exam_service, student_service
from app.ui.helpers import show_error
from app.utils.exceptions import EduflexError


class ExamResultsDialog(QDialog):
    def __init__(self, parent, exam: dict) -> None:
        super().__init__(parent)
        self.exam = exam
        self.setWindowTitle(f"درجات: {exam['name']}")
        self.setMinimumSize(420, 460)
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        add_row = QHBoxLayout()
        self.student_picker = QComboBox()
        add_row.addWidget(self.student_picker, 2)
        self.score_input = QDoubleSpinBox()
        self.score_input.setRange(0, float(self.exam["max_score"]))
        add_row.addWidget(self.score_input, 1)
        add_btn = QPushButton("تسجيل")
        add_btn.clicked.connect(self._on_record)
        add_row.addWidget(add_btn, 1)
        layout.addLayout(add_row)

        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        layout.addWidget(self.error_label)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["الطالب", "الدرجة", "من"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)

        stats_label = QLabel()
        self.stats_label = stats_label
        layout.addWidget(stats_label)

        close_btn = QPushButton("إغلاق")
        close_btn.setObjectName("secondaryButton")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def refresh(self) -> None:
        try:
            results = exam_service.list_results_for_exam(self.exam["id"])
            all_students = student_service.list_students()
            stats = exam_service.get_exam_statistics(self.exam["id"])
        except EduflexError as exc:
            show_error(self, exc)
            return

        recorded_ids = {r["student_id"] for r in results}
        by_id = {s["id"]: s for s in all_students}

        self.student_picker.clear()
        for s in all_students:
            if s["id"] not in recorded_ids:
                self.student_picker.addItem(f"{s['full_name']} ({s['student_code']})", s["id"])

        self.table.setRowCount(len(results))
        for row, r in enumerate(results):
            student = by_id.get(r["student_id"])
            name = student["full_name"] if student else "-"
            self.table.setItem(row, 0, QTableWidgetItem(name))
            self.table.setItem(row, 1, QTableWidgetItem(str(r["score"])))
            self.table.setItem(row, 2, QTableWidgetItem(str(self.exam["max_score"])))

        if stats["count"]:
            self.stats_label.setText(
                f"المتوسط: {stats['average']} | الأعلى: {stats['highest']} | "
                f"الأقل: {stats['lowest']} | نسبة النجاح: {stats['pass_rate']}%"
            )
        else:
            self.stats_label.setText("لا توجد نتائج مسجلة بعد.")

    def _on_record(self) -> None:
        self.error_label.setText("")
        student_id = self.student_picker.currentData()
        if student_id is None:
            return
        try:
            exam_service.record_result(self.exam["id"], student_id, self.score_input.value())
            self.refresh()
        except EduflexError as exc:
            self.error_label.setText(str(exc))
