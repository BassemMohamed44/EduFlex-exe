from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

APP_NAME = "Eduflex"
APP_ORG = "EduflexSoftware"


def _is_frozen() -> bool:
    return getattr(sys, "frozen", False)


def get_app_data_dir() -> Path:
    if sys.platform == "win32":
        base = os.environ.get("APPDATA")
        if not base:
            base = str(Path.home() / "AppData" / "Roaming")
        root = Path(base) / APP_NAME
    elif sys.platform == "darwin":
        root = Path.home() / "Library" / "Application Support" / APP_NAME
    else:
        base = os.environ.get("XDG_DATA_HOME")
        if not base:
            base = str(Path.home() / ".local" / "share")
        root = Path(base) / APP_NAME

    root.mkdir(parents=True, exist_ok=True)
    return root


@dataclass
class AppPaths:

    root: Path = field(default_factory=get_app_data_dir)

    @property
    def database_file(self) -> Path:
        return self.root / "eduflex.db"

    @property
    def backups_dir(self) -> Path:
        d = self.root / "backups"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def qr_dir(self) -> Path:
        d = self.root / "qr_codes"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def logs_dir(self) -> Path:
        d = self.root / "logs"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def exports_dir(self) -> Path:
        d = self.root / "exports"
        d.mkdir(parents=True, exist_ok=True)
        return d

    @property
    def settings_file(self) -> Path:
        return self.root / "settings.json"


class Settings:

    DEFAULTS = {
        "language": "ar",
        "last_backup_path": None,
        "subscription_warning_days": 7,
        "window_geometry": None,
    }

    def __init__(self, paths: AppPaths | None = None) -> None:
        self.paths = paths or AppPaths()
        self._data: dict = dict(self.DEFAULTS)
        self.load()

    def load(self) -> None:
        if self.paths.settings_file.exists():
            try:
                with open(self.paths.settings_file, "r", encoding="utf-8") as f:
                    stored = json.load(f)
                self._data.update(stored)
            except (json.JSONDecodeError, OSError):
                self._data = dict(self.DEFAULTS)

    def save(self) -> None:
        with open(self.paths.settings_file, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False, indent=2)

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        self._data[key] = value
        self.save()


_paths_instance: AppPaths | None = None
_settings_instance: Settings | None = None


def get_paths() -> AppPaths:
    global _paths_instance
    if _paths_instance is None:
        _paths_instance = AppPaths()
    return _paths_instance


def get_settings() -> Settings:
    global _settings_instance
    if _settings_instance is None:
        _settings_instance = Settings(get_paths())
    return _settings_instance


def reset_for_tests(tmp_root: Path) -> None:
    global _paths_instance, _settings_instance
    _paths_instance = AppPaths(root=tmp_root)
    _settings_instance = Settings(_paths_instance)
