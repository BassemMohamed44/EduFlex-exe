from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.engine import Engine

from app.utils.logger import get_logger

logger = get_logger(__name__)

SCHEMA_VERSION_KEY = "schema_version"


def _get_current_version(conn) -> int:
    result = conn.execute(
        text("SELECT value FROM settings WHERE key = :key"), {"key": SCHEMA_VERSION_KEY}
    ).fetchone()
    return int(result[0]) if result else 0


def _set_current_version(conn, version: int) -> None:
    conn.execute(
        text(
            "INSERT INTO settings (key, value, created_at, updated_at) "
            "VALUES (:key, :value, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) "
            "ON CONFLICT(key) DO UPDATE SET value = :value, updated_at = CURRENT_TIMESTAMP"
        ),
        {"key": SCHEMA_VERSION_KEY, "value": str(version)},
    )


MIGRATIONS: list[tuple[int, callable]] = []


def run_migrations(engine: Engine) -> None:
    with engine.begin() as conn:
        current = _get_current_version(conn)
        applied = 0
        for version, migration_fn in sorted(MIGRATIONS, key=lambda m: m[0]):
            if version <= current:
                continue
            logger.info("Applying migration %s", version)
            migration_fn(conn)
            _set_current_version(conn, version)
            applied += 1
        if applied:
            logger.info("Applied %d migration(s).", applied)
