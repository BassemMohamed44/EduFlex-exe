from __future__ import annotations

from app.database.session import get_engine
from app.database.migrations import run_migrations
from app.models import Base
from app.utils.logger import get_logger

logger = get_logger(__name__)


def init_database() -> None:
    engine = get_engine()
    Base.metadata.create_all(bind=engine)
    logger.info("Database schema ensured (create_all complete).")
    run_migrations(engine)
