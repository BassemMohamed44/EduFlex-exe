from __future__ import annotations

import secrets

TOKEN_BYTES = 16
QR_PREFIX = "EDUFLEX:STUDENT:"


def generate_token() -> str:
    return secrets.token_urlsafe(TOKEN_BYTES)


def build_qr_payload(token: str) -> str:
    return f"{QR_PREFIX}{token}"


def parse_qr_payload(payload: str) -> str | None:
    if not payload or not payload.startswith(QR_PREFIX):
        return None
    token = payload[len(QR_PREFIX):].strip()
    return token or None
