from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from pyzbar.pyzbar import decode as zbar_decode

from app.qr.token import parse_qr_payload
from app.utils.exceptions import QRError
from app.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class ScanResult:
    token: str
    raw_payload: str


def decode_frame(frame: "np.ndarray") -> Optional[ScanResult]:
    try:
        decoded_objects = zbar_decode(frame)
    except Exception as exc:
        logger.error("QR frame decode failed: %s", exc)
        raise QRError("تعذرت قراءة الكاميرا.") from exc

    for obj in decoded_objects:
        payload = obj.data.decode("utf-8", errors="ignore")
        token = parse_qr_payload(payload)
        if token:
            return ScanResult(token=token, raw_payload=payload)
    return None


def decode_image_file(path: str) -> Optional[ScanResult]:
    from PIL import Image

    with Image.open(path) as img:
        decoded_objects = zbar_decode(img)

    for obj in decoded_objects:
        payload = obj.data.decode("utf-8", errors="ignore")
        token = parse_qr_payload(payload)
        if token:
            return ScanResult(token=token, raw_payload=payload)
    return None


class QRCameraScanner:

    def __init__(self, camera_index: int = 0) -> None:
        self.camera_index = camera_index
        self._capture = None
        self._last_frame = None

    def start(self) -> None:
        import cv2

        self._capture = cv2.VideoCapture(self.camera_index)
        if not self._capture.isOpened():
            self._capture = None
            raise QRError("تعذر فتح الكاميرا. تأكد من توصيلها وعدم استخدامها ببرنامج آخر.")
        logger.info("Camera scanner started (index=%s).", self.camera_index)

    def read_and_decode(self) -> Optional[ScanResult]:
        if self._capture is None:
            raise QRError("لم يتم تشغيل الكاميرا بعد.")

        success, frame = self._capture.read()
        if not success or frame is None:
            self._last_frame = None
            return None
        self._last_frame = frame
        return decode_frame(frame)

    def stop(self) -> None:
        if self._capture is not None:
            self._capture.release()
            self._capture = None
            self._last_frame = None
            logger.info("Camera scanner stopped.")

    def __enter__(self) -> "QRCameraScanner":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.stop()
