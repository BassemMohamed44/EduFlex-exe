from __future__ import annotations

from pathlib import Path

import qrcode
from qrcode.image.pil import PilImage

from app.config.settings import get_paths
from app.database.session import session_scope
from app.qr.token import build_qr_payload, generate_token
from app.repositories.student_repository import StudentRepository
from app.utils.exceptions import NotFoundError, QRError
from app.utils.logger import get_logger

logger = get_logger(__name__)


def _qr_file_path(student_code: str) -> Path:
    return get_paths().qr_dir / f"student_{student_code}.png"


def _render_and_save(payload: str, student_code: str) -> Path:
    try:
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        qr.add_data(payload)
        qr.make(fit=True)
        image = qr.make_image(image_factory=PilImage, fill_color="black", back_color="white")

        path = _qr_file_path(student_code)
        image.save(path)
        return path
    except Exception as exc:
        logger.error("Failed to render/save QR for student_code=%s: %s", student_code, exc)
        raise QRError("تعذر إنشاء رمز QR.") from exc


def generate_qr_for_student(student_id: int) -> dict:
    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError("لم يتم العثور على الطالب.")

        if not student.qr_token:
            student.qr_token = generate_token()
            repo.update(student)
            logger.info("Assigned new QR token to student_id=%s", student_id)

        payload = build_qr_payload(student.qr_token)
        file_path = _render_and_save(payload, student.student_code)

        return {"token": student.qr_token, "payload": payload, "file_path": str(file_path)}


def regenerate_qr_for_student(student_id: int) -> dict:
    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError("لم يتم العثور على الطالب.")

        student.qr_token = generate_token()
        repo.update(student)
        logger.info("Regenerated QR token for student_id=%s", student_id)

        payload = build_qr_payload(student.qr_token)
        file_path = _render_and_save(payload, student.student_code)

        return {"token": student.qr_token, "payload": payload, "file_path": str(file_path)}


def get_qr_file_path(student_id: int) -> str:
    with session_scope() as session:
        repo = StudentRepository(session)
        student = repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError("لم يتم العثور على الطالب.")

        path = _qr_file_path(student.student_code)
        if student.qr_token and path.exists():
            return str(path)

    result = generate_qr_for_student(student_id)
    return result["file_path"]


def export_qr_as_png(student_id: int, destination: str) -> str:
    import shutil

    source = get_qr_file_path(student_id)
    dest_path = Path(destination)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(source, dest_path)
    logger.info("Exported QR for student_id=%s to %s", student_id, dest_path)
    return str(dest_path)
