from __future__ import annotations

from pathlib import Path
from typing import Sequence

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.lib.styles import getSampleStyleSheet

from app.utils.exceptions import EduflexError
from app.utils.logger import get_logger

logger = get_logger(__name__)


class ReportGenerationError(EduflexError):
    pass


def export_table_to_pdf(
    *,
    title: str,
    headers: Sequence[str],
    rows: Sequence[Sequence],
    destination: str,
) -> str:
    try:
        dest_path = Path(destination)
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        doc = SimpleDocTemplate(
            str(dest_path),
            pagesize=A4,
            leftMargin=1.5 * cm,
            rightMargin=1.5 * cm,
            topMargin=1.5 * cm,
            bottomMargin=1.5 * cm,
        )
        styles = getSampleStyleSheet()

        elements = [Paragraph(title, styles["Title"]), Spacer(1, 12)]

        table_data = [list(headers)] + [[str(cell) for cell in row] for row in rows]
        table = Table(table_data, repeatRows=1)
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2C3E50")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F6FA")]),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("TOPPADDING", (0, 0), (-1, -1), 6),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ]
            )
        )
        elements.append(table)

        doc.build(elements)
        logger.info("Generated PDF report at %s", dest_path)
        return str(dest_path)
    except Exception as exc:
        logger.error("PDF generation failed: %s", exc)
        raise ReportGenerationError("تعذر إنشاء تقرير PDF.") from exc
