from __future__ import annotations

from pathlib import Path
from typing import Sequence

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from app.utils.exceptions import EduflexError
from app.utils.logger import get_logger

logger = get_logger(__name__)


class ReportGenerationError(EduflexError):
    pass


def export_table_to_excel(
    *,
    title: str,
    headers: Sequence[str],
    rows: Sequence[Sequence],
    destination: str,
) -> str:
    try:
        dest_path = Path(destination)
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        wb = Workbook()
        ws = wb.active
        ws.title = title[:31] if title else "Report"

        header_fill = PatternFill(start_color="2C3E50", end_color="2C3E50", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)

        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font

        for row_idx, row in enumerate(rows, start=2):
            for col_idx, value in enumerate(row, start=1):
                ws.cell(row=row_idx, column=col_idx, value=value)

        for col_idx, header in enumerate(headers, start=1):
            max_len = len(str(header))
            for row in rows:
                if col_idx - 1 < len(row):
                    max_len = max(max_len, len(str(row[col_idx - 1])))
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 4, 40)

        wb.save(dest_path)
        logger.info("Generated Excel report at %s", dest_path)
        return str(dest_path)
    except Exception as exc:
        logger.error("Excel generation failed: %s", exc)
        raise ReportGenerationError("تعذر إنشاء تقرير Excel.") from exc
