from __future__ import annotations

import argparse
import base64
import secrets
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.licensing.codec import encode_license_code

PRIVATE_KEY_FILE = Path(__file__).with_name("private_key.pem")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate an Eduflex license activation code.")
    parser.add_argument("plan", choices=["monthly", "yearly"])
    parser.add_argument("--id", default=None, help="Optional license id/reference (e.g. customer name).")
    args = parser.parse_args()

    if not PRIVATE_KEY_FILE.exists():
        print(f"Private key file not found at {PRIVATE_KEY_FILE}")
        sys.exit(1)

    private_key_b64 = PRIVATE_KEY_FILE.read_text(encoding="utf-8").strip()
    license_id = args.id or base64.b32encode(secrets.token_bytes(5)).decode().rstrip("=")

    code = encode_license_code(private_key_b64, args.plan, license_id)
    print(f"Plan: {args.plan}")
    print(f"License ID: {license_id}")
    print(f"Activation Code:\n{code}")


if __name__ == "__main__":
    main()
