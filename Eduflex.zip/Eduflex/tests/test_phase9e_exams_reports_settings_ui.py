from __future__ import annotations

import datetime as dt

from app.services import (
    attendance_service, auth_service, exam_service, student_service,
    subscription_service, teacher_service,
)
from app.ui.dialogs.exam_dialog import ExamDialog
from app.ui.dialogs.exam_results_dialog import ExamResultsDialog
from app.ui.windows.exams_page import ExamsPage
from app.ui.windows.reports_page import ReportsPage
from app.ui.windows.settings_page import SettingsPage


def _login(name="مدرس الاختبار", subject="مادة", password="Passw0rd"):
    auth_service.register_teacher(name, subject, password)
    auth_service.login(name, password)


def test_exam_dialog_creates_exam(temp_db, qtbot):
    _login()
    dialog = ExamDialog()
    qtbot.addWidget(dialog)
    dialog.name_input.setText("اختبار واجهة")
    dialog.subject_input.setText("رياضيات")
    dialog.grade_input.setText("1")
    dialog.max_score_input.setValue(100)
    dialog._on_save()
    assert dialog.error_label.text() == ""
    assert len(exam_service.list_exams()) == 1


def test_exams_page_lists_and_deletes(temp_db, qtbot, monkeypatch):
    _login()
    exam_service.create_exam(
        name="اختبار1", subject="علوم", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    page = ExamsPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 1

    page.table.selectRow(0)
    monkeypatch.setattr("app.ui.windows.exams_page.confirm", lambda *a, **k: True)
    page._on_delete_selected()
    assert page.table.rowCount() == 0


def test_exam_results_dialog_records_score(temp_db, qtbot):
    _login()
    student = student_service.create_student(full_name="طالب نتيجة", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار نتائج", subject="علوم", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    dialog = ExamResultsDialog(None, exam)
    qtbot.addWidget(dialog)
    dialog.student_picker.setCurrentIndex(0)
    dialog.score_input.setValue(85)
    dialog._on_record()

    assert dialog.error_label.text() == ""
    results = exam_service.list_results_for_exam(exam["id"])
    assert len(results) == 1
    assert results[0]["score"] == 85


def test_reports_page_shows_cards(temp_db, qtbot):
    _login()
    from app.ui.widgets.report_card import ReportCard

    page = ReportsPage()
    qtbot.addWidget(page)
    cards = page.findChildren(ReportCard)
    assert len(cards) == 7


def test_reports_page_card_opens_detail_dialog(temp_db, qtbot, monkeypatch):
    _login()
    student = student_service.create_student(full_name="تقرير حضور", grade_level="1")
    attendance_service.record_attendance_by_code(student["student_code"])

    page = ReportsPage()
    qtbot.addWidget(page)

    opened = {}
    def fake_dialog(parent, kind, title):
        opened["kind"] = kind
        return type("FakeDialog", (), {"exec": lambda self: None})()

    monkeypatch.setattr("app.ui.windows.reports_page.ReportDetailDialog", fake_dialog)
    page._on_card_clicked("attendance_totals", "إجمالي الحضور")
    assert opened["kind"] == "attendance_totals"


def test_reports_page_exams_card_emits_navigation(temp_db, qtbot):
    _login()
    page = ReportsPage()
    qtbot.addWidget(page)

    received = []
    page.navigate_requested.connect(received.append)
    page._on_card_clicked("goto_exams", "تسجيل درجات الاختبارات")
    assert received == ["exams"]


def test_report_detail_dialog_attendance_totals(temp_db, qtbot):
    _login()
    student = student_service.create_student(full_name="تفاصيل حضور", grade_level="1")
    attendance_service.record_attendance_by_code(student["student_code"])

    from app.ui.dialogs.report_detail_dialog import ReportDetailDialog

    dialog = ReportDetailDialog(None, "attendance_totals", "إجمالي الحضور")
    qtbot.addWidget(dialog)
    assert dialog.table.rowCount() == 1


def test_report_detail_dialog_export_pdf(temp_db, qtbot, monkeypatch, tmp_path):
    _login()
    student_service.create_student(full_name="تصدير تقرير", grade_level="1")

    from app.ui.dialogs.report_detail_dialog import ReportDetailDialog

    dialog = ReportDetailDialog(None, "attendance_totals", "إجمالي الحضور")
    qtbot.addWidget(dialog)

    dest = str(tmp_path / "out.pdf")
    monkeypatch.setattr(
        "app.ui.dialogs.report_detail_dialog.QFileDialog.getSaveFileName", lambda *a, **k: (dest, "")
    )
    monkeypatch.setattr("app.ui.dialogs.report_detail_dialog.show_info", lambda *a, **k: None)

    dialog._on_export("pdf")
    import os
    assert os.path.exists(dest)


def test_report_detail_dialog_comprehensive_statistics(temp_db, qtbot):
    _login()
    student_service.create_student(full_name="إحصاء تقرير", grade_level="1")

    from app.ui.dialogs.report_detail_dialog import ReportDetailDialog

    dialog = ReportDetailDialog(None, "comprehensive_statistics", "الإحصائيات الشاملة")
    qtbot.addWidget(dialog)
    assert dialog.table.rowCount() == 6


def test_settings_page_shows_current_profile(temp_db, qtbot):
    _login(name="منى سالم", subject="فيزياء")
    page = SettingsPage()
    qtbot.addWidget(page)
    assert page.name_input.text() == "منى سالم"
    assert page.subject_input.text() == "فيزياء"


def test_settings_page_updates_profile(temp_db, qtbot, monkeypatch):
    _login(name="اسم قديم", subject="مادة قديمة")
    page = SettingsPage()
    qtbot.addWidget(page)

    monkeypatch.setattr("app.ui.windows.settings_page.show_info", lambda *a, **k: None)

    page.name_input.setText("اسم جديد")
    page.subject_input.setText("مادة جديدة")
    page._on_save_profile()

    profile = teacher_service.get_profile(auth_service.current_session.teacher_id)
    assert profile["full_name"] == "اسم جديد"


def test_settings_page_changes_password(temp_db, qtbot, monkeypatch):
    _login(password="OldPass1")
    page = SettingsPage()
    qtbot.addWidget(page)

    monkeypatch.setattr("app.ui.windows.settings_page.show_info", lambda *a, **k: None)

    page.old_password_input.setText("OldPass1")
    page.new_password_input.setText("NewPass1")
    page._on_change_password()

    assert page.password_error.text() == ""


def test_settings_page_wrong_old_password_shows_error(temp_db, qtbot):
    _login(password="OldPass1")
    page = SettingsPage()
    qtbot.addWidget(page)

    page.old_password_input.setText("WrongOld1")
    page.new_password_input.setText("NewPass1")
    page._on_change_password()

    assert page.password_error.text() != ""
