from __future__ import annotations

import datetime as dt

import pytest

from app.licensing import license_service, machine_id
from app.licensing.codec import LicenseCodeError, decode_license_code, encode_license_code
from app.licensing.keys import PUBLIC_KEY_B64
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization
import base64


@pytest.fixture()
def test_keypair():
    private_key = ed25519.Ed25519PrivateKey.generate()
    priv_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    return base64.b64encode(priv_bytes).decode()


def test_encode_decode_roundtrip_monthly(monkeypatch, test_keypair):
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(
        base64.b64decode(test_keypair)
    )
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    monkeypatch.setattr(
        "app.licensing.codec.PUBLIC_KEY_B64", base64.b64encode(public_bytes).decode()
    )

    code = encode_license_code(test_keypair, "monthly", "abc123")
    payload = decode_license_code(code)
    assert payload["plan"] == "monthly"
    assert payload["days"] == 30
    assert payload["id"] == "abc123"


def test_decode_rejects_tampered_code(monkeypatch, test_keypair):
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(test_keypair))
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    monkeypatch.setattr(
        "app.licensing.codec.PUBLIC_KEY_B64", base64.b64encode(public_bytes).decode()
    )

    code = encode_license_code(test_keypair, "yearly", "xyz")
    tampered = code[:-2] + ("AA" if code[-2:] != "AA" else "BB")
    with pytest.raises(LicenseCodeError):
        decode_license_code(tampered)


def test_decode_rejects_code_signed_by_wrong_key(test_keypair):
    code = encode_license_code(test_keypair, "monthly", "forged")
    with pytest.raises(LicenseCodeError):
        decode_license_code(code)


def test_decode_rejects_garbage_input():
    with pytest.raises(LicenseCodeError):
        decode_license_code("not-a-real-code")


def test_decode_rejects_empty_input():
    with pytest.raises(LicenseCodeError):
        decode_license_code("")


def test_machine_id_is_stable():
    assert machine_id.get_machine_id() == machine_id.get_machine_id()
    assert len(machine_id.get_machine_id()) == 32


def test_status_not_activated(temp_db):
    license_service.deactivate_for_tests()
    status = license_service.get_status()
    assert status["activated"] is False
    assert status["valid"] is False


def test_activate_and_status_valid(temp_db, monkeypatch, test_keypair):
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(test_keypair))
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    monkeypatch.setattr(
        "app.licensing.codec.PUBLIC_KEY_B64", base64.b64encode(public_bytes).decode()
    )

    code = encode_license_code(test_keypair, "monthly", "customer1")
    status = license_service.activate(code)
    assert status["valid"] is True
    assert status["plan"] == "monthly"
    assert status["remaining_days"] == 29 or status["remaining_days"] == 30


def test_activate_invalid_code_raises(temp_db):
    with pytest.raises(LicenseCodeError):
        license_service.activate("garbage-code")


def test_expired_license_detected(temp_db, monkeypatch, test_keypair):
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(test_keypair))
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    monkeypatch.setattr(
        "app.licensing.codec.PUBLIC_KEY_B64", base64.b64encode(public_bytes).decode()
    )

    code = encode_license_code(test_keypair, "monthly", "old_customer")
    license_service.activate(code)

    record_path = license_service._license_file()
    import json

    record = json.loads(record_path.read_text(encoding="utf-8"))
    record["activated_at"] = (dt.datetime.now() - dt.timedelta(days=40)).isoformat()
    license_service._save_record(record)

    status = license_service.get_status()
    assert status["valid"] is False
    assert status["reason"] == "expired"


def test_tampering_local_file_invalidates_license(temp_db, monkeypatch, test_keypair):
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(test_keypair))
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    monkeypatch.setattr(
        "app.licensing.codec.PUBLIC_KEY_B64", base64.b64encode(public_bytes).decode()
    )

    code = encode_license_code(test_keypair, "yearly", "tamper_test")
    license_service.activate(code)

    record_path = license_service._license_file()
    import json

    record = json.loads(record_path.read_text(encoding="utf-8"))
    record["activated_at"] = (dt.datetime.now() + dt.timedelta(days=300)).isoformat()
    record_path.write_text(json.dumps(record), encoding="utf-8")

    status = license_service.get_status()
    assert status["activated"] is False
    assert status["valid"] is False


def test_machine_mismatch_detected(temp_db, monkeypatch, test_keypair):
    private_key = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(test_keypair))
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    monkeypatch.setattr(
        "app.licensing.codec.PUBLIC_KEY_B64", base64.b64encode(public_bytes).decode()
    )

    code = encode_license_code(test_keypair, "monthly", "other_pc")
    license_service.activate(code)

    monkeypatch.setattr("app.licensing.license_service.get_machine_id", lambda: "different-machine-id")
    status = license_service.get_status()
    assert status["valid"] is False
    assert status["reason"] == "machine_mismatch"
