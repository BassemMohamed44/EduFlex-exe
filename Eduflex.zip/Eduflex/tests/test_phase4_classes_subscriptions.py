from __future__ import annotations

import datetime as dt

import pytest

from app.services import class_service, student_service, subscription_service
from app.services.subscription_service import SubscriptionStatus
from app.utils.exceptions import DuplicateError, NotFoundError, ValidationError


def test_create_and_get_class(temp_db):
    c = class_service.create_class(subject="رياضيات", days_of_week="Sat,Mon", time_slot="4-6 PM", price=200)
    fetched = class_service.get_class(c["id"])
    assert fetched["subject"] == "رياضيات"
    assert fetched["price"] == 200


def test_create_class_missing_fields_rejected(temp_db):
    with pytest.raises(ValidationError):
        class_service.create_class(subject="", days_of_week="Sat", time_slot="5 PM")


def test_update_class(temp_db):
    c = class_service.create_class(subject="علوم", days_of_week="Sun", time_slot="3 PM", price=100)
    updated = class_service.update_class(
        c["id"], subject="علوم متقدم", days_of_week="Sun,Tue", time_slot="4 PM", price=150
    )
    assert updated["subject"] == "علوم متقدم"
    assert updated["price"] == 150


def test_delete_class(temp_db):
    c = class_service.create_class(subject="عربي", days_of_week="Mon", time_slot="5 PM")
    class_service.delete_class(c["id"])
    with pytest.raises(NotFoundError):
        class_service.get_class(c["id"])


def test_enroll_and_list_students_for_class(temp_db):
    student = student_service.create_student(full_name="طالب1", grade_level="1")
    c = class_service.create_class(subject="كيمياء", days_of_week="Wed", time_slot="6 PM")

    class_service.enroll_student(student["id"], c["id"])
    students = class_service.list_students_for_class(c["id"])
    assert len(students) == 1
    assert students[0]["id"] == student["id"]

    classes = class_service.list_classes_for_student(student["id"])
    assert len(classes) == 1
    assert classes[0]["id"] == c["id"]


def test_duplicate_enrollment_rejected_by_service(temp_db):
    student = student_service.create_student(full_name="طالب2", grade_level="1")
    c = class_service.create_class(subject="فيزياء", days_of_week="Thu", time_slot="7 PM")
    class_service.enroll_student(student["id"], c["id"])
    with pytest.raises(DuplicateError):
        class_service.enroll_student(student["id"], c["id"])


def test_enroll_nonexistent_student_raises(temp_db):
    c = class_service.create_class(subject="فيزياء", days_of_week="Thu", time_slot="7 PM")
    with pytest.raises(NotFoundError):
        class_service.enroll_student(9999, c["id"])


def test_unenroll_student(temp_db):
    student = student_service.create_student(full_name="طالب3", grade_level="1")
    c = class_service.create_class(subject="أحياء", days_of_week="Fri", time_slot="2 PM")
    class_service.enroll_student(student["id"], c["id"])
    class_service.unenroll_student(student["id"], c["id"])
    assert class_service.list_students_for_class(c["id"]) == []


def test_create_subscription_and_status_active(temp_db):
    student = student_service.create_student(full_name="نورا", grade_level="1")
    today = dt.date.today()
    sub = subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today,
        end_date=today + dt.timedelta(days=30),
        price=300,
    )
    assert sub["status"] == SubscriptionStatus.ACTIVE


def test_subscription_status_expiring_soon(temp_db):
    student = student_service.create_student(full_name="سامر", grade_level="1")
    today = dt.date.today()
    sub = subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=20),
        end_date=today + dt.timedelta(days=3),
        price=300,
    )
    assert sub["status"] == SubscriptionStatus.EXPIRING_SOON


def test_subscription_status_expired(temp_db):
    student = student_service.create_student(full_name="ياسر", grade_level="1")
    today = dt.date.today()
    sub = subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=1),
        price=300,
    )
    assert sub["status"] == SubscriptionStatus.EXPIRED


def test_create_subscription_invalid_dates_rejected(temp_db):
    student = student_service.create_student(full_name="دينا", grade_level="1")
    today = dt.date.today()
    with pytest.raises(ValidationError):
        subscription_service.create_subscription(
            student_id=student["id"],
            start_date=today,
            end_date=today - dt.timedelta(days=5),
            price=100,
        )


def test_create_subscription_nonexistent_student_raises(temp_db):
    today = dt.date.today()
    with pytest.raises(NotFoundError):
        subscription_service.create_subscription(
            student_id=9999, start_date=today, end_date=today + dt.timedelta(days=10)
        )


def test_list_expired_subscriptions(temp_db):
    expired_student = student_service.create_student(full_name="منتهي", grade_level="1")
    active_student = student_service.create_student(full_name="نشط", grade_level="1")
    today = dt.date.today()

    subscription_service.create_subscription(
        student_id=expired_student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=5),
        price=100,
    )
    subscription_service.create_subscription(
        student_id=active_student["id"],
        start_date=today,
        end_date=today + dt.timedelta(days=30),
        price=100,
    )

    expired = subscription_service.list_expired_subscriptions()
    assert len(expired) == 1
    assert expired[0]["student_id"] == expired_student["id"]


def test_list_expiring_soon_subscriptions(temp_db):
    student = student_service.create_student(full_name="قريب الانتهاء", grade_level="1")
    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=25),
        end_date=today + dt.timedelta(days=2),
        price=100,
    )
    expiring = subscription_service.list_expiring_soon_subscriptions()
    assert len(expiring) == 1
    assert expiring[0]["student_id"] == student["id"]


def test_latest_subscription_used_for_student_status(temp_db):
    student = student_service.create_student(full_name="متجدد", grade_level="1")
    today = dt.date.today()

    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=30),
        price=100,
    )
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today,
        end_date=today + dt.timedelta(days=30),
        price=100,
    )

    status = subscription_service.get_current_status_for_student(student["id"])
    assert status == SubscriptionStatus.ACTIVE


def test_delete_subscription(temp_db):
    student = student_service.create_student(full_name="حذف", grade_level="1")
    today = dt.date.today()
    sub = subscription_service.create_subscription(
        student_id=student["id"], start_date=today, end_date=today + dt.timedelta(days=10)
    )
    subscription_service.delete_subscription(sub["id"])
    assert subscription_service.list_subscriptions_for_student(student["id"]) == []
