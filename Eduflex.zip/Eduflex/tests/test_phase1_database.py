from __future__ import annotations

import datetime as dt

import pytest
from sqlalchemy.exc import IntegrityError

from app.database.session import session_scope
from app.models import (
    AppSetting,
    Attendance,
    AttendanceSource,
    AttendanceStatus,
    ClassSession,
    Enrollment,
    Exam,
    ExamResult,
    Student,
    Subscription,
    Teacher,
)


def test_tables_created(temp_db):
    with session_scope() as s:
        for model in (Teacher, Student, ClassSession, Enrollment, Subscription, Attendance, Exam, ExamResult, AppSetting):
            assert s.query(model).count() == 0


def test_create_teacher_and_student(temp_db):
    with session_scope() as s:
        teacher = Teacher(full_name="أحمد علي", subject="رياضيات", password_hash="hash")
        s.add(teacher)

        student = Student(
            student_code="1001",
            full_name="محمد سامي",
            grade_level="الصف الأول الثانوي",
            subscription_price=300,
        )
        s.add(student)

    with session_scope() as s:
        assert s.query(Teacher).count() == 1
        assert s.query(Student).filter_by(student_code="1001").one().full_name == "محمد سامي"


def test_student_code_must_be_unique(temp_db):
    with session_scope() as s:
        s.add(Student(student_code="1002", full_name="طالب1", grade_level="1"))

    with pytest.raises(IntegrityError):
        with session_scope() as s:
            s.add(Student(student_code="1002", full_name="طالب2", grade_level="1"))


def test_class_enrollment_relationship(temp_db):
    with session_scope() as s:
        student = Student(student_code="2001", full_name="سارة", grade_level="2")
        class_session = ClassSession(subject="فيزياء", days_of_week="Sat,Mon", time_slot="5-7 PM", price=250)
        s.add_all([student, class_session])
        s.flush()
        s.add(Enrollment(student_id=student.id, class_id=class_session.id))

    with session_scope() as s:
        cs = s.query(ClassSession).one()
        assert len(cs.enrollments) == 1
        assert cs.enrollments[0].student.full_name == "سارة"


def test_duplicate_enrollment_rejected(temp_db):
    with session_scope() as s:
        student = Student(student_code="2002", full_name="ياسمين", grade_level="2")
        class_session = ClassSession(subject="كيمياء", days_of_week="Sun", time_slot="3-4 PM", price=200)
        s.add_all([student, class_session])
        s.flush()
        s.add(Enrollment(student_id=student.id, class_id=class_session.id))

    with pytest.raises(IntegrityError):
        with session_scope() as s:
            student = s.query(Student).filter_by(student_code="2002").one()
            cs = s.query(ClassSession).filter_by(subject="كيمياء").one()
            s.add(Enrollment(student_id=student.id, class_id=cs.id))


def test_attendance_unique_per_day(temp_db):
    with session_scope() as s:
        student = Student(student_code="3001", full_name="خالد", grade_level="3")
        s.add(student)
        s.flush()
        today = dt.date.today()
        s.add(
            Attendance(
                student_id=student.id,
                attendance_date=today,
                check_in_time=dt.datetime.now(),
                status=AttendanceStatus.PRESENT,
                source=AttendanceSource.MANUAL_ID,
            )
        )

    with pytest.raises(IntegrityError):
        with session_scope() as s:
            student = s.query(Student).filter_by(student_code="3001").one()
            s.add(
                Attendance(
                    student_id=student.id,
                    attendance_date=dt.date.today(),
                    check_in_time=dt.datetime.now(),
                    status=AttendanceStatus.PRESENT,
                    source=AttendanceSource.MANUAL_ID,
                )
            )


def test_exam_result_score_constraint(temp_db):
    with session_scope() as s:
        student = Student(student_code="4001", full_name="ليلى", grade_level="4")
        exam = Exam(name="اختبار شهري", subject="عربي", exam_date=dt.date.today(), max_score=100, grade_level="4")
        s.add_all([student, exam])
        s.flush()
        s.add(ExamResult(exam_id=exam.id, student_id=student.id, score=85))

    with session_scope() as s:
        result = s.query(ExamResult).one()
        assert result.score == 85


def test_exam_result_negative_score_rejected(temp_db):
    with session_scope() as s:
        student = Student(student_code="4002", full_name="نور", grade_level="4")
        exam = Exam(name="اختبار", subject="علوم", exam_date=dt.date.today(), max_score=50, grade_level="4")
        s.add_all([student, exam])
        s.flush()

    with pytest.raises(IntegrityError):
        with session_scope() as s:
            student = s.query(Student).filter_by(student_code="4002").one()
            exam = s.query(Exam).filter_by(name="اختبار").one()
            s.add(ExamResult(exam_id=exam.id, student_id=student.id, score=-5))
