from __future__ import annotations

import numpy as np
import pytest

from app.qr.scanner import ScanResult
from app.services import auth_service, student_service, attendance_service
from app.qr import qr_service
from app.ui.widgets.qr_scan_widget import QRScanWidget, frame_to_pixmap
from app.ui.windows.attendance_page import AttendancePage
from app.utils.exceptions import QRError


class FakeScanner:
    def __init__(self):
        self.started = False
        self._frame = np.zeros((240, 320, 3), dtype=np.uint8)
        self._result = None
        self._raise_on_start = False

    def start(self):
        if self._raise_on_start:
            raise QRError("تعذر فتح الكاميرا.")
        self.started = True

    def stop(self):
        self.started = False

    def read_and_decode(self):
        self._last_frame = self._frame
        return self._result


def test_frame_to_pixmap_converts_array(qapp):
    frame = np.zeros((100, 200, 3), dtype=np.uint8)
    pixmap = frame_to_pixmap(frame)
    assert not pixmap.isNull()
    assert pixmap.width() == 200
    assert pixmap.height() == 100


def test_qr_scan_widget_starts_and_stops(qtbot):
    fake = FakeScanner()
    widget = QRScanWidget(scanner=fake)
    qtbot.addWidget(widget)

    widget.start()
    assert widget.is_running
    assert fake.started

    widget.stop()
    assert not widget.is_running
    assert not fake.started


def test_qr_scan_widget_camera_start_failure_emits_error(qtbot):
    fake = FakeScanner()
    fake._raise_on_start = True
    widget = QRScanWidget(scanner=fake)
    qtbot.addWidget(widget)

    errors = []
    widget.camera_error.connect(errors.append)
    widget.start()

    assert not widget.is_running
    assert len(errors) == 1


def test_qr_scan_widget_detects_and_stops(temp_db, qtbot):
    student = student_service.create_student(full_name="كاميرا", grade_level="1")
    qr = qr_service.generate_qr_for_student(student["id"])

    fake = FakeScanner()
    fake._result = ScanResult(token=qr["token"], raw_payload=qr["payload"])
    widget = QRScanWidget(scanner=fake)
    qtbot.addWidget(widget)

    detected = []
    widget.qr_detected.connect(detected.append)

    widget.start()
    widget._poll_frame()

    assert detected == [qr["token"]]
    assert not widget.is_running


def test_attendance_page_camera_tab_records_on_detection(temp_db, qtbot):
    student = student_service.create_student(full_name="حضور كاميرا", grade_level="1")
    qr = qr_service.generate_qr_for_student(student["id"])

    page = AttendancePage()
    qtbot.addWidget(page)

    fake = FakeScanner()
    page.scan_widget._scanner = fake

    page._on_qr_detected(qr["token"])

    assert "تسجيل حضور" in page.banner.label.text()
    assert page.table.rowCount() == 1


def test_attendance_page_camera_invalid_token_shows_error(temp_db, qtbot):
    page = AttendancePage()
    qtbot.addWidget(page)
    page._on_qr_detected("invalid-token")
    assert "#E74C3C" in page.banner.label.styleSheet()


def test_attendance_page_switching_away_from_camera_tab_stops_scanning(temp_db, qtbot):
    page = AttendancePage()
    qtbot.addWidget(page)
    fake = FakeScanner()
    page.scan_widget._scanner = fake

    page.tabs.setCurrentIndex(1)
    page.scan_widget.start()
    assert page.scan_widget.is_running

    page.tabs.setCurrentIndex(0)
    assert not page.scan_widget.is_running
