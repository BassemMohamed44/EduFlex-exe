from __future__ import annotations

import datetime as dt
import os

import pytest

from app.services import (
    attendance_service,
    class_service,
    exam_service,
    export_service,
    report_service,
    student_service,
    subscription_service,
)


def test_attendance_totals_report(temp_db):
    s1 = student_service.create_student(full_name="حاضر دائمًا", grade_level="1")
    s2 = student_service.create_student(full_name="غائب أحيانًا", grade_level="1")
    attendance_service.record_attendance_by_code(s1["student_code"])

    totals = report_service.attendance_totals_report()
    by_id = {r["student_id"]: r for r in totals}
    assert by_id[s1["id"]]["present_count"] == 1
    assert by_id[s2["id"]]["present_count"] == 0


def test_daily_attendance_report(temp_db):
    s1 = student_service.create_student(full_name="يومي1", grade_level="1")
    attendance_service.record_attendance_by_code(s1["student_code"])

    today_report = report_service.daily_attendance_report(dt.date.today())
    assert len(today_report) == 1
    assert today_report[0]["full_name"] == "يومي1"


def test_exam_results_report(temp_db):
    student = student_service.create_student(full_name="نتيجة1", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار تقرير", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.record_result(exam["id"], student["id"], 88)

    report = report_service.exam_results_report(exam["id"])
    assert report["statistics"]["count"] == 1
    assert report["results"][0]["full_name"] == "نتيجة1"
    assert report["results"][0]["score"] == 88


def test_expired_subscriptions_report(temp_db):
    student = student_service.create_student(full_name="منتهي التقرير", grade_level="1")
    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=10),
        price=200,
    )
    report = report_service.expired_subscriptions_report()
    assert len(report) == 1
    assert report[0]["full_name"] == "منتهي التقرير"


def test_comprehensive_statistics_report(temp_db):
    s1 = student_service.create_student(full_name="إحصاء1", grade_level="1")
    s2 = student_service.create_student(full_name="إحصاء2", grade_level="1")
    attendance_service.record_attendance_by_code(s1["student_code"])

    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=s1["id"], start_date=today, end_date=today + dt.timedelta(days=30)
    )
    subscription_service.create_subscription(
        student_id=s2["id"], start_date=today - dt.timedelta(days=60), end_date=today - dt.timedelta(days=1)
    )

    stats = report_service.comprehensive_statistics_report()
    assert stats["number_of_students"] == 2
    assert stats["active_subscriptions"] == 1
    assert stats["expired_subscriptions"] == 1
    assert stats["attendance_rate"] == 50.0


def test_export_attendance_totals_pdf_and_excel(temp_db, tmp_path):
    s1 = student_service.create_student(full_name="تصدير1", grade_level="1")
    attendance_service.record_attendance_by_code(s1["student_code"])

    pdf_path = export_service.export_attendance_totals("pdf", str(tmp_path / "totals.pdf"))
    excel_path = export_service.export_attendance_totals("excel", str(tmp_path / "totals.xlsx"))

    assert os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 0
    assert os.path.exists(excel_path) and os.path.getsize(excel_path) > 0


def test_export_daily_attendance(temp_db, tmp_path):
    s1 = student_service.create_student(full_name="تصدير يومي", grade_level="1")
    attendance_service.record_attendance_by_code(s1["student_code"])

    path = export_service.export_daily_attendance(dt.date.today(), "pdf", str(tmp_path / "daily.pdf"))
    assert os.path.exists(path)


def test_export_exam_results(temp_db, tmp_path):
    student = student_service.create_student(full_name="تصدير اختبار", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار تصدير", subject="علوم", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.record_result(exam["id"], student["id"], 77)

    path = export_service.export_exam_results(exam["id"], "excel", str(tmp_path / "exam.xlsx"))
    assert os.path.exists(path)


def test_export_expired_subscriptions(temp_db, tmp_path):
    student = student_service.create_student(full_name="تصدير منتهي", grade_level="1")
    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=5),
        price=100,
    )
    path = export_service.export_expired_subscriptions("pdf", str(tmp_path / "expired.pdf"))
    assert os.path.exists(path)


def test_export_comprehensive_statistics(temp_db, tmp_path):
    student_service.create_student(full_name="تصدير إحصائي", grade_level="1")
    path = export_service.export_comprehensive_statistics("excel", str(tmp_path / "stats.xlsx"))
    assert os.path.exists(path)


def test_export_invalid_format_rejected(temp_db, tmp_path):
    from app.utils.exceptions import ValidationError

    with pytest.raises(ValidationError):
        export_service.export_comprehensive_statistics("word", str(tmp_path / "stats.doc"))
