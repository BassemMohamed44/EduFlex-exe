from __future__ import annotations

import datetime as dt

import pytest

from app.services import exam_service, student_service
from app.utils.exceptions import DuplicateError, NotFoundError, ValidationError


def test_create_exam(temp_db):
    exam = exam_service.create_exam(
        name="اختبار شهري", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    assert exam["max_score"] == 100
    fetched = exam_service.get_exam(exam["id"])
    assert fetched["name"] == "اختبار شهري"


def test_create_exam_missing_fields_rejected(temp_db):
    with pytest.raises(ValidationError):
        exam_service.create_exam(
            name="", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
        )


def test_create_exam_zero_max_score_rejected(temp_db):
    with pytest.raises(ValidationError):
        exam_service.create_exam(
            name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=0, grade_level="1"
        )


def test_update_exam(temp_db):
    exam = exam_service.create_exam(
        name="اختبار1", subject="علوم", exam_date=dt.date.today(), max_score=50, grade_level="1"
    )
    updated = exam_service.update_exam(
        exam["id"], name="اختبار محدث", subject="علوم", exam_date=dt.date.today(), max_score=60, grade_level="1"
    )
    assert updated["name"] == "اختبار محدث"
    assert updated["max_score"] == 60


def test_delete_exam(temp_db):
    exam = exam_service.create_exam(
        name="حذف", subject="عربي", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.delete_exam(exam["id"])
    with pytest.raises(NotFoundError):
        exam_service.get_exam(exam["id"])


def test_record_result(temp_db):
    student = student_service.create_student(full_name="طالب1", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    result = exam_service.record_result(exam["id"], student["id"], 85)
    assert result["score"] == 85


def test_record_result_negative_score_rejected(temp_db):
    student = student_service.create_student(full_name="طالب2", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    with pytest.raises(ValidationError):
        exam_service.record_result(exam["id"], student["id"], -5)


def test_record_result_exceeds_max_score_rejected(temp_db):
    student = student_service.create_student(full_name="طالب3", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=50, grade_level="1"
    )
    with pytest.raises(ValidationError):
        exam_service.record_result(exam["id"], student["id"], 55)


def test_record_duplicate_result_rejected(temp_db):
    student = student_service.create_student(full_name="طالب4", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.record_result(exam["id"], student["id"], 70)
    with pytest.raises(DuplicateError):
        exam_service.record_result(exam["id"], student["id"], 80)


def test_record_result_nonexistent_student_raises(temp_db):
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    with pytest.raises(NotFoundError):
        exam_service.record_result(exam["id"], 9999, 50)


def test_update_result(temp_db):
    student = student_service.create_student(full_name="طالب5", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.record_result(exam["id"], student["id"], 60)
    updated = exam_service.update_result(exam["id"], student["id"], 75)
    assert updated["score"] == 75


def test_update_result_not_found_raises(temp_db):
    student = student_service.create_student(full_name="طالب6", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    with pytest.raises(NotFoundError):
        exam_service.update_result(exam["id"], student["id"], 75)


def test_delete_result(temp_db):
    student = student_service.create_student(full_name="طالب7", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.record_result(exam["id"], student["id"], 90)
    exam_service.delete_result(exam["id"], student["id"])
    assert exam_service.list_results_for_exam(exam["id"]) == []


def test_exam_statistics(temp_db):
    exam = exam_service.create_exam(
        name="اختبار إحصائي", subject="علوم", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    s1 = student_service.create_student(full_name="ط1", grade_level="1")
    s2 = student_service.create_student(full_name="ط2", grade_level="1")
    s3 = student_service.create_student(full_name="ط3", grade_level="1")

    exam_service.record_result(exam["id"], s1["id"], 90)
    exam_service.record_result(exam["id"], s2["id"], 40)
    exam_service.record_result(exam["id"], s3["id"], 60)

    stats = exam_service.get_exam_statistics(exam["id"])
    assert stats["count"] == 3
    assert stats["average"] == 63.33
    assert stats["highest"] == 90
    assert stats["lowest"] == 40
    assert stats["pass_rate"] == round(2 / 3 * 100, 1)


def test_exam_statistics_no_results(temp_db):
    exam = exam_service.create_exam(
        name="بدون نتائج", subject="علوم", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    stats = exam_service.get_exam_statistics(exam["id"])
    assert stats["count"] == 0
    assert stats["average"] is None


def test_lowering_max_score_below_existing_result_rejected(temp_db):
    student = student_service.create_student(full_name="ط8", grade_level="1")
    exam = exam_service.create_exam(
        name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.record_result(exam["id"], student["id"], 90)
    with pytest.raises(ValidationError):
        exam_service.update_exam(
            exam["id"], name="اختبار", subject="رياضيات", exam_date=dt.date.today(), max_score=50, grade_level="1"
        )


def test_list_exams_filtered_by_grade_and_subject(temp_db):
    exam_service.create_exam(
        name="ا1", subject="رياضيات", exam_date=dt.date.today(), max_score=100, grade_level="1"
    )
    exam_service.create_exam(
        name="ا2", subject="علوم", exam_date=dt.date.today(), max_score=100, grade_level="2"
    )
    grade1 = exam_service.list_exams(grade_level="1")
    assert len(grade1) == 1
    assert grade1[0]["name"] == "ا1"
