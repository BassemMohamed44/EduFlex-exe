from __future__ import annotations

import os

import pytest

from app.qr import qr_service
from app.qr.scanner import decode_image_file
from app.qr.token import build_qr_payload, generate_token, parse_qr_payload
from app.services import student_service
from app.utils.exceptions import NotFoundError


def test_generate_token_is_random_and_unique():
    tokens = {generate_token() for _ in range(100)}
    assert len(tokens) == 100


def test_build_and_parse_payload_roundtrip():
    token = generate_token()
    payload = build_qr_payload(token)
    assert payload.startswith("EDUFLEX:STUDENT:")
    assert parse_qr_payload(payload) == token


def test_parse_payload_rejects_garbage():
    assert parse_qr_payload("some random text") is None
    assert parse_qr_payload("") is None
    assert parse_qr_payload("EDUFLEX:STUDENT:") is None


def test_generate_qr_creates_file_and_token(temp_db):
    student = student_service.create_student(full_name="ياسمين", grade_level="1")
    result = qr_service.generate_qr_for_student(student["id"])

    assert result["token"]
    assert result["payload"] == f"EDUFLEX:STUDENT:{result['token']}"
    assert os.path.exists(result["file_path"])


def test_qr_payload_never_contains_personal_data(temp_db):
    student = student_service.create_student(
        full_name="محمد الحساس", grade_level="ثانوي", student_phone="01012345678"
    )
    result = qr_service.generate_qr_for_student(student["id"])

    assert "محمد" not in result["payload"]
    assert "01012345678" not in result["payload"]
    assert "ثانوي" not in result["payload"]
    assert student["student_code"] not in result["payload"]


def test_generate_qr_is_idempotent_reuses_token(temp_db):
    student = student_service.create_student(full_name="كريم", grade_level="1")
    first = qr_service.generate_qr_for_student(student["id"])
    second = qr_service.generate_qr_for_student(student["id"])
    assert first["token"] == second["token"]


def test_regenerate_qr_issues_new_token(temp_db):
    student = student_service.create_student(full_name="سلمى", grade_level="1")
    first = qr_service.generate_qr_for_student(student["id"])
    second = qr_service.regenerate_qr_for_student(student["id"])
    assert first["token"] != second["token"]


def test_generate_qr_nonexistent_student_raises(temp_db):
    with pytest.raises(NotFoundError):
        qr_service.generate_qr_for_student(9999)


def test_qr_decode_roundtrip_from_file(temp_db):
    student = student_service.create_student(full_name="حسام", grade_level="1")
    result = qr_service.generate_qr_for_student(student["id"])

    scan_result = decode_image_file(result["file_path"])
    assert scan_result is not None
    assert scan_result.token == result["token"]
    assert scan_result.raw_payload == result["payload"]


def test_get_qr_file_path_generates_if_missing(temp_db):
    student = student_service.create_student(full_name="ريهام", grade_level="1")
    path = qr_service.get_qr_file_path(student["id"])
    assert os.path.exists(path)


def test_export_qr_as_png(temp_db, tmp_path):
    student = student_service.create_student(full_name="آدم", grade_level="1")
    qr_service.generate_qr_for_student(student["id"])
    dest = tmp_path / "exported" / "my_qr.png"
    exported_path = qr_service.export_qr_as_png(student["id"], str(dest))
    assert os.path.exists(exported_path)
