from __future__ import annotations

import pytest

from app.security.password_hasher import hash_password, verify_password
from app.services import auth_service
from app.utils.exceptions import AuthenticationError, NotAuthenticatedError, ValidationError


def test_hash_password_never_returns_plaintext():
    h = hash_password("Secret123")
    assert h != "Secret123"
    assert h.startswith("$argon2id$")


def test_verify_password_correct_and_incorrect():
    h = hash_password("Secret123")
    assert verify_password("Secret123", h) is True
    assert verify_password("WrongPass1", h) is False


def test_register_and_login(temp_db):
    auth_service.register_teacher("محمد إبراهيم", "علوم", "Passw0rd")
    auth_service.login("محمد إبراهيم", "Passw0rd")
    assert auth_service.current_session.is_authenticated
    assert auth_service.current_session.teacher_name == "محمد إبراهيم"
    auth_service.logout()
    assert not auth_service.current_session.is_authenticated


def test_login_wrong_password_raises_generic_error(temp_db):
    auth_service.register_teacher("سمير حسن", "لغة عربية", "Passw0rd")
    with pytest.raises(AuthenticationError):
        auth_service.login("سمير حسن", "WrongOne1")
    assert not auth_service.current_session.is_authenticated


def test_login_unknown_user_raises_same_error_type(temp_db):
    with pytest.raises(AuthenticationError):
        auth_service.login("غير موجود", "Passw0rd")


def test_duplicate_teacher_name_rejected(temp_db):
    auth_service.register_teacher("هدى فؤاد", "فرنسي", "Passw0rd")
    with pytest.raises(ValidationError):
        auth_service.register_teacher("هدى فؤاد", "فرنسي", "AnotherPass1")


def test_weak_password_rejected(temp_db):
    with pytest.raises(ValidationError):
        auth_service.register_teacher("مروان", "تاريخ", "123")


def test_change_password_flow(temp_db):
    auth_service.register_teacher("ريم", "جغرافيا", "OldPass1")
    auth_service.login("ريم", "OldPass1")
    auth_service.change_password("OldPass1", "NewPass1")
    auth_service.logout()

    with pytest.raises(AuthenticationError):
        auth_service.login("ريم", "OldPass1")
    auth_service.login("ريم", "NewPass1")
    assert auth_service.current_session.is_authenticated
    auth_service.logout()


def test_change_password_requires_login(temp_db):
    with pytest.raises(NotAuthenticatedError):
        auth_service.change_password("a", "b")


def test_change_password_wrong_old_password(temp_db):
    auth_service.register_teacher("كريم", "فلسفة", "OldPass1")
    auth_service.login("كريم", "OldPass1")
    with pytest.raises(AuthenticationError):
        auth_service.change_password("WrongOld1", "NewPass1")
    auth_service.logout()
