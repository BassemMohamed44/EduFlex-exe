from __future__ import annotations

from app.services import student_service
from app.ui.dialogs.qr_code_dialog import QRCodeDialog
from app.ui.dialogs.student_dialog import StudentDialog
from app.ui.windows.students_page import StudentsPage


def test_student_dialog_creates_student(temp_db, qtbot):
    dialog = StudentDialog()
    qtbot.addWidget(dialog)

    dialog.full_name_input.setText("كريم أحمد")
    dialog.grade_level_input.setText("الصف الثاني")
    dialog.price_input.setValue(300)
    dialog._on_save()

    assert dialog.error_label.text() == ""
    students = student_service.list_students()
    assert len(students) == 1
    assert students[0]["full_name"] == "كريم أحمد"


def test_student_dialog_missing_name_shows_error(temp_db, qtbot):
    dialog = StudentDialog()
    qtbot.addWidget(dialog)

    dialog.grade_level_input.setText("1")
    dialog._on_save()

    assert dialog.error_label.text() != ""
    assert student_service.list_students() == []


def test_student_dialog_edit_populates_and_saves(temp_db, qtbot):
    created = student_service.create_student(full_name="اسم أصلي", grade_level="1")
    full = student_service.get_student(created["id"])

    dialog = StudentDialog(student=full)
    qtbot.addWidget(dialog)
    assert dialog.full_name_input.text() == "اسم أصلي"

    dialog.full_name_input.setText("اسم معدل")
    dialog._on_save()

    updated = student_service.get_student(created["id"])
    assert updated["full_name"] == "اسم معدل"
    assert updated["student_code"] == created["student_code"]


def test_students_page_lists_students(temp_db, qtbot):
    student_service.create_student(full_name="طالب1", grade_level="1")
    student_service.create_student(full_name="طالب2", grade_level="2")

    page = StudentsPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 2


def test_students_page_search_filters_table(temp_db, qtbot):
    student_service.create_student(full_name="سارة محمود", grade_level="1")
    student_service.create_student(full_name="آخر", grade_level="1")

    page = StudentsPage()
    qtbot.addWidget(page)

    page.search_input.setText("سارة")
    assert page.table.rowCount() == 1
    assert page.table.item(0, 1).text() == "سارة محمود"


def test_students_page_add_dialog_refreshes_table(temp_db, qtbot):
    page = StudentsPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 0

    student_service.create_student(full_name="مضاف يدويًا", grade_level="1")
    page.refresh()
    assert page.table.rowCount() == 1


def test_students_page_selected_student_returns_correct_row(temp_db, qtbot):
    student_service.create_student(full_name="أول", grade_level="1")
    student_service.create_student(full_name="ثاني", grade_level="1")

    page = StudentsPage()
    qtbot.addWidget(page)
    page.table.selectRow(1)

    selected = page._selected_student()
    assert selected is not None
    assert selected["full_name"] == "ثاني"


def test_students_page_delete_selected_removes_student(temp_db, qtbot, monkeypatch):
    student_service.create_student(full_name="سيُحذف من الواجهة", grade_level="1")

    page = StudentsPage()
    qtbot.addWidget(page)
    page.table.selectRow(0)

    monkeypatch.setattr("app.ui.windows.students_page.confirm", lambda *a, **k: True)

    page._on_delete_selected()
    assert page.table.rowCount() == 0
    assert student_service.list_students() == []


def test_students_page_delete_cancelled_keeps_student(temp_db, qtbot, monkeypatch):
    student_service.create_student(full_name="لن يُحذف", grade_level="1")

    page = StudentsPage()
    qtbot.addWidget(page)
    page.table.selectRow(0)

    monkeypatch.setattr("app.ui.windows.students_page.confirm", lambda *a, **k: False)

    page._on_delete_selected()
    assert page.table.rowCount() == 1


def test_qr_code_dialog_loads_qr_for_student(temp_db, qtbot):
    created = student_service.create_student(full_name="طالب QR", grade_level="1")
    student = student_service.get_student(created["id"])

    dialog = QRCodeDialog(None, student)
    qtbot.addWidget(dialog)

    assert not dialog.image_label.pixmap().isNull()


def test_students_page_edit_without_selection_shows_hint(temp_db, qtbot, monkeypatch):
    called = {}
    monkeypatch.setattr(
        "app.ui.windows.students_page.show_info",
        lambda *a, **k: called.setdefault("shown", True),
    )
    page = StudentsPage()
    qtbot.addWidget(page)
    page._on_edit_selected()
    assert called.get("shown") is True


def test_students_page_delete_without_selection_shows_hint(temp_db, qtbot, monkeypatch):
    called = {}
    monkeypatch.setattr(
        "app.ui.windows.students_page.show_info",
        lambda *a, **k: called.setdefault("shown", True),
    )
    page = StudentsPage()
    qtbot.addWidget(page)
    page._on_delete_selected()
    assert called.get("shown") is True
