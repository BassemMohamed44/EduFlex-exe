from __future__ import annotations

import datetime as dt

from app.services import attendance_service, auth_service, student_service
from app.ui.windows.dashboard_page import DashboardPage
from app.ui.windows.login_window import LoginWindow
from app.ui.windows.main_window import MainWindow


def test_login_window_first_run_shows_registration_fields(temp_db, qtbot):
    window = LoginWindow()
    qtbot.addWidget(window)
    assert window._is_first_run is True
    assert window.subject_input is not None
    assert window.confirm_password_input is not None


def test_login_window_creates_account_and_logs_in(temp_db, qtbot):
    window = LoginWindow()
    qtbot.addWidget(window)

    window.name_input.setText("عمر خالد")
    window.subject_input.setText("لغة إنجليزية")
    window.password_input.setText("Passw0rd")
    window.confirm_password_input.setText("Passw0rd")

    with qtbot.waitSignal(window.login_succeeded, timeout=2000):
        window.submit_button.click()

    assert auth_service.current_session.is_authenticated
    assert auth_service.current_session.teacher_name == "عمر خالد"
    auth_service.logout()


def test_login_window_mismatched_passwords_shows_error(temp_db, qtbot):
    window = LoginWindow()
    qtbot.addWidget(window)

    window.name_input.setText("منى سعيد")
    window.subject_input.setText("تاريخ")
    window.password_input.setText("Passw0rd")
    window.confirm_password_input.setText("Different1")
    window.submit_button.click()

    assert "غير متطابقتين" in window.error_label.text()
    assert not auth_service.current_session.is_authenticated


def test_login_window_normal_run_shows_login_fields(temp_db, qtbot):
    auth_service.register_teacher("هالة يوسف", "رياضيات", "Passw0rd")
    auth_service.logout()

    window = LoginWindow()
    qtbot.addWidget(window)
    assert window._is_first_run is False
    assert window.subject_input is None


def test_login_window_wrong_password_shows_generic_error(temp_db, qtbot):
    auth_service.register_teacher("زياد سامي", "علوم", "Passw0rd")
    auth_service.logout()

    window = LoginWindow()
    qtbot.addWidget(window)
    window.name_input.setText("زياد سامي")
    window.password_input.setText("WrongPass1")
    window.submit_button.click()

    assert window.error_label.text() != ""
    assert not auth_service.current_session.is_authenticated


def test_main_window_shows_sidebar_and_dashboard(temp_db, qtbot):
    auth_service.register_teacher("لمياء فتحي", "علوم", "Passw0rd")
    auth_service.login("لمياء فتحي", "Passw0rd")

    window = MainWindow()
    qtbot.addWidget(window)

    assert window.sidebar is not None
    assert window.stack.currentWidget() is window.dashboard_page
    auth_service.logout()


def test_main_window_navigation_switches_pages(temp_db, qtbot):
    auth_service.register_teacher("باسم رفعت", "فيزياء", "Passw0rd")
    auth_service.login("باسم رفعت", "Passw0rd")

    window = MainWindow()
    qtbot.addWidget(window)

    window._on_navigate("students")
    assert window.stack.currentWidget() is window._pages["students"]

    window._on_navigate("dashboard")
    assert window.stack.currentWidget() is window.dashboard_page
    auth_service.logout()


def test_main_window_logout_clears_session(temp_db, qtbot):
    auth_service.register_teacher("جيهان عادل", "عربي", "Passw0rd")
    auth_service.login("جيهان عادل", "Passw0rd")

    window = MainWindow()
    qtbot.addWidget(window)
    window._on_logout()

    assert not auth_service.current_session.is_authenticated


def test_dashboard_reflects_real_data(temp_db, qtbot):
    student = student_service.create_student(full_name="طالب اللوحة", grade_level="1")
    attendance_service.record_attendance_by_code(student["student_code"])

    page = DashboardPage()
    qtbot.addWidget(page)

    assert page.card_total_students.value_label.text() == "1"
    assert page.card_present_today.value_label.text() == "1"
    assert page.card_absent_today.value_label.text() == "0"
    assert page.recent_table.rowCount() == 1


def test_dashboard_refresh_updates_after_new_data(temp_db, qtbot):
    page = DashboardPage()
    qtbot.addWidget(page)
    assert page.card_total_students.value_label.text() == "0"

    student_service.create_student(full_name="طالب جديد", grade_level="1")
    page.refresh()
    assert page.card_total_students.value_label.text() == "1"
