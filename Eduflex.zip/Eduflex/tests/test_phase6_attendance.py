from __future__ import annotations

import datetime as dt

import pytest

from app.models.student import StudentStatus
from app.qr import qr_service
from app.services import attendance_service, class_service, student_service
from app.services.attendance_service import (
    get_today_summary,
    list_attendance_for_date,
    list_attendance_for_student,
    list_recent_attendance,
    record_attendance_by_code,
    record_attendance_by_token,
)
from app.utils.exceptions import AttendanceError, NotFoundError, ValidationError


def test_first_scan_is_check_in(temp_db):
    student = student_service.create_student(full_name="أمير", grade_level="1")
    result = record_attendance_by_code(student["student_code"])
    assert result["action"] == "check_in"
    assert result["check_out_time"] is None


def test_second_scan_same_day_is_check_out(temp_db):
    student = student_service.create_student(full_name="فادي", grade_level="1")
    record_attendance_by_code(student["student_code"])
    result = record_attendance_by_code(student["student_code"])
    assert result["action"] == "check_out"
    assert result["check_out_time"] is not None


def test_third_scan_same_day_rejected(temp_db):
    student = student_service.create_student(full_name="جودي", grade_level="1")
    record_attendance_by_code(student["student_code"])
    record_attendance_by_code(student["student_code"])
    with pytest.raises(AttendanceError):
        record_attendance_by_code(student["student_code"])


def test_attendance_via_qr_token(temp_db):
    student = student_service.create_student(full_name="ندى", grade_level="1")
    qr = qr_service.generate_qr_for_student(student["id"])
    result = record_attendance_by_token(qr["token"])
    assert result["action"] == "check_in"
    assert result["student_id"] == student["id"]


def test_attendance_invalid_qr_token_rejected(temp_db):
    with pytest.raises(NotFoundError):
        record_attendance_by_token("nonexistent-token")


def test_attendance_invalid_student_code_rejected(temp_db):
    with pytest.raises(NotFoundError):
        record_attendance_by_code("9999")


def test_attendance_empty_code_rejected(temp_db):
    with pytest.raises(ValidationError):
        record_attendance_by_code("")


def test_attendance_blocked_for_inactive_student(temp_db):
    student = student_service.create_student(full_name="معطل", grade_level="1")
    student_service.update_student(
        student["id"],
        full_name="معطل",
        grade_level="1",
        status=StudentStatus.SUSPENDED,
    )
    with pytest.raises(AttendanceError):
        record_attendance_by_code(student["student_code"])


def test_attendance_separate_per_class(temp_db):
    student = student_service.create_student(full_name="متعدد", grade_level="1")
    c1 = class_service.create_class(subject="رياضيات", days_of_week="Sat", time_slot="4 PM")
    c2 = class_service.create_class(subject="فيزياء", days_of_week="Sat", time_slot="6 PM")

    r1 = record_attendance_by_code(student["student_code"], class_id=c1["id"])
    r2 = record_attendance_by_code(student["student_code"], class_id=c2["id"])
    assert r1["action"] == "check_in"
    assert r2["action"] == "check_in"


def test_attendance_records_check_in_check_out_and_source(temp_db):
    student = student_service.create_student(full_name="سجل", grade_level="1")
    record_attendance_by_code(student["student_code"])
    record_attendance_by_code(student["student_code"])

    records = list_attendance_for_student(student["id"])
    assert len(records) == 1
    assert records[0]["check_in_time"] is not None
    assert records[0]["check_out_time"] is not None
    assert records[0]["source"].value == "manual_id"


def test_list_attendance_for_date(temp_db):
    s1 = student_service.create_student(full_name="اليوم1", grade_level="1")
    s2 = student_service.create_student(full_name="اليوم2", grade_level="1")
    record_attendance_by_code(s1["student_code"])
    record_attendance_by_code(s2["student_code"])

    today_records = list_attendance_for_date(dt.date.today())
    assert len(today_records) == 2


def test_list_recent_attendance(temp_db):
    for i in range(3):
        s = student_service.create_student(full_name=f"حديث{i}", grade_level="1")
        record_attendance_by_code(s["student_code"])

    recent = list_recent_attendance(limit=2)
    assert len(recent) == 2


def test_dashboard_today_summary(temp_db):
    s1 = student_service.create_student(full_name="حاضر", grade_level="1")
    student_service.create_student(full_name="غائب", grade_level="1")
    record_attendance_by_code(s1["student_code"])

    summary = get_today_summary()
    assert summary["total_students"] == 2
    assert summary["present_today"] == 1
    assert summary["absent_today"] == 1
    assert summary["attendance_rate"] == 50.0


def test_attendance_includes_subscription_status(temp_db):
    student = student_service.create_student(full_name="مشترك", grade_level="1")
    from app.services import subscription_service

    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today,
        end_date=today + dt.timedelta(days=30),
    )

    result = record_attendance_by_code(student["student_code"])
    assert result["subscription_status"].value == "active"
