from __future__ import annotations

import os
import time

import pytest

from app.services import backup_service, student_service
from app.utils.exceptions import BackupError


def test_create_backup_creates_real_file(temp_db):
    student_service.create_student(full_name="نسخة1", grade_level="1")
    result = backup_service.create_backup()
    assert os.path.exists(result["path"])
    assert os.path.getsize(result["path"]) > 0


def test_create_backup_to_custom_directory(temp_db, tmp_path):
    custom_dir = tmp_path / "my_backups"
    result = backup_service.create_backup(destination_dir=str(custom_dir))
    assert os.path.exists(result["path"])
    assert str(custom_dir) in result["path"]


def test_get_last_backup_info_after_backup(temp_db):
    assert backup_service.get_last_backup_info() is None
    backup_service.create_backup()
    info = backup_service.get_last_backup_info()
    assert info is not None
    assert info["exists"] is True


def test_list_available_backups(temp_db):
    assert backup_service.list_available_backups() == []
    backup_service.create_backup()
    time.sleep(0.01)
    backup_service.create_backup()
    backups = backup_service.list_available_backups()
    assert len(backups) == 2


def test_restore_backup_recovers_data(temp_db):
    student_service.create_student(full_name="قبل النسخة", grade_level="1")
    backup = backup_service.create_backup()

    student_service.create_student(full_name="بعد النسخة", grade_level="1")
    all_students_before_restore = student_service.list_students()
    assert len(all_students_before_restore) == 2

    backup_service.restore_backup(backup["path"])

    all_students_after_restore = student_service.list_students()
    names = {s["full_name"] for s in all_students_after_restore}
    assert names == {"قبل النسخة"}


def test_restore_backup_creates_pre_restore_safety_copy(temp_db):
    student_service.create_student(full_name="أساسي", grade_level="1")
    backup = backup_service.create_backup()

    student_service.create_student(full_name="سيُفقد", grade_level="1")

    backups_before = len(backup_service.list_available_backups())
    result = backup_service.restore_backup(backup["path"])

    assert "pre_restore_backup" in result
    assert os.path.exists(result["pre_restore_backup"])
    backups_after = len(backup_service.list_available_backups())
    assert backups_after > backups_before


def test_restore_nonexistent_file_rejected(temp_db):
    with pytest.raises(BackupError):
        backup_service.restore_backup("/tmp/does_not_exist_eduflex.db")


def test_restore_invalid_file_rejected(temp_db, tmp_path):
    junk_file = tmp_path / "not_a_database.db"
    junk_file.write_text("this is not a sqlite database")
    with pytest.raises(BackupError):
        backup_service.restore_backup(str(junk_file))


def test_restore_recovers_even_after_deletion(temp_db):
    student = student_service.create_student(full_name="سيُحذف ثم يعود", grade_level="1")
    backup = backup_service.create_backup()

    student_service.delete_student(student["id"])
    assert student_service.list_students() == []

    backup_service.restore_backup(backup["path"])
    restored = student_service.list_students()
    assert len(restored) == 1
    assert restored[0]["full_name"] == "سيُحذف ثم يعود"
