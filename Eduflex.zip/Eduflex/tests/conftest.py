from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app.config import settings as settings_module
from app.database import session as session_module
from app.database.init_db import init_database


@pytest.fixture()
def temp_db(tmp_path, monkeypatch):
    settings_module.reset_for_tests(tmp_path)
    session_module.reset_engine_for_tests(settings_module.get_paths().database_file)

    from app.utils.logger import reset_logging_for_tests
    reset_logging_for_tests()

    init_database()

    from app.services.auth_service import current_session
    current_session.clear()

    yield session_module.get_session_factory()

    current_session.clear()
