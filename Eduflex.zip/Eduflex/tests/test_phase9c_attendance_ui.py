from __future__ import annotations

import datetime as dt

from app.services import student_service, subscription_service
from app.ui.windows.attendance_page import AttendancePage


def test_attendance_page_manual_check_in(temp_db, qtbot):
    student = student_service.create_student(full_name="حضور واجهة", grade_level="1")
    page = AttendancePage()
    qtbot.addWidget(page)

    page.code_input.setText(student["student_code"])
    page._on_submit_code()

    assert "تسجيل حضور" in page.banner.label.text()
    assert page.table.rowCount() == 1
    assert page.table.item(0, 0).text() == "حضور واجهة"


def test_attendance_page_second_submit_is_check_out(temp_db, qtbot):
    student = student_service.create_student(full_name="انصراف واجهة", grade_level="1")
    page = AttendancePage()
    qtbot.addWidget(page)

    page.code_input.setText(student["student_code"])
    page._on_submit_code()
    page.code_input.setText(student["student_code"])
    page._on_submit_code()

    assert "تسجيل انصراف" in page.banner.label.text()
    assert page.table.item(0, 3).text() != "-"


def test_attendance_page_invalid_code_shows_error_banner(temp_db, qtbot):
    page = AttendancePage()
    qtbot.addWidget(page)

    page.code_input.setText("9999")
    page._on_submit_code()

    assert page.table.rowCount() == 0
    assert "#E74C3C" in page.banner.label.styleSheet()


def test_attendance_page_shows_expired_subscription_warning(temp_db, qtbot):
    student = student_service.create_student(full_name="اشتراك منتهي واجهة", grade_level="1")
    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=5),
        price=100,
    )

    page = AttendancePage()
    qtbot.addWidget(page)
    page.code_input.setText(student["student_code"])
    page._on_submit_code()

    assert "منتهٍ" in page.banner.label.text()
    assert "#F39C12" in page.banner.label.styleSheet()


def test_attendance_page_refresh_loads_existing_records(temp_db, qtbot):
    student = student_service.create_student(full_name="سجل موجود مسبقًا", grade_level="1")
    from app.services import attendance_service

    attendance_service.record_attendance_by_code(student["student_code"])

    page = AttendancePage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 1
