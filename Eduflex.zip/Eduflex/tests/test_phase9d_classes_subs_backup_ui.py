from __future__ import annotations

import datetime as dt

from app.services import backup_service, class_service, student_service, subscription_service
from app.ui.dialogs.class_dialog import ClassDialog
from app.ui.dialogs.enrollment_dialog import EnrollmentDialog
from app.ui.dialogs.student_dialog import StudentDialog
from app.ui.windows.backup_page import BackupPage
from app.ui.windows.classes_page import ClassesPage
from app.ui.windows.subscriptions_page import SubscriptionsPage, RenewSubscriptionDialog


def test_student_dialog_creates_matching_subscription_row(temp_db, qtbot):
    dialog = StudentDialog()
    qtbot.addWidget(dialog)
    dialog.full_name_input.setText("طالب واشتراك")
    dialog.grade_level_input.setText("1")
    dialog.price_input.setValue(250)
    dialog._on_save()

    student = student_service.list_students()[0]
    subs = subscription_service.list_subscriptions_for_student(student["id"])
    assert len(subs) == 1
    assert subs[0]["price"] == 250


def test_class_dialog_creates_class(temp_db, qtbot):
    dialog = ClassDialog()
    qtbot.addWidget(dialog)
    dialog.subject_input.setText("كيمياء")
    dialog.days_input.setText("Sun,Tue")
    dialog.time_input.setText("6 PM")
    dialog._on_save()

    assert dialog.error_label.text() == ""
    assert len(class_service.list_classes()) == 1


def test_classes_page_lists_classes(temp_db, qtbot):
    class_service.create_class(subject="فيزياء", days_of_week="Sat", time_slot="4 PM")
    page = ClassesPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 1


def test_classes_page_delete_bypassed_confirm(temp_db, qtbot, monkeypatch):
    class_service.create_class(subject="حذف هذه", days_of_week="Sat", time_slot="4 PM")
    page = ClassesPage()
    qtbot.addWidget(page)
    page.table.selectRow(0)
    monkeypatch.setattr("app.ui.windows.classes_page.confirm", lambda *a, **k: True)
    page._on_delete_selected()
    assert page.table.rowCount() == 0


def test_enrollment_dialog_enroll_and_unenroll(temp_db, qtbot):
    student = student_service.create_student(full_name="طالب تسجيل", grade_level="1")
    c = class_service.create_class(subject="أحياء", days_of_week="Wed", time_slot="7 PM")

    dialog = EnrollmentDialog(None, c)
    qtbot.addWidget(dialog)
    assert dialog.student_picker.count() == 1

    dialog.student_picker.setCurrentIndex(0)
    dialog._on_enroll()
    assert dialog.list_widget.count() == 1
    assert dialog.student_picker.count() == 0

    dialog.list_widget.setCurrentRow(0)
    dialog._on_unenroll()
    assert dialog.list_widget.count() == 0

    assert class_service.list_students_for_class(c["id"]) == []


def test_subscriptions_page_shows_status(temp_db, qtbot):
    student = student_service.create_student(full_name="مشترك واجهة", grade_level="1")
    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"], start_date=today, end_date=today + dt.timedelta(days=30), price=200
    )

    page = SubscriptionsPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 1
    assert page.table.item(0, 4).text() == "نشط"


def test_subscriptions_page_filter_by_status(temp_db, qtbot):
    active_student = student_service.create_student(full_name="نشط واجهة", grade_level="1")
    expired_student = student_service.create_student(full_name="منتهي واجهة", grade_level="1")
    today = dt.date.today()

    subscription_service.create_subscription(
        student_id=active_student["id"], start_date=today, end_date=today + dt.timedelta(days=30)
    )
    subscription_service.create_subscription(
        student_id=expired_student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=5),
    )

    page = SubscriptionsPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 2

    page.status_filter.setCurrentIndex(3)
    assert page.table.rowCount() == 1
    assert page.table.item(0, 0).text() == "منتهي واجهة"


def test_renew_subscription_dialog_creates_new_row(temp_db, qtbot):
    student = student_service.create_student(full_name="تجديد واجهة", grade_level="1")
    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"],
        start_date=today - dt.timedelta(days=60),
        end_date=today - dt.timedelta(days=5),
        price=100,
    )

    full_student = student_service.get_student(student["id"])
    dialog = RenewSubscriptionDialog(None, full_student)
    qtbot.addWidget(dialog)
    dialog.price_input.setValue(150)
    dialog._on_save()

    subs = subscription_service.list_subscriptions_for_student(student["id"])
    assert len(subs) == 2
    status = subscription_service.get_current_status_for_student(student["id"])
    assert status.value == "active"


def test_backup_page_lists_backups(temp_db, qtbot):
    backup_service.create_backup()
    page = BackupPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 1
    assert "لا يوجد" not in page.last_backup_label.text()


def test_backup_page_shows_no_backups_message_initially(temp_db, qtbot):
    page = BackupPage()
    qtbot.addWidget(page)
    assert page.table.rowCount() == 0
    assert "لم يتم إنشاء" in page.last_backup_label.text()


def test_backup_page_restore_selected_bypassed_confirm(temp_db, qtbot, monkeypatch):
    student_service.create_student(full_name="قبل النسخة", grade_level="1")
    backup_service.create_backup()
    student_service.create_student(full_name="بعد النسخة", grade_level="1")

    page = BackupPage()
    qtbot.addWidget(page)
    page.table.selectRow(0)

    monkeypatch.setattr("app.ui.windows.backup_page.confirm", lambda *a, **k: True)
    monkeypatch.setattr("app.ui.windows.backup_page.show_info", lambda *a, **k: None)

    page._on_restore_selected()

    names = {s["full_name"] for s in student_service.list_students()}
    assert names == {"قبل النسخة"}
