from __future__ import annotations

import datetime as dt
import logging

import pytest

from app.config.settings import get_paths
from app.services import (
    attendance_service,
    auth_service,
    backup_service,
    class_service,
    exam_service,
    export_service,
    student_service,
    subscription_service,
)
from app.qr import qr_service
from app.utils.exceptions import ValidationError


def test_password_never_appears_in_log_file(temp_db):
    secret_password = "MySuperSecret789"
    new_secret_password = "AnotherSecret456"

    auth_service.register_teacher("مستخدم السجل", "مادة", secret_password)
    auth_service.login("مستخدم السجل", secret_password)
    auth_service.change_password(secret_password, new_secret_password)
    auth_service.logout()

    for handler in logging.getLogger("eduflex").handlers:
        handler.flush()

    log_file = get_paths().logs_dir / "eduflex.log"
    assert log_file.exists()
    content = log_file.read_text(encoding="utf-8")

    assert secret_password not in content
    assert new_secret_password not in content
    assert "$argon2id$" not in content


def test_qr_token_and_payload_never_logged(temp_db):
    student = student_service.create_student(full_name="سري", grade_level="1")
    result = qr_service.generate_qr_for_student(student["id"])

    for handler in logging.getLogger("eduflex").handlers:
        handler.flush()

    log_file = get_paths().logs_dir / "eduflex.log"
    content = log_file.read_text(encoding="utf-8")
    assert result["token"] not in content
    assert result["payload"] not in content


def test_sql_injection_style_input_is_stored_safely_not_executed(temp_db):
    malicious_name = "Robert'); DROP TABLE students;--"
    student = student_service.create_student(full_name=malicious_name, grade_level="1")

    fetched = student_service.get_student(student["id"])
    assert fetched["full_name"] == malicious_name

    student_service.create_student(full_name="طالب عادي بعد المحاولة", grade_level="1")
    assert len(student_service.list_students()) == 2


def test_search_text_with_sql_wildcards_does_not_crash(temp_db):
    student_service.create_student(full_name="اختبار%_وايلد كارد", grade_level="1")
    results = student_service.search_students(text="%")
    assert isinstance(results, list)


def test_full_workflow_across_all_phases(temp_db, tmp_path):
    auth_service.register_teacher("مدرس شامل", "رياضيات", "FullFlow123")
    auth_service.login("مدرس شامل", "FullFlow123")

    student = student_service.create_student(
        full_name="طالب التدفق الكامل", grade_level="3", subscription_price=400
    )

    class_session = class_service.create_class(
        subject="فيزياء", days_of_week="Sat,Mon", time_slot="5 PM", price=250
    )
    class_service.enroll_student(student["id"], class_session["id"])

    today = dt.date.today()
    subscription_service.create_subscription(
        student_id=student["id"], start_date=today, end_date=today + dt.timedelta(days=30), price=400
    )

    qr = qr_service.generate_qr_for_student(student["id"])

    attendance_result = attendance_service.record_attendance_by_token(qr["token"])
    assert attendance_result["action"] == "check_in"

    exam = exam_service.create_exam(
        name="اختبار التدفق", subject="فيزياء", exam_date=today, max_score=100, grade_level="3"
    )
    exam_service.record_result(exam["id"], student["id"], 92)

    stats = export_service.export_comprehensive_statistics("pdf", str(tmp_path / "stats.pdf"))
    assert stats

    backup = backup_service.create_backup()
    student_service.delete_student(student["id"])
    assert student_service.list_students() == []

    backup_service.restore_backup(backup["path"])
    restored_students = student_service.list_students()
    assert len(restored_students) == 1
    assert restored_students[0]["full_name"] == "طالب التدفق الكامل"

    restored_id = restored_students[0]["id"]
    assert len(class_service.list_classes_for_student(restored_id)) == 1
    assert len(exam_service.list_results_for_student(restored_id)) == 1

    auth_service.logout()


def test_reports_on_empty_database_do_not_crash(temp_db):
    from app.services import report_service

    assert report_service.attendance_totals_report() == []
    assert report_service.expired_subscriptions_report() == []
    stats = report_service.comprehensive_statistics_report()
    assert stats["number_of_students"] == 0
    assert stats["attendance_rate"] == 0.0


def test_settings_persist_across_reloads(temp_db):
    from app.config.settings import get_settings

    get_settings().set("subscription_warning_days", 15)
    from app.config.settings import Settings, get_paths

    reloaded = Settings(get_paths())
    assert reloaded.get("subscription_warning_days") == 15


def test_migrations_are_idempotent(temp_db):
    from app.database.init_db import init_database

    init_database()
    init_database()
    student_service.create_student(full_name="بعد الترحيل", grade_level="1")
    assert len(student_service.list_students()) == 1


def test_generic_error_message_for_unexpected_ui_exception(temp_db):
    from app.ui.helpers import show_error

    class _FakeParentless:
        pass

    from app.utils.exceptions import EduflexError

    raw_error = RuntimeError("Traceback: secret internal path /etc/eduflex/db leaked")
    assert not isinstance(raw_error, EduflexError)
