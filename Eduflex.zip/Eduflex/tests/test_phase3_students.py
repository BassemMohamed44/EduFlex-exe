from __future__ import annotations

import datetime as dt

import pytest

from app.models.student import StudentStatus
from app.services import student_service
from app.utils.exceptions import NotFoundError, ValidationError


def test_create_student_assigns_4_digit_code(temp_db):
    student = student_service.create_student(full_name="أحمد", grade_level="1")
    assert len(student["student_code"]) == 4
    assert 1000 <= int(student["student_code"]) <= 9999


def test_create_student_codes_are_unique(temp_db):
    codes = set()
    for i in range(30):
        s = student_service.create_student(full_name=f"طالب{i}", grade_level="1")
        codes.add(s["student_code"])
    assert len(codes) == 30


def test_create_student_missing_name_rejected(temp_db):
    with pytest.raises(ValidationError):
        student_service.create_student(full_name="  ", grade_level="1")


def test_create_student_negative_price_rejected(temp_db):
    with pytest.raises(ValidationError):
        student_service.create_student(full_name="سالي", grade_level="1", subscription_price=-10)


def test_create_student_invalid_phone_rejected(temp_db):
    with pytest.raises(ValidationError):
        student_service.create_student(full_name="مينا", grade_level="1", student_phone="abc")


def test_create_student_invalid_date_range_rejected(temp_db):
    with pytest.raises(ValidationError):
        student_service.create_student(
            full_name="لينا",
            grade_level="1",
            subscription_start=dt.date(2026, 5, 1),
            subscription_end=dt.date(2026, 1, 1),
        )


def test_update_student(temp_db):
    created = student_service.create_student(full_name="عمر", grade_level="1")
    updated = student_service.update_student(
        created["id"], full_name="عمر خالد", grade_level="2", subscription_price=500
    )
    assert updated["full_name"] == "عمر خالد"
    assert updated["grade_level"] == "2"
    assert updated["student_code"] == created["student_code"]


def test_update_nonexistent_student_raises(temp_db):
    with pytest.raises(NotFoundError):
        student_service.update_student(9999, full_name="x", grade_level="1")


def test_delete_student(temp_db):
    created = student_service.create_student(full_name="سيف", grade_level="1")
    student_service.delete_student(created["id"])
    with pytest.raises(NotFoundError):
        student_service.get_student(created["id"])


def test_delete_nonexistent_student_raises(temp_db):
    with pytest.raises(NotFoundError):
        student_service.delete_student(9999)


def test_get_student_by_code(temp_db):
    created = student_service.create_student(full_name="هبة", grade_level="3")
    fetched = student_service.get_student_by_code(created["student_code"])
    assert fetched["id"] == created["id"]


def test_search_students_by_text(temp_db):
    student_service.create_student(full_name="محمود عادل", grade_level="1")
    student_service.create_student(full_name="عادل حسن", grade_level="2")
    student_service.create_student(full_name="غير ذلك", grade_level="3")

    results = student_service.search_students(text="عادل")
    names = {r["full_name"] for r in results}
    assert names == {"محمود عادل", "عادل حسن"}


def test_search_students_by_grade_and_status(temp_db):
    a = student_service.create_student(full_name="ط1", grade_level="1")
    student_service.create_student(full_name="ط2", grade_level="2")
    student_service.update_student(
        a["id"], full_name="ط1", grade_level="1", status=StudentStatus.ARCHIVED
    )

    active_grade1 = student_service.search_students(grade_level="1", status=StudentStatus.ACTIVE)
    assert active_grade1 == []

    archived = student_service.search_students(status=StudentStatus.ARCHIVED)
    assert len(archived) == 1
    assert archived[0]["full_name"] == "ط1"


def test_search_students_sorting(temp_db):
    student_service.create_student(full_name="ب", grade_level="1")
    student_service.create_student(full_name="أ", grade_level="1")

    ascending = student_service.search_students(sort_by="full_name", sort_desc=False)
    assert [r["full_name"] for r in ascending] == ["أ", "ب"]

    descending = student_service.search_students(sort_by="full_name", sort_desc=True)
    assert [r["full_name"] for r in descending] == ["ب", "أ"]
