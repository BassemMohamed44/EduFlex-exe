# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for Eduflex.

Build (from a Windows machine, inside the project's virtualenv):
    pyinstaller eduflex.spec

Produces dist/Eduflex/Eduflex.exe (a one-folder build - preferred over
one-file for a PySide6 + OpenCV app, since one-file builds unpack to a
temp directory on every launch, which is slow and complicates the
camera/QR native libraries OpenCV and pyzbar depend on).

IMPORTANT: the SQLite database is deliberately NOT bundled into this
build and is never written under the install directory - see
app/config/settings.py:get_app_data_dir(), which always resolves to
%APPDATA%\\Eduflex on Windows, a location the installed (and
potentially read-only, e.g. under Program Files) directory tree does
not need write access to.
"""
from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs

block_cipher = None

# OpenCV and pyzbar both ship native shared libraries that PyInstaller's
# static analysis can miss; collect them explicitly rather than relying
# on auto-detection alone.
binaries = []
binaries += collect_dynamic_libs("cv2")
binaries += collect_dynamic_libs("pyzbar")

datas = []
datas += collect_data_files("pyzbar")  # bundles libzbar DLL/dependencies on Windows

a = Analysis(
    ["app/main.py"],
    pathex=["."],
    binaries=binaries,
    datas=datas,
    hiddenimports=[
        "PySide6.QtSvg",  # used indirectly by some Qt widgets/icons
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Eduflex",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # no console window for a desktop GUI app
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # set to "assets/icon.ico" once an app icon is added
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="Eduflex",
)
