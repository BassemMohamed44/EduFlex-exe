@echo off
REM Build script for Eduflex.exe on Windows.
REM Run from the project root inside an activated virtualenv that has
REM requirements.txt installed.

echo Running test suite before packaging...
pytest
if %ERRORLEVEL% NEQ 0 (
    echo Tests failed - aborting build.
    exit /b 1
)

echo Cleaning previous build artifacts...
rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul

echo Building Eduflex.exe with PyInstaller...
pyinstaller eduflex.spec

echo.
echo Build complete. Find the app at dist\Eduflex\Eduflex.exe
